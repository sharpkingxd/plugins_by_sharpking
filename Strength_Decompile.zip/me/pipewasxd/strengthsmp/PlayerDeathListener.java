package me.pipewasxd.strengthsmp;

import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public record PlayerDeathListener(StrengthManager strengthManager, ConfigManager configManager) implements Listener {
   @EventHandler
   public void onPlayerDeath(PlayerDeathEvent event) {
      Player victim = event.getEntity();
      Player killer = victim.getKiller();
      if (killer != null && killer != victim) {
         if (!this.strengthManager.isAtMinStrength(victim)) {
            this.strengthManager.addStrength(victim, -1);
            String var10001 = String.valueOf(ChatColor.DARK_RED);
            victim.sendMessage(var10001 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ʟᴏsᴛ " + String.valueOf(ChatColor.WHITE) + String.valueOf(ChatColor.BOLD) + "-1" + String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + " sᴛʀᴇɴɢᴛʜ");
            if (this.strengthManager.isAtMaxStrength(killer)) {
               ItemStack strengthItem = StrengthItemRecipe.createStrengthItem();
               event.getDrops().add(strengthItem);
               var10001 = String.valueOf(ChatColor.DARK_RED);
               killer.sendMessage(var10001 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ᴀʀᴇ ᴀᴛ ᴛʜᴇ ᴍᴀxɪᴍᴜᴍ ᴀᴍᴏᴜɴᴛ ᴏғ sᴛʀᴇɴɢᴛʜ!");
            } else {
               this.strengthManager.addStrength(killer, 1);
               var10001 = String.valueOf(ChatColor.DARK_RED);
               killer.sendMessage(var10001 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ɢᴀɪɴᴇᴅ " + String.valueOf(ChatColor.WHITE) + String.valueOf(ChatColor.BOLD) + "+1" + String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + " sᴛʀᴇɴɢᴛʜ");
            }
         } else {
            String var7 = String.valueOf(ChatColor.DARK_RED);
            victim.sendMessage(var7 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ᴀʀᴇ ᴀᴛ ᴛʜᴇ ᴍɪɴɪᴍᴜᴍ ᴀᴍᴏᴜɴᴛ ᴏғ sᴛʀᴇɴɢᴛʜ!");
         }
      }

   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      this.strengthManager.loadPlayerStrength(event.getPlayer());
   }

   @EventHandler
   public void onPlayerRespawn(PlayerRespawnEvent event) {
      Bukkit.getScheduler().runTaskLater((Plugin)Objects.requireNonNull(Bukkit.getPluginManager().getPlugin("StrengthSMP")), () -> this.strengthManager.loadPlayerStrength(event.getPlayer()), 10L);
   }
}
