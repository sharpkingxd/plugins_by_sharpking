package com.sharpkingyt.majesticmace.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.ChatColor;

import com.sharpkingyt.majesticmace.MajesticMace;
import com.sharpkingyt.majesticmace.utils.SmallCapsConverter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MajesticMaceCommand implements CommandExecutor, TabCompleter {
    
    private final MajesticMace plugin;
    
    public MajesticMaceCommand(MajesticMace plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        
        if (args.length == 0) {
            sendHelpMessage(sender);
            return true;
        }
        
        switch (args[0].toLowerCase()) {
            case "setrecipe":
            case "set":
                return handleSetRecipeCommand(sender);
                
            case "viewrecipe":
            case "view":
                return handleViewRecipeCommand(sender);
                
            case "reload":
                return handleReloadCommand(sender);
                
            case "help":
                sendHelpMessage(sender);
                return true;
                
            case "info":
                sendInfoMessage(sender);
                return true;
                
            case "toggle":
                return handleToggleCommand(sender);
                
            case "reset":
                return handleResetCommand(sender);
                
            default:
                sender.sendMessage(ChatColor.RED + SmallCapsConverter.convert("Unknown subcommand. Use /majesticmace help for available commands."));
                return true;
        }
    }
    
    private boolean handleSetRecipeCommand(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + SmallCapsConverter.convert("This command can only be used by players!"));
            return true;
        }
        
        Player player = (Player) sender;
        
        if (!player.hasPermission("majesticmace.recipe")) {
            player.sendMessage(ChatColor.RED + "§c§l" + SmallCapsConverter.convert("Access Denied! You don't have permission to configure recipes."));
            plugin.getSoundManager().playSound(player, "access-denied");
            return true;
        }
        
        plugin.getGUIManager().openRecipeEditorGUI(player);
        plugin.getSoundManager().playSound(player, "command-execute");
        return true;
    }
    
    private boolean handleViewRecipeCommand(CommandSender sender) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + SmallCapsConverter.convert("This command can only be used by players!"));
            return true;
        }
        
        Player player = (Player) sender;
        plugin.getGUIManager().openViewRecipeGUI(player);
        plugin.getSoundManager().playSound(player, "command-execute");
        return true;
    }
    
    private boolean handleReloadCommand(CommandSender sender) {
        if (!sender.hasPermission("majesticmace.admin")) {
            sender.sendMessage(ChatColor.RED + "§c§l" + SmallCapsConverter.convert("Access Denied! You don't have permission to reload the plugin."));
            if (sender instanceof Player) {
                plugin.getSoundManager().playSound((Player) sender, "access-denied");
            }
            return true;
        }
        
        plugin.reloadPluginConfig();
        sender.sendMessage(ChatColor.GREEN + "§a§l" + SmallCapsConverter.convert("MajesticMace configuration reloaded successfully!"));
        
        if (sender instanceof Player) {
            plugin.getSoundManager().playSound((Player) sender, "command-execute");
        }
        return true;
    }
    
    private boolean handleToggleCommand(CommandSender sender) {
        if (!sender.hasPermission("majesticmace.admin")) {
            sender.sendMessage(ChatColor.RED + "§c§l" + SmallCapsConverter.convert("Access Denied! You don't have permission to toggle the recipe system."));
            if (sender instanceof Player) {
                plugin.getSoundManager().playSound((Player) sender, "access-denied");
            }
            return true;
        }
        
        boolean currentState = plugin.getConfig().getBoolean("recipe.enabled");
        plugin.getConfig().set("recipe.enabled", !currentState);
        plugin.saveConfig();
        
        String status = !currentState ? "§a§l" + SmallCapsConverter.convert("ENABLED") : "§c§l" + SmallCapsConverter.convert("DISABLED");
        sender.sendMessage(ChatColor.YELLOW + "§e§l" + SmallCapsConverter.convert("Recipe system ") + status + "§e§l!");
        
        if (sender instanceof Player) {
            plugin.getSoundManager().playSound((Player) sender, "recipe-toggle");
        }
        return true;
    }
    
    private boolean handleResetCommand(CommandSender sender) {
        if (!sender.hasPermission("majesticmace.admin")) {
            sender.sendMessage(ChatColor.RED + "§c§l" + SmallCapsConverter.convert("Access Denied! You don't have permission to reset recipes."));
            if (sender instanceof Player) {
                plugin.getSoundManager().playSound((Player) sender, "access-denied");
            }
            return true;
        }
        
        plugin.getRecipeManager().resetToDefault();
        sender.sendMessage(ChatColor.YELLOW + "§e§l" + SmallCapsConverter.convert("Mace recipe has been reset to default settings!"));
        
        if (sender instanceof Player) {
            plugin.getSoundManager().playSound((Player) sender, "reset-recipe");
        }
        return true;
    }
    
    private void sendHelpMessage(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        sender.sendMessage(ChatColor.GOLD + "§6§l                    " + SmallCapsConverter.convert("MAJESTIC MACE HELP"));
        sender.sendMessage(ChatColor.GOLD + "§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.YELLOW + "§e/majesticmace setrecipe §7- §f" + SmallCapsConverter.convert("Open recipe editor GUI") + " §7(OP only)");
        sender.sendMessage(ChatColor.YELLOW + "§e/majesticmace viewrecipe §7- §f" + SmallCapsConverter.convert("View current recipe") + " §7(All players)");
        sender.sendMessage(ChatColor.YELLOW + "§e/majesticmace reload §7- §f" + SmallCapsConverter.convert("Reload plugin configuration") + " §7(OP only)");
        sender.sendMessage(ChatColor.YELLOW + "§e/majesticmace toggle §7- §f" + SmallCapsConverter.convert("Enable/disable recipe system") + " §7(OP only)");
        sender.sendMessage(ChatColor.YELLOW + "§e/majesticmace reset §7- §f" + SmallCapsConverter.convert("Reset recipe to default") + " §7(OP only)");
        sender.sendMessage(ChatColor.YELLOW + "§e/majesticmace info §7- §f" + SmallCapsConverter.convert("Show plugin information"));
        sender.sendMessage(ChatColor.YELLOW + "§e/majesticmace help §7- §f" + SmallCapsConverter.convert("Show this help menu"));
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GRAY + "§7" + SmallCapsConverter.convert("Aliases:") + " §f/mmace, /mm");
        sender.sendMessage(ChatColor.GRAY + "§7" + SmallCapsConverter.convert("Set aliases:") + " §f/mm set, /mmace set");
        sender.sendMessage(ChatColor.GRAY + "§7" + SmallCapsConverter.convert("View aliases:") + " §f/mm view, /mmace view");
        sender.sendMessage(ChatColor.GOLD + "§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        
        if (sender instanceof Player) {
            plugin.getSoundManager().playSound((Player) sender, "command-execute");
        }
    }
    
    private void sendInfoMessage(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        sender.sendMessage(ChatColor.GOLD + "§6§l                    " + SmallCapsConverter.convert("MAJESTIC MACE INFO"));
        sender.sendMessage(ChatColor.GOLD + "§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.YELLOW + "§e" + SmallCapsConverter.convert("Plugin:") + " §f" + SmallCapsConverter.convert("Majestic Mace"));
        sender.sendMessage(ChatColor.YELLOW + "§e" + SmallCapsConverter.convert("Version:") + " §f1.0.0");
        sender.sendMessage(ChatColor.YELLOW + "§e" + SmallCapsConverter.convert("Author:") + " §fSharpKingYT");
        sender.sendMessage(ChatColor.YELLOW + "§e" + SmallCapsConverter.convert("API Version:") + " §f1.21");
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GRAY + "§7" + SmallCapsConverter.convert("A comprehensive mace recipe management system"));
        sender.sendMessage(ChatColor.GRAY + "§7" + SmallCapsConverter.convert("with GUI-based configuration for server operators."));
        sender.sendMessage("");
        sender.sendMessage(ChatColor.GREEN + "§a" + SmallCapsConverter.convert("Recipe System:") + " §f" + (plugin.getConfig().getBoolean("recipe.enabled") ? "§a§l" + SmallCapsConverter.convert("ENABLED") : "§c§l" + SmallCapsConverter.convert("DISABLED")));
        sender.sendMessage(ChatColor.GOLD + "§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        
        if (sender instanceof Player) {
            plugin.getSoundManager().playSound((Player) sender, "command-execute");
        }
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            List<String> subcommands = Arrays.asList("setrecipe", "set", "viewrecipe", "view", "reload", "help", "info", "toggle", "reset");
            String input = args[0].toLowerCase();
            
            for (String subcommand : subcommands) {
                if (subcommand.startsWith(input)) {
                    completions.add(subcommand);
                }
            }
        }
        
        return completions;
    }
}