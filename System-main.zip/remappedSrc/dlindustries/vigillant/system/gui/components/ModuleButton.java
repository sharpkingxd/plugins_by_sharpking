package dlindustries.vigillant.system.gui.components;

import dlindustries.vigillant.system.gui.components.settings.*;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.*;
import dlindustries.vigillant.system.utils.*;
import net.minecraft.client.gui.DrawContext;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public final class ModuleButton {
	public List<RenderableSetting> settings = new ArrayList<>();
	public Object parent;
	public Module module;
	public int offset;
	public boolean extended;
	public int settingOffset;
	public Color currentColor;
	public Color defaultColor = new Color(200, 200, 200, 128);
	public Color currentAlpha;
	public AnimationUtils animation = new AnimationUtils(0);

	public ModuleButton(Object parent, Module module, int offset) {
		this.parent = parent;
		this.module = module;
		this.offset = offset;
		this.extended = false;

		for (Setting<?> setting : module.getSettings()) {
			if (setting instanceof BooleanSetting) {
				settings.add(new CheckBox(this, setting, this.settingOffset));
			} else if (setting instanceof NumberSetting) {
				settings.add(new Slider(this, setting, this.settingOffset));
			} else if (setting instanceof ModeSetting) {
				settings.add(new ModeBox(this, setting, this.settingOffset));
			} else if (setting instanceof KeybindSetting) {
				settings.add(new KeybindBox(this, setting, this.settingOffset));
			} else if (setting instanceof StringSetting) {
				settings.add(new StringBox(this, setting, this.settingOffset));
			} else if (setting instanceof MinMaxSetting) {
				settings.add(new MinMaxSlider(this, setting, this.settingOffset));
			}
			settingOffset += 20;
		}
	}

	public void render(DrawContext context, int mouseX, int mouseY, float delta) {

	}

	public void mouseClicked(double mouseX, double mouseY, int button) {

	}

	public void mouseReleased(double mouseX, double mouseY, int button) {

	}

	public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {

	}

	public void keyPressed(int keyCode, int scanCode, int modifiers) {

	}

	public void onGuiClose() {

	}

	public void onExtend() {

		this.extended = true;
	}
}
