package me.pipewasxd.strengthsmp;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class AxeUltimate implements Listener {
   private final StrengthSMP plugin;
   private final WeaponManager weaponManager;
   private final StrengthManager strengthManager;
   private final Map<UUID, UUID> lastHitTarget = new HashMap();
   private final Map<UUID, Integer> targetHitCount = new HashMap();
   private final Map<UUID, Long> lastHitTime = new HashMap();
   private final Map<UUID, Boolean> ultimateActive = new HashMap();
   private final Map<UUID, Boolean> ultimateReadyToRelease = new HashMap();
   private final Map<UUID, Double> storedDamage = new HashMap();
   private final Map<UUID, Long> ultimateCooldown = new HashMap();
   private final Map<UUID, BukkitRunnable> cooldownTasks = new HashMap();
   private final Map<UUID, BukkitRunnable> soundTasks = new HashMap();

   public AxeUltimate(StrengthSMP plugin, WeaponManager weaponManager, StrengthManager strengthManager) {
      this.plugin = plugin;
      this.weaponManager = weaponManager;
      this.strengthManager = strengthManager;
      ((PluginCommand)Objects.requireNonNull(plugin.getCommand("ability"))).setExecutor(this::onAbilityCommand);
   }

   @EventHandler
   public void onAxeHit(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         Entity var4 = event.getEntity();
         if (var4 instanceof LivingEntity target) {
            if (this.isAxe(attacker.getInventory().getItemInMainHand().getType())) {
               if (this.weaponManager.getPlayerWeapon(attacker) == WeaponType.AXE) {
                  if (this.strengthManager.isAtMaxStrength(attacker)) {
                     UUID attackerUUID = attacker.getUniqueId();
                     UUID targetUUID = target.getUniqueId();
                     long currentTime = System.currentTimeMillis();
                     if ((Boolean)this.ultimateReadyToRelease.getOrDefault(attackerUUID, false) && target instanceof Player) {
                        Double stored = (Double)this.storedDamage.get(attackerUUID);
                        if (stored != null && stored > (double)0.0F) {
                           double cappedDamage = Math.min(stored, event.getDamage() * (double)2.0F);
                           event.setDamage(cappedDamage);
                           this.storedDamage.put(attackerUUID, (double)0.0F);
                           this.ultimateReadyToRelease.put(attackerUUID, false);
                           Location targetLoc = target.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
                           target.getWorld().spawnParticle(Particle.END_ROD, targetLoc, 50, (double)0.0F, (double)0.0F, (double)0.0F, 0.3);
                           target.getWorld().spawnParticle(Particle.FIREWORK, targetLoc, 100, (double)0.5F, (double)0.5F, (double)0.5F, 0.2);

                           for(Player nearby : target.getWorld().getPlayers()) {
                              if (nearby.getLocation().distance(targetLoc) <= (double)30.0F) {
                                 nearby.playSound(targetLoc, Sound.BLOCK_RESPAWN_ANCHOR_DEPLETE, 1.0F, 1.5F);
                              }
                           }

                           return;
                        }
                     }

                     if ((Boolean)this.ultimateActive.getOrDefault(attackerUUID, false)) {
                        Long lastHit = (Long)this.lastHitTime.get(attackerUUID);
                        if (lastHit != null && currentTime - lastHit < 500L) {
                           event.setDamage(event.getDamage() * 0.05);
                        } else {
                           this.lastHitTime.put(attackerUUID, currentTime);
                           if (target instanceof Player) {
                              double damage = event.getDamage();
                              this.storedDamage.put(attackerUUID, (Double)this.storedDamage.getOrDefault(attackerUUID, (double)0.0F) + damage);
                              event.setDamage(damage * 0.05);
                              attacker.playSound(attacker.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 0.6F, 1.4F);
                           }

                        }
                     } else {
                        if (event.isCritical() && target instanceof Player) {
                           UUID lastTarget = (UUID)this.lastHitTarget.get(attackerUUID);
                           if (lastTarget != null && lastTarget.equals(targetUUID)) {
                              int hits = (Integer)this.targetHitCount.getOrDefault(attackerUUID, 0) + 1;
                              this.targetHitCount.put(attackerUUID, hits);
                              if (hits >= 5) {
                                 this.applyStun(target);
                                 this.targetHitCount.put(attackerUUID, 0);
                                 this.lastHitTarget.remove(attackerUUID);

                                 for(Player nearby : attacker.getWorld().getPlayers()) {
                                    if (nearby.getLocation().distance(attacker.getLocation()) <= (double)20.0F) {
                                       nearby.playSound(attacker.getLocation(), Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0F, 0.8F);
                                       nearby.playSound(attacker.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1.0F, 1.0F);
                                    }
                                 }
                              }
                           } else {
                              this.lastHitTarget.put(attackerUUID, targetUUID);
                              this.targetHitCount.put(attackerUUID, 1);
                           }
                        }

                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onSwapHands(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (player.isSneaking()) {
         if (this.isAxe(player.getInventory().getItemInMainHand().getType())) {
            if (this.weaponManager.getPlayerWeapon(player) == WeaponType.AXE) {
               if (this.strengthManager.isAtMaxStrength(player)) {
                  UUID uuid = player.getUniqueId();
                  event.setCancelled(true);
                  if (!(Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
                     if (!this.isOnCooldown(player)) {
                        this.activateUltimate(player);
                     }
                  }
               }
            }
         }
      }
   }

   public boolean onAbilityCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!this.isAxe(player.getInventory().getItemInMainHand().getType())) {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#808080:#A9A9A9>ʏᴏᴜ ᴍᴜsᴛ ʜᴏʟᴅ ᴀɴ ᴀxᴇ ᴛᴏ ᴜsᴇ ᴛʜɪs!</gradient></bold>"));
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6F, 1.2F);
            return true;
         } else if (this.weaponManager.getPlayerWeapon(player) != WeaponType.AXE) {
            return true;
         } else if (!this.strengthManager.isAtMaxStrength(player)) {
            return true;
         } else {
            UUID uuid = player.getUniqueId();
            if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
               return true;
            } else if (this.isOnCooldown(player)) {
               return true;
            } else {
               this.activateUltimate(player);
               return true;
            }
         }
      } else {
         sender.sendMessage("Only players can use this command.");
         return true;
      }
   }

   public void activateUltimate(final Player player) {
      final UUID uuid = player.getUniqueId();
      this.ultimateActive.put(uuid, true);
      this.storedDamage.put(uuid, (double)0.0F);
      this.lastHitTime.remove(uuid);
      player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#8B0000:#B22222>ᴜʟᴛɪᴍᴀᴛᴇ ᴀᴄᴛɪᴠᴀᴛᴇᴅ</gradient></bold>"));
      player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1.0F, 0.8F);

      for(LivingEntity entity : player.getWorld().getNearbyLivingEntities(player.getLocation(), (double)30.0F, (double)10.0F, (double)30.0F)) {
         if (!entity.equals(player) && entity instanceof Player) {
            entity.getWorld().playSound(entity.getLocation(), Sound.ENTITY_ELDER_GUARDIAN_CURSE, 1.0F, 1.0F);
         }
      }

      BukkitRunnable soundTask = new BukkitRunnable() {
         int ticks = 0;

         public void run() {
            if (this.ticks < 5 && (Boolean)AxeUltimate.this.ultimateActive.getOrDefault(uuid, false)) {
               Location loc = player.getLocation();

               for(Player nearbyPlayer : player.getWorld().getPlayers()) {
                  if (nearbyPlayer.getLocation().distance(loc) <= (double)30.0F) {
                     nearbyPlayer.playSound(loc, Sound.ENTITY_ELDER_GUARDIAN_CURSE, 0.8F, 1.5F);
                  }
               }

               ++this.ticks;
            } else {
               this.cancel();
            }
         }
      };
      soundTask.runTaskTimer(this.plugin, 0L, 20L);
      this.soundTasks.put(uuid, soundTask);
      (new BukkitRunnable() {
         public void run() {
            BukkitRunnable task = (BukkitRunnable)AxeUltimate.this.soundTasks.remove(uuid);
            if (task != null) {
               task.cancel();
            }

            AxeUltimate.this.deactivateUltimate(player);
         }
      }).runTaskLater(this.plugin, 100L);
   }

   private void deactivateUltimate(final Player player) {
      final UUID uuid = player.getUniqueId();
      if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
         this.ultimateActive.put(uuid, false);
         this.ultimateReadyToRelease.put(uuid, true);
         this.ultimateCooldown.put(uuid, System.currentTimeMillis() + 60000L);
         player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#A9A9A9:#D3D3D3>ᴏɴ ᴄᴏᴏʟᴅᴏᴡɴ</gradient></bold>"));
         player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5F, 1.0F);
         BukkitRunnable cooldownTask = new BukkitRunnable() {
            public void run() {
               player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#006400:#008000>ᴜʟᴛɪᴍᴀᴛᴇ ʀᴇᴀᴅʏ</gradient></bold>"));
               player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
               AxeUltimate.this.cooldownTasks.remove(uuid);
            }
         };
         cooldownTask.runTaskLater(this.plugin, 1200L);
         this.cooldownTasks.put(uuid, cooldownTask);
      }
   }

   private void applyStun(final LivingEntity target) {
      final Location freezeLocation = target.getLocation().clone();
      (new BukkitRunnable() {
         int ticks = 0;
         final int maxTicks = 60;

         public void run() {
            if (this.ticks < 60 && target.isValid() && !target.isDead()) {
               target.teleport(freezeLocation);
               ++this.ticks;
            } else {
               this.cancel();
            }
         }
      }).runTaskTimer(this.plugin, 0L, 1L);
   }

   public boolean isOnCooldown(Player player) {
      Long cooldownEnd = (Long)this.ultimateCooldown.get(player.getUniqueId());
      return cooldownEnd != null && System.currentTimeMillis() < cooldownEnd;
   }

   private boolean isAxe(Material material) {
      boolean var10000;
      switch (material) {
         case WOODEN_AXE:
         case STONE_AXE:
         case IRON_AXE:
         case GOLDEN_AXE:
         case DIAMOND_AXE:
         case NETHERITE_AXE:
            var10000 = true;
            break;
         default:
            var10000 = false;
      }

      return var10000;
   }
}
