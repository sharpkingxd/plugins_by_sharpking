/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package me.astral.strengthmain;

import me.astral.strengthmain.StrengthMain;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StrengthCommand
implements CommandExecutor {
    private final StrengthMain plugin;

    public StrengthCommand(StrengthMain plugin) {
        this.plugin = plugin;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            Player player = (Player)sender;
            double strength = this.plugin.getStrengthMultiplierForPlayer(player);
            player.sendMessage("Your current strength level is: " + strength);
        } else {
            sender.sendMessage("Only players can use this command.");
        }
        return true;
    }
}

