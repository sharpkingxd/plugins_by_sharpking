package com.infusesmp.data;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DataManager {
    
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, PlayerData> playerDataMap;
    private File dataFile;
    private FileConfiguration dataConfig;
    
    public DataManager(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.playerDataMap = new HashMap<>();
        
        setupDataFile();
        loadAllData();
        startAutoSaveTask();
    }
    
    private void setupDataFile() {
        dataFile = new File(plugin.getDataFolder(), "playerdata.yml");
        if (!dataFile.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                dataFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create playerdata.yml file: " + e.getMessage());
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
    }
    
    public PlayerData getPlayerData(UUID playerId) {
        return playerDataMap.computeIfAbsent(playerId, PlayerData::new);
    }
    
    public void savePlayerData(UUID playerId) {
        PlayerData data = playerDataMap.get(playerId);
        if (data == null) return;
        
        String basePath = playerId.toString();
        
        // Save potions
        dataConfig.set(basePath + ".primary_potion", 
                data.getPrimaryPotion() != null ? data.getPrimaryPotion().name() : null);
        dataConfig.set(basePath + ".secondary_potion", 
                data.getSecondaryPotion() != null ? data.getSecondaryPotion().name() : null);
        
        // Save enabled states
        dataConfig.set(basePath + ".primary_enabled", data.isPrimaryEnabled());
        dataConfig.set(basePath + ".secondary_enabled", data.isSecondaryEnabled());
        
        // Save active slot
        dataConfig.set(basePath + ".active_slot", 
                data.getActiveSlot() != null ? data.getActiveSlot().name() : null);
        
        // Save trusted players
        if (!data.getTrustedPlayers().isEmpty()) {
            dataConfig.set(basePath + ".trusted_players", 
                    data.getTrustedPlayers().stream().map(UUID::toString).toList());
        } else {
            dataConfig.set(basePath + ".trusted_players", null);
        }
        
        saveDataFile();
    }
    
    private void loadAllData() {
        for (String playerIdStr : dataConfig.getKeys(false)) {
            try {
                UUID playerId = UUID.fromString(playerIdStr);
                PlayerData data = new PlayerData(playerId);
                
                // Load primary potion
                String primaryStr = dataConfig.getString(playerIdStr + ".primary_potion");
                if (primaryStr != null && !primaryStr.equals("null")) {
                    try {
                        data.setPrimaryPotion(PotionType.valueOf(primaryStr));
                    } catch (IllegalArgumentException ignored) {}
                }
                
                // Load secondary potion
                String secondaryStr = dataConfig.getString(playerIdStr + ".secondary_potion");
                if (secondaryStr != null && !secondaryStr.equals("null")) {
                    try {
                        data.setSecondaryPotion(PotionType.valueOf(secondaryStr));
                    } catch (IllegalArgumentException ignored) {}
                }
                
                // Load enabled states
                data.setPrimaryEnabled(dataConfig.getBoolean(playerIdStr + ".primary_enabled", false));
                data.setSecondaryEnabled(dataConfig.getBoolean(playerIdStr + ".secondary_enabled", false));
                
                // Load active slot
                String activeSlotStr = dataConfig.getString(playerIdStr + ".active_slot");
                if (activeSlotStr != null && !activeSlotStr.equals("null")) {
                    try {
                        data.setActiveSlot(PotionType.valueOf(activeSlotStr));
                    } catch (IllegalArgumentException ignored) {}
                }
                
                // Load trusted players
                if (dataConfig.contains(playerIdStr + ".trusted_players")) {
                    for (String trustedIdStr : dataConfig.getStringList(playerIdStr + ".trusted_players")) {
                        try {
                            UUID trustedId = UUID.fromString(trustedIdStr);
                            data.addTrustedPlayer(trustedId);
                        } catch (IllegalArgumentException ignored) {}
                    }
                }
                
                playerDataMap.put(playerId, data);
            } catch (IllegalArgumentException e) {
                // Invalid UUID, skip
            }
        }
    }
    
    public void saveAllData() {
        for (UUID playerId : playerDataMap.keySet()) {
            savePlayerData(playerId);
        }
    }
    
    private void saveDataFile() {
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save player data: " + e.getMessage());
        }
    }
    
    private void startAutoSaveTask() {
        int saveInterval = plugin.getConfig().getInt("storage.save_interval", 300) * 20; // Convert to ticks
        
        new BukkitRunnable() {
            @Override
            public void run() {
                saveAllData();
            }
        }.runTaskTimerAsynchronously(plugin, saveInterval, saveInterval);
    }
    
    public void removePlayerData(UUID playerId) {
        playerDataMap.remove(playerId);
        String playerIdStr = playerId.toString();
        dataConfig.set(playerIdStr, null);
        saveDataFile();
    }
    
    public void clearPlayerPotions(Player player) {
        PlayerData data = getPlayerData(player.getUniqueId());
        
        // Clear effects
        if (data.getPrimaryPotion() != null) {
            plugin.getEffectManager().disablePassiveEffects(player, data.getPrimaryPotion());
        }
        if (data.getSecondaryPotion() != null) {
            plugin.getEffectManager().disablePassiveEffects(player, data.getSecondaryPotion());
        }
        
        // Clear data
        data.setPrimaryPotion(null);
        data.setSecondaryPotion(null);
        data.setPrimaryEnabled(false);
        data.setSecondaryEnabled(false);
        data.setActiveSlot(null);
        
        // Update HUD
        plugin.getInfuseHUD().updateHUD(player);
        
        // Save
        savePlayerData(player.getUniqueId());
    }
}
