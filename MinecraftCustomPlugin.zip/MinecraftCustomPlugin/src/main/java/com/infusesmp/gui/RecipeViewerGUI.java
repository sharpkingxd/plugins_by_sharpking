package com.infusesmp.gui;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import com.infusesmp.utils.ItemUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class RecipeViewerGUI implements Listener {
    
    private final InfuseSMPPlugin plugin;
    private final Player player;
    private Inventory currentInventory;
    private boolean isMainMenu = true;
    private final UUID playerUUID;
    
    public RecipeViewerGUI(InfuseSMPPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.playerUUID = player.getUniqueId();
        
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    public void openMainMenu() {
        isMainMenu = true;
        currentInventory = Bukkit.createInventory(null, 54, 
                Component.text("Infuse Potion Recipes").color(NamedTextColor.DARK_PURPLE));
        
        setupMainMenu();
        player.openInventory(currentInventory);
    }
    
    private void setupMainMenu() {
        // Fill with filler items
        ItemStack filler = ItemUtil.createFillerItem();
        for (int i = 0; i < 54; i++) {
            currentInventory.setItem(i, filler);
        }
        
        // Add potion items
        PotionType[] potions = PotionType.values();
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24};
        
        for (int i = 0; i < Math.min(potions.length, slots.length); i++) {
            PotionType type = potions[i];
            ItemStack potionItem = plugin.getPotionManager().createPotionItem(type);
            
            if (potionItem != null) {
                currentInventory.setItem(slots[i], potionItem);
            }
        }
    }
    
    public void openRecipeView(PotionType potionType) {
        isMainMenu = false;
        currentInventory = Bukkit.createInventory(null, 54, 
                Component.text(potionType.getDisplayName() + " Recipe").color(NamedTextColor.DARK_PURPLE));
        
        setupRecipeView(potionType);
        player.openInventory(currentInventory);
    }
    
    private void setupRecipeView(PotionType potionType) {
        // Fill with filler items
        ItemStack filler = ItemUtil.createFillerItem();
        for (int i = 0; i < 54; i++) {
            currentInventory.setItem(i, filler);
        }
        
        // Get recipe
        ItemStack[][] recipe = plugin.getPotionManager().getRecipe(potionType);
        if (recipe == null) return;
        
        // Display recipe in crafting grid pattern
        int[] recipeSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        int index = 0;
        
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                ItemStack item = recipe[row][col];
                if (item != null && item.getType() != Material.AIR) {
                    currentInventory.setItem(recipeSlots[index], item);
                }
                index++;
            }
        }
        
        // Show result
        ItemStack result = plugin.getPotionManager().createPotionItem(potionType);
        currentInventory.setItem(24, result);
        
        // Back button
        ItemStack backButton = ItemUtil.createGuiItem(Material.ARROW, 
                "Back to Recipe List", 
                List.of("Return to the main recipe menu"));
        currentInventory.setItem(45, backButton);
        
        // Info item
        ItemStack infoItem = ItemUtil.createGuiItem(Material.BOOK, 
                "Recipe Information", 
                Arrays.asList(
                        "This recipe can only be crafted",
                        "in an Infuse Potion Crafter",
                        "(renamed brewing stand)",
                        "",
                        "Brewing takes 15 minutes",
                        "Coordinates leak every 5 minutes"
                ));
        currentInventory.setItem(49, infoItem);
    }
    
    @EventHandler(ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getInventory().equals(currentInventory)) return;
        if (!(event.getWhoClicked() instanceof Player clickingPlayer)) return;
        if (!clickingPlayer.getUniqueId().equals(playerUUID)) return;
        
        // Cancel the event immediately to prevent any item movement
        event.setCancelled(true);
        
        // Additional safety: prevent MOVE_TO_OTHER_INVENTORY and COLLECT_TO_CURSOR actions
        InventoryAction action = event.getAction();
        if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY || 
            action == InventoryAction.COLLECT_TO_CURSOR) {
            return;
        }
        
        int slot = event.getRawSlot();
        ItemStack clicked = event.getCurrentItem();
        
        if (clicked == null || clicked.getType() == Material.AIR) return;
        
        if (isMainMenu) {
            // Check if clicked item is a potion
            com.infusesmp.potion.PotionType potionType = 
                    com.infusesmp.potion.InfusePotion.getPotionType(clicked);
            
            if (potionType != null) {
                openRecipeView(potionType);
            }
        } else {
            // Recipe view
            if (slot == 45) { // Back button
                openMainMenu();
            }
        }
    }
    
    // Add handler for inventory drag events
    @EventHandler(ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getInventory().equals(currentInventory)) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!event.getInventory().equals(currentInventory)) return;
        if (!(event.getPlayer() instanceof Player closingPlayer)) return;
        if (!closingPlayer.getUniqueId().equals(playerUUID)) return;
        
        // Schedule a task to check and remove any items that might have been taken
        new BukkitRunnable() {
            @Override
            public void run() {
                // Check player's inventory for any potion items that might have been taken
                Player p = Bukkit.getPlayer(playerUUID);
                if (p != null && p.isOnline()) {
                    for (ItemStack item : p.getInventory().getContents()) {
                        if (item != null && com.infusesmp.potion.InfusePotion.isInfusePotion(item)) {
                            // If this item was obtained in the last second, it might be from the GUI
                            // Remove it to prevent duplication
                            p.getInventory().remove(item);
                            p.sendMessage(Component.text("⚠ Items from the recipe viewer cannot be taken!").color(NamedTextColor.RED));
                        }
                    }
                }
            }
        }.runTaskLater(plugin, 1L); // Run 1 tick later
        
        // Unregister listener
        InventoryClickEvent.getHandlerList().unregister(this);
        InventoryDragEvent.getHandlerList().unregister(this);
        InventoryCloseEvent.getHandlerList().unregister(this);
    }
}
