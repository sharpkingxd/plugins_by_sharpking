package dlindustries.vigillant.system.utils;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.VertexSorter;
import com.mojang.blaze3d.vertex.VertexFormat;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

import java.awt.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static dlindustries.vigillant.system.system.mc;

public final class RenderUtils {
	public static void fillWithAlpha(DrawContext context, int x1, int y1, int x2, int y2, int color) {
		boolean depthTestWasEnabled = GL11.glGetBoolean(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDisable(GL11.GL_DEPTH_TEST);

		int a = (color >> 24) & 0xFF;
		int r = (color >> 16) & 0xFF;
		int g = (color >> 8) & 0xFF;
		int b = color & 0xFF;

		float alpha = a / 255f;
		float red = r / 255f;
		float green = g / 255f;
		float blue = b / 255f;

		MatrixStack matrices = new MatrixStack();
		Tessellator tessellator = Tessellator.getInstance();
		BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

		Matrix4f matrix = matrices.peek().getPositionMatrix();
		buffer.vertex(matrix, x1, y2, 0).color(red, green, blue, alpha);
		buffer.vertex(matrix, x2, y2, 0).color(red, green, blue, alpha);
		buffer.vertex(matrix, x2, y1, 0).color(red, green, blue, alpha);
		buffer.vertex(matrix, x1, y1, 0).color(red, green, blue, alpha);

		buffer.end();

		if (depthTestWasEnabled) {
			GL11.glEnable(GL11.GL_DEPTH_TEST);
		} else {
			GL11.glDisable(GL11.GL_DEPTH_TEST);
		}
	}
	public static VertexSorter vertexSorter;
	public static boolean rendering3D = true;

	public static Vec3d getCameraPos() {
		return mc.getBlockEntityRenderDispatcher().new Vec3d(camera.getX(), camera.getY(), camera.getZ());
	}

	public static double deltaTime() {
		return mc.getCurrentFps() > 0 ? (1.0000 / mc.getCurrentFps()) : 1;
	}

	public static float fast(float end, float start, float multiple) {
		return (1 - MathHelper.clamp((float) (deltaTime() * multiple), 0, 1)) * end + MathHelper.clamp((float) (deltaTime() * multiple), 0, 1) * start;
	}

	public static Vec3d getPlayerLookVec(PlayerEntity player) {
		float f = 0.017453292F;
		float pi = 3.1415927F;
		float f1 = MathHelper.cos(-player.getYaw() * f - pi);
		float f2 = MathHelper.sin(-player.getYaw() * f - pi);
		float f3 = -MathHelper.cos(-player.getPitch() * f);
		float f4 = MathHelper.sin(-player.getPitch() * f);
		return (new Vec3d((f2 * f3), f4, (f1 * f3))).normalize();
	}

	public static void unscaledProjection() {
		vertexSorter = VertexSorter.BY_Z;
		rendering3D = false;
	}

	public static void scaledProjection() {
		rendering3D = true;
	}

	public static void renderRoundedQuad(MatrixStack matrices, Color c, double x, double y, double x2, double y2, double corner1, double corner2, double corner3, double corner4, double samples) {
		int color = c.getRGB();
		Matrix4f matrix = matrices.peek().getPositionMatrix();
		float f = (float) (color >> 24 & 255) / 255.0F;
		float g = (float) (color >> 16 & 255) / 255.0F;
		float h = (float) (color >> 8 & 255) / 255.0F;
		float k = (float) (color & 255) / 255.0F;

		boolean blendWasEnabled = GL11.glGetBoolean(GL11.GL_BLEND);
		boolean depthTestWasEnabled = GL11.glGetBoolean(GL11.GL_DEPTH_TEST);

		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDisable(GL11.GL_DEPTH_TEST);

		renderRoundedQuadInternal(matrix, g, h, k, f, x, y, x2, y2, corner1, corner2, corner3, corner4, samples);

		if (depthTestWasEnabled) {
			GL11.glEnable(GL11.GL_DEPTH_TEST);
		}
	}

	private static void setup() {
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
	}

	private static void cleanup() {
		GL11.glEnable(GL11.GL_CULL_FACE);
	}

	private static java.lang.reflect.Method cachedShaderMethod = null;
	private static Boolean cachedShaderIsStatic = null;

	private static void setupPositionColorShader() {
		try {
			MinecraftClient client = MinecraftClient.getInstance();
			if (client == null || client.gameRenderer == null) return;

			if (cachedShaderMethod != null && cachedShaderIsStatic != null) {
				try {
					final java.lang.reflect.Method finalShaderMethod = cachedShaderMethod;
					final boolean finalIsStatic = cachedShaderIsStatic;
					final net.minecraft.client.render.GameRenderer finalGameRenderer = client.gameRenderer;

					java.util.function.Supplier<?> shaderSupplier = () -> {
						try {
							return finalIsStatic ? finalShaderMethod.invoke(null) : finalShaderMethod.invoke(finalGameRenderer);
						} catch (Exception e) {

							cachedShaderMethod = null;
							cachedShaderIsStatic = null;
							return null;
						}
					};

					java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
					setShaderMethod.invoke(null, shaderSupplier);
					return;
				} catch (Exception e) {
					cachedShaderMethod = null;
					cachedShaderIsStatic = null;
				}
			}

			java.lang.reflect.Method shaderMethod = null;
			boolean isStatic = false;

			java.lang.reflect.Method[] allMethods = net.minecraft.client.render.GameRenderer.class.getDeclaredMethods();
			for (java.lang.reflect.Method m : allMethods) {
				if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
					Class<?> returnType = m.getReturnType();
					String returnTypeName = returnType.getName();
					if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
						returnTypeName.startsWith("net.minecraft.client.gl.")) {
						m.setAccessible(true);
						shaderMethod = m;
						isStatic = true;
						break;
					}
				}
			}

			if (shaderMethod == null && client.gameRenderer != null) {
				allMethods = client.gameRenderer.getClass().getDeclaredMethods();
				for (java.lang.reflect.Method m : allMethods) {
					if (!java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
						Class<?> returnType = m.getReturnType();
						String returnTypeName = returnType.getName();
						if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
							returnTypeName.startsWith("net.minecraft.client.gl.")) {
							m.setAccessible(true);
							shaderMethod = m;
							isStatic = false;
							break;
						}
					}
				}
			}

			if (shaderMethod != null) {
				cachedShaderMethod = shaderMethod;
				cachedShaderIsStatic = isStatic;

				final java.lang.reflect.Method finalShaderMethod = shaderMethod;
				final boolean finalIsStatic = isStatic;
				final net.minecraft.client.render.GameRenderer finalGameRenderer = client.gameRenderer;

					java.util.function.Supplier<?> shaderSupplier = () -> {
						try {
							return finalIsStatic ? finalShaderMethod.invoke(null) : finalShaderMethod.invoke(finalGameRenderer);
						} catch (Exception e) {
							cachedShaderMethod = null;
						cachedShaderIsStatic = null;
						return null;
					}
				};

				java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
				setShaderMethod.invoke(null, shaderSupplier);
			}
		} catch (Exception ex) {
			cachedShaderMethod = null;
			cachedShaderIsStatic = null;
		}
	}

	public static void renderRoundedQuad(MatrixStack matrices, Color c, double x, double y, double x1, double y1, double rad, double samples) {
		renderRoundedQuad(matrices, c, x, y, x1, y1, rad, rad, rad, rad, samples);
	}

	public static void drawRoundedOutline(DrawContext context, int x, int y, int width, int height, double radius, double outlineWidth, Color color) {
		renderRoundedOutline(context, color, x, y, x + width, y + height, radius, radius, radius, radius, outlineWidth, 20);
	}

	public static void renderRoundedOutlineInternal(Matrix4f matrix, float cr, float cg, float cb, float ca, double fromX, double fromY, double toX, double toY, double radC1, double radC2, double radC3, double radC4, double width, double samples) {
		BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);

		double[][] map = new double[][]{new double[]{toX - radC4, toY - radC4, radC4}, new double[]{toX - radC2, fromY + radC2, radC2},
				new double[]{fromX + radC1, fromY + radC1, radC1}, new double[]{fromX + radC3, toY - radC3, radC3}};
		for (int i = 0; i < 4; i++) {
			double[] current = map[i];
			double rad = current[2];
			for (double r = i * 90d; r < (360 / 4d + i * 90d); r += (90 / samples)) {
				float rad1 = (float) Math.toRadians(r);
				double sin1 = Math.sin(rad1);
				float sin = (float) (sin1 * rad);
				double cos1 = Math.cos(rad1);
				float cos = (float) (cos1 * rad);
				bufferBuilder.vertex(matrix, (float) current[0] + sin, (float) current[1] + cos, 0.0F).color(cr, cg, cb, ca);
				bufferBuilder.vertex(matrix, (float) (current[0] + sin + sin1 * width), (float) (current[1] + cos + cos1 * width), 0.0F).color(cr, cg, cb, ca);
			}
			float rad1 = (float) Math.toRadians((360 / 4d + i * 90d));
			double sin1 = Math.sin(rad1);
			float sin = (float) (sin1 * rad);
			double cos1 = Math.cos(rad1);
			float cos = (float) (cos1 * rad);
			bufferBuilder.vertex(matrix, (float) current[0] + sin, (float) current[1] + cos, 0.0F).color(cr, cg, cb, ca);
			bufferBuilder.vertex(matrix, (float) (current[0] + sin + sin1 * width), (float) (current[1] + cos + cos1 * width), 0.0F).color(cr, cg, cb, ca);
		}
		int i = 0;
		double[] current = map[i];
		double rad = current[2];
		float cos = (float) (rad);
		bufferBuilder.vertex(matrix, (float) current[0], (float) current[1] + cos, 0.0F).color(cr, cg, cb, ca);
		bufferBuilder.vertex(matrix, (float) (current[0]), (float) (current[1] + cos + width), 0.0F).color(cr, cg, cb, ca);

		setupPositionColorShader();
		bufferBuilder.end();
	}
	public static void renderFilledBox(MatrixStack matrices, Box box, Color color) {
		renderFilledBox(matrices,
				(float) box.minX, (float) box.minY, (float) box.minZ,
				(float) box.maxX, (float) box.maxY, (float) box.maxZ,
				color);
	}

	public static void renderFilledBox(MatrixStack matrices, float minX, float minY, float minZ,
									   float maxX, float maxY, float maxZ, Color color) {
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDisable(GL11.GL_CULL_FACE);

		float r = color.getRed() / 255f;
		float g = color.getGreen() / 255f;
		float b = color.getBlue() / 255f;
		float a = color.getAlpha() / 255f;

		Tessellator tessellator = Tessellator.getInstance();
		BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

		MatrixStack.Entry entry = matrices.peek();
		Matrix4f matrix = entry.getPositionMatrix();

		buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);

		buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);

		buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);

		buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);

		buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);

		buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);

		buffer.end();
	}

	public static void renderOutlinedBox(MatrixStack matrices, Box box, Color color) {
		renderOutlinedBox(matrices,
				(float) box.minX, (float) box.minY, (float) box.minZ,
				(float) box.maxX, (float) box.maxY, (float) box.maxZ,
				color);
	}

	public static void renderOutlinedBox(MatrixStack matrices, float minX, float minY, float minZ,
										 float maxX, float maxY, float maxZ, Color color) {
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

		float r = color.getRed() / 255f;
		float g = color.getGreen() / 255f;
		float b = color.getBlue() / 255f;
		float a = color.getAlpha() / 255f;

		Tessellator tessellator = Tessellator.getInstance();
		BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

		MatrixStack.Entry entry = matrices.peek();
		Matrix4f matrix = entry.getPositionMatrix();
		buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);

		buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);

		buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);

		buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);

		buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);

		buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);

		buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, minZ).color(r, g, b, a);

		buffer.vertex(matrix, maxX, minY, minZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, minZ).color(r, g, b, a);

		buffer.vertex(matrix, maxX, minY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, maxX, maxY, maxZ).color(r, g, b, a);

		buffer.vertex(matrix, minX, minY, maxZ).color(r, g, b, a);
		buffer.vertex(matrix, minX, maxY, maxZ).color(r, g, b, a);

		buffer.end();

		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDisable(GL11.GL_BLEND);
	}

	public static void renderCircle(MatrixStack matrices, Color c, double originX, double originY, double rad, int segments) {
		int segments1 = MathHelper.clamp(segments, 4, 360);
		int color = c.getRGB();

		Matrix4f matrix = matrices.peek().getPositionMatrix();
		float f = (float) (color >> 24 & 255) / 255.0F;
		float g = (float) (color >> 16 & 255) / 255.0F;
		float h = (float) (color >> 8 & 255) / 255.0F;
		float k = (float) (color & 255) / 255.0F;
		setup();
		BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
		for (int i = 0; i < 360; i += Math.min(360 / segments1, 360 - i)) {
			double radians = Math.toRadians(i);
			double sin = Math.sin(radians) * rad;
			double cos = Math.cos(radians) * rad;
			bufferBuilder.vertex(matrix, (float) (originX + sin), (float) (originY + cos), 0).color(g, h, k, f);
		}
		setupPositionColorShader();
		bufferBuilder.end();
		cleanup();
	}

	public static void renderRoundedOutline(DrawContext poses, Color c, double fromX, double fromY, double toX, double toY, double rad1, double rad2, double rad3, double rad4, double width, double samples) {
		int color = c.getRGB();
		MatrixStack matrices = new MatrixStack();
		Matrix4f matrix = matrices.peek().getPositionMatrix();
		float f = (float) (color >> 24 & 255) / 255.0F;
		float g = (float) (color >> 16 & 255) / 255.0F;
		float h = (float) (color >> 8 & 255) / 255.0F;
		float k = (float) (color & 255) / 255.0F;
		setup();
		renderRoundedOutlineInternal(matrix, g, h, k, f, fromX, fromY, toX, toY, rad1, rad2, rad3, rad4, width, samples);
		cleanup();
	}

	public static void renderRoundedQuadInternal(Matrix4f matrix, float cr, float cg, float cb, float ca, double fromX, double fromY, double toX, double toY, double corner1, double corner2, double corner3, double corner4, double samples) {
		BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);

		double[][] map = new double[][]{new double[]{toX - corner4, toY - corner4, corner4}, new double[]{toX - corner2, fromY + corner2, corner2},
				new double[]{fromX + corner1, fromY + corner1, corner1}, new double[]{fromX + corner3, toY - corner3, corner3}};
		for (int i = 0; i < 4; i++) {
			double[] current = map[i];
			double rad = current[2];
			for (double r = i * 90d; r < (360 / 4d + i * 90d); r += (90 / samples)) {
				float rad1 = (float) Math.toRadians(r);
				float sin = (float) (Math.sin(rad1) * rad);
				float cos = (float) (Math.cos(rad1) * rad);
				bufferBuilder.vertex(matrix, (float) current[0] + sin, (float) current[1] + cos, 0.0F).color(cr, cg, cb, ca);
			}
			float rad1 = (float) Math.toRadians((360 / 4d + i * 90d));
			float sin = (float) (Math.sin(rad1) * rad);
			float cos = (float) (Math.cos(rad1) * rad);
			bufferBuilder.vertex(matrix, (float) current[0] + sin, (float) current[1] + cos, 0.0F).color(cr, cg, cb, ca);
		}

		setupPositionColorShader();
		bufferBuilder.end();
	}

	public static void renderBox(MatrixStack matrices, Box box, Color sideColor, Color lineColor,
	                             boolean renderSides, boolean renderLines) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.gameRenderer == null || client.gameRenderer.getCamera() == null) return;

		Vec3d camPos = new Vec3d(client.gameRenderer.getCamera().getX(), client.gameRenderer.getCamera().getY(), client.gameRenderer.getCamera().getZ());

		float minX = (float) (box.minX - camPos.x);
		float minY = (float) (box.minY - camPos.y);
		float minZ = (float) (box.minZ - camPos.z);
		float maxX = (float) (box.maxX - camPos.x);
		float maxY = (float) (box.maxY - camPos.y);
		float maxZ = (float) (box.maxZ - camPos.z);

		Matrix4f matrix = matrices.peek().getPositionMatrix();

		if (renderSides) {
			float sr = sideColor.getRed() / 255f;
			float sg = sideColor.getGreen() / 255f;
			float sb = sideColor.getBlue() / 255f;
			float sa = sideColor.getAlpha() / 255f;

			Tessellator tessellator = Tessellator.getInstance();
			BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

			buffer.vertex(matrix, minX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, minY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, minZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, minX, maxY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, maxZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, minX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, minZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, minX, minY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, maxZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, minX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, minY, maxZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, maxX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, minZ).color(sr, sg, sb, sa);

			try {
				java.lang.reflect.Method shaderMethod = null;
				boolean isStatic = false;

				java.lang.reflect.Method[] allMethods = net.minecraft.client.render.GameRenderer.class.getDeclaredMethods();
				for (java.lang.reflect.Method m : allMethods) {
					if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
						Class<?> returnType = m.getReturnType();
						String returnTypeName = returnType.getName();
						if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
							returnTypeName.startsWith("net.minecraft.client.gl.")) {
							m.setAccessible(true);
							shaderMethod = m;
							isStatic = true;
							break;
						}
					}
				}

				if (shaderMethod == null && client.gameRenderer != null) {
					allMethods = client.gameRenderer.getClass().getDeclaredMethods();
					for (java.lang.reflect.Method m : allMethods) {
						if (!java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
							Class<?> returnType = m.getReturnType();
							String returnTypeName = returnType.getName();
							if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
								returnTypeName.startsWith("net.minecraft.client.gl.")) {
								m.setAccessible(true);
								shaderMethod = m;
								isStatic = false;
								break;
							}
						}
					}
				}

				if (shaderMethod != null) {
					final java.lang.reflect.Method finalShaderMethod = shaderMethod;
					final boolean finalIsStatic = isStatic;
					final net.minecraft.client.render.GameRenderer finalGameRenderer = client.gameRenderer;

					java.util.function.Supplier<?> shaderSupplier = () -> {
						try {
							return finalIsStatic ? finalShaderMethod.invoke(null) : finalShaderMethod.invoke(finalGameRenderer);
						} catch (Exception e) {
							return null;
						}
					};

					java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
					setShaderMethod.invoke(null, shaderSupplier);
				}
			} catch (Exception ex) {
			}

			buffer.end();
		}

		if (renderLines) {
			float lr = lineColor.getRed() / 255f;
			float lg = lineColor.getGreen() / 255f;
			float lb = lineColor.getBlue() / 255f;
			float la = lineColor.getAlpha() / 255f;

			Tessellator tessellator = Tessellator.getInstance();
			BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

			buffer.vertex(matrix, minX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, minY, minZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, maxX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, minY, maxZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, maxX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, minY, maxZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, minX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, minY, minZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, minX, maxY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, minZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, maxX, maxY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, maxX, maxY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, maxZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, minX, maxY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, minZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, minX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, minZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, maxX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, minZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, maxX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, minX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, maxZ).color(lr, lg, lb, la);

			try {
				java.lang.reflect.Method shaderMethod = null;
				boolean isStatic = false;

				java.lang.reflect.Method[] allMethods = net.minecraft.client.render.GameRenderer.class.getDeclaredMethods();
				for (java.lang.reflect.Method m : allMethods) {
					if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
						Class<?> returnType = m.getReturnType();
						String returnTypeName = returnType.getName();
						if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
							returnTypeName.startsWith("net.minecraft.client.gl.")) {
							m.setAccessible(true);
							shaderMethod = m;
							isStatic = true;
							break;
						}
					}
				}

				if (shaderMethod == null && client.gameRenderer != null) {
					allMethods = client.gameRenderer.getClass().getDeclaredMethods();
					for (java.lang.reflect.Method m : allMethods) {
						if (!java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
							Class<?> returnType = m.getReturnType();
							String returnTypeName = returnType.getName();
							if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
								returnTypeName.startsWith("net.minecraft.client.gl.")) {
								m.setAccessible(true);
								shaderMethod = m;
								isStatic = false;
								break;
							}
						}
					}
				}

				if (shaderMethod != null) {
					final java.lang.reflect.Method finalShaderMethod = shaderMethod;
					final boolean finalIsStatic = isStatic;
					final net.minecraft.client.render.GameRenderer finalGameRenderer = client.gameRenderer;

					java.util.function.Supplier<?> shaderSupplier = () -> {
						try {
							return finalIsStatic ? finalShaderMethod.invoke(null) : finalShaderMethod.invoke(finalGameRenderer);
						} catch (Exception e) {
							return null;
						}
					};

					java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
					setShaderMethod.invoke(null, shaderSupplier);
				}
			} catch (Exception ex) {
			}

			buffer.end();
		}
	}

	public static void renderBox(MatrixStack matrices, float minX, float minY, float minZ,
								 float maxX, float maxY, float maxZ,
								 Color sideColor, Color lineColor, boolean renderSides, boolean renderLines) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.gameRenderer == null) return;

		MatrixStack.Entry entry = matrices.peek();
		Matrix4f matrix = entry.getPositionMatrix();

		if (renderSides) {
			float sr = sideColor.getRed() / 255f;
			float sg = sideColor.getGreen() / 255f;
			float sb = sideColor.getBlue() / 255f;
			float sa = sideColor.getAlpha() / 255f;

			Tessellator tessellator = Tessellator.getInstance();
			BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

			buffer.vertex(matrix, minX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, minY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, minZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, minX, maxY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, maxZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, minX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, minZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, minX, minY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, maxZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, minX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, minX, minY, maxZ).color(sr, sg, sb, sa);

			buffer.vertex(matrix, maxX, minY, minZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, minY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(sr, sg, sb, sa);
			buffer.vertex(matrix, maxX, maxY, minZ).color(sr, sg, sb, sa);

			try {
				java.lang.reflect.Method shaderMethod = null;
				boolean isStatic = false;

				java.lang.reflect.Method[] allMethods = net.minecraft.client.render.GameRenderer.class.getDeclaredMethods();
				for (java.lang.reflect.Method m : allMethods) {
					if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
						Class<?> returnType = m.getReturnType();
						String returnTypeName = returnType.getName();
						if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
							returnTypeName.startsWith("net.minecraft.client.gl.")) {
							m.setAccessible(true);
							shaderMethod = m;
							isStatic = true;
							break;
						}
					}
				}

				if (shaderMethod == null && client.gameRenderer != null) {
					allMethods = client.gameRenderer.getClass().getDeclaredMethods();
					for (java.lang.reflect.Method m : allMethods) {
						if (!java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
							Class<?> returnType = m.getReturnType();
							String returnTypeName = returnType.getName();
							if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
								returnTypeName.startsWith("net.minecraft.client.gl.")) {
								m.setAccessible(true);
								shaderMethod = m;
								isStatic = false;
								break;
							}
						}
					}
				}

				if (shaderMethod != null) {
					final java.lang.reflect.Method finalShaderMethod = shaderMethod;
					final boolean finalIsStatic = isStatic;
					final net.minecraft.client.render.GameRenderer finalGameRenderer = client.gameRenderer;

					java.util.function.Supplier<?> shaderSupplier = () -> {
						try {
							return finalIsStatic ? finalShaderMethod.invoke(null) : finalShaderMethod.invoke(finalGameRenderer);
						} catch (Exception e) {
							return null;
						}
					};

					java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
					setShaderMethod.invoke(null, shaderSupplier);
				}
			} catch (Exception ex) {
			}

			buffer.end();
		}

		if (renderLines) {
			float lr = lineColor.getRed() / 255f;
			float lg = lineColor.getGreen() / 255f;
			float lb = lineColor.getBlue() / 255f;
			float la = lineColor.getAlpha() / 255f;

			Tessellator tessellator = Tessellator.getInstance();
			BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

			buffer.vertex(matrix, minX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, minY, minZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, minX, maxY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, minZ).color(lr, lg, lb, la);

			buffer.vertex(matrix, minX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, minY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, minZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, maxX, maxY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, minY, maxZ).color(lr, lg, lb, la);
			buffer.vertex(matrix, minX, maxY, maxZ).color(lr, lg, lb, la);

			try {
				java.lang.reflect.Method shaderMethod = null;
				boolean isStatic = false;

				java.lang.reflect.Method[] allMethods = net.minecraft.client.render.GameRenderer.class.getDeclaredMethods();
				for (java.lang.reflect.Method m : allMethods) {
					if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
						Class<?> returnType = m.getReturnType();
						String returnTypeName = returnType.getName();
						if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
							returnTypeName.startsWith("net.minecraft.client.gl.")) {
							m.setAccessible(true);
							shaderMethod = m;
							isStatic = true;
							break;
						}
					}
				}

				if (shaderMethod == null && client.gameRenderer != null) {
					allMethods = client.gameRenderer.getClass().getDeclaredMethods();
					for (java.lang.reflect.Method m : allMethods) {
						if (!java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
							Class<?> returnType = m.getReturnType();
							String returnTypeName = returnType.getName();
							if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
								returnTypeName.startsWith("net.minecraft.client.gl.")) {
								m.setAccessible(true);
								shaderMethod = m;
								isStatic = false;
								break;
							}
						}
					}
				}

				if (shaderMethod != null) {
					final java.lang.reflect.Method finalShaderMethod = shaderMethod;
					final boolean finalIsStatic = isStatic;
					final net.minecraft.client.render.GameRenderer finalGameRenderer = client.gameRenderer;

					java.util.function.Supplier<?> shaderSupplier = () -> {
						try {
							return finalIsStatic ? finalShaderMethod.invoke(null) : finalShaderMethod.invoke(finalGameRenderer);
						} catch (Exception e) {
							return null;
						}
					};

					java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
					setShaderMethod.invoke(null, shaderSupplier);
				}
			} catch (Exception ex) {
			}

			buffer.end();
		}
	}

	public static void renderLine(MatrixStack matrices, Vec3d startWorld, Vec3d endWorld, Color color) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.gameRenderer == null || client.gameRenderer.getCamera() == null) return;

		Vec3d camPos = new Vec3d(client.gameRenderer.getCamera().getX(), client.gameRenderer.getCamera().getY(), client.gameRenderer.getCamera().getZ());
		Vec3d s = startWorld.subtract(camPos);
		Vec3d e = endWorld.subtract(camPos);

		float r = color.getRed() / 255f;
		float g = color.getGreen() / 255f;
		float b = color.getBlue() / 255f;
		float a = color.getAlpha() / 255f;

		Tessellator tessellator = Tessellator.getInstance();
		BufferBuilder buffer = tessellator.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

		Matrix4f matrix = matrices.peek().getPositionMatrix();
		buffer.vertex(matrix, (float) s.x, (float) s.y, (float) s.z).color(r, g, b, a);
		buffer.vertex(matrix, (float) e.x, (float) e.y, (float) e.z).color(r, g, b, a);

		try {
			java.lang.reflect.Method shaderMethod = null;
			boolean isStatic = false;

			java.lang.reflect.Method[] allMethods = net.minecraft.client.render.GameRenderer.class.getDeclaredMethods();
			for (java.lang.reflect.Method m : allMethods) {
				if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
					Class<?> returnType = m.getReturnType();
					String returnTypeName = returnType.getName();
					if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
						returnTypeName.startsWith("net.minecraft.client.gl.")) {
						m.setAccessible(true);
						shaderMethod = m;
						isStatic = true;
						break;
					}
				}
			}

			if (shaderMethod == null && client.gameRenderer != null) {
				allMethods = client.gameRenderer.getClass().getDeclaredMethods();
				for (java.lang.reflect.Method m : allMethods) {
					if (!java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
						Class<?> returnType = m.getReturnType();
						String returnTypeName = returnType.getName();
						if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
							returnTypeName.startsWith("net.minecraft.client.gl.")) {
							m.setAccessible(true);
							shaderMethod = m;
							isStatic = false;
							break;
						}
					}
				}
			}

			if (shaderMethod != null) {
				final java.lang.reflect.Method finalShaderMethod = shaderMethod;
				final boolean finalIsStatic = isStatic;
				final net.minecraft.client.render.GameRenderer finalGameRenderer = client.gameRenderer;

				java.util.function.Supplier<?> shaderSupplier = () -> {
					try {
						return finalIsStatic ? finalShaderMethod.invoke(null) : finalShaderMethod.invoke(finalGameRenderer);
					} catch (Exception ex2) {
						return null;
					}
				};

				java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
				setShaderMethod.invoke(null, shaderSupplier);
			}
		} catch (Exception ex) {
		}

		buffer.end();
	}
}
