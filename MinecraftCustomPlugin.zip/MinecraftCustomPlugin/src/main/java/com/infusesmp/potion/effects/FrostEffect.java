package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData; // Add this import
import com.infusesmp.potion.PotionType;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.*;

public class FrostEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Integer> hitCounter = new HashMap<>();
    private final Map<UUID, Long> sparkEndTimes = new HashMap<>();
    private static final int HITS_FOR_FREEZE = 10;
    private static final int FREEZE_DURATION = 60; // 3 seconds (60 ticks)
    private static final double SPEED_MULTIPLIER = 1.5;
    private static final long SPARK_DURATION = 30 * 1000; // 30 seconds in milliseconds

    public FrostEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void activatePassive(Player player) {
        hitCounter.put(player.getUniqueId(), 0);
    }

    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        hitCounter.remove(playerId);
        sparkEndTimes.remove(playerId);
    }

    @Override
    public void useSpark(Player player) {
        if (!hasEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Frost effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        sparkEndTimes.put(playerId, System.currentTimeMillis() + SPARK_DURATION);
        
        // Visual and sound effects
        player.playSound(player.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.0f, 1.0f);
        player.sendMessage(Component.text("❄️ Frost Spark activated!")
                .color(NamedTextColor.AQUA));
    }

    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        Entity target = event.getEntity();
    
        // Check if target is a trusted player
        if (target instanceof Player targetPlayer) {
            PlayerData playerData = plugin.getDataManager().getPlayerData(attacker.getUniqueId());
            if (playerData.isTrustedPlayer(targetPlayer.getUniqueId())) {
                // Skip effects for trusted players
                return;
            }
        }
    
        // Check if spark is active
        if (isSparkActive(attackerId)) {
            if (target instanceof LivingEntity livingTarget) {
                freezeTarget(livingTarget);
                
                // Reduce jump height
                if (target instanceof Player) {
                    ((Player) target).addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 60, -2));
                }
            }
            return;
        }

        // Handle regular attacks
        if (target instanceof Monster) {
            // Freeze mobs on every hit
            freezeTarget((LivingEntity) target);
        } else if (target instanceof Player) {
            // Increment hit counter for player targets
            int hits = hitCounter.getOrDefault(attackerId, 0) + 1;
            
            if (hits >= HITS_FOR_FREEZE) {
                hits = 0;
                freezeTarget((LivingEntity) target);
            }
            
            hitCounter.put(attackerId, hits);
        }
    }

    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // No special defense handling needed
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        
        if (!hasEffect(player)) return;
        
        Block block = player.getLocation().getBlock();
        Material blockType = block.getType();
        
        // Handle ice and snow speed boost
        if (blockType == Material.ICE || 
            blockType == Material.PACKED_ICE || 
            blockType == Material.BLUE_ICE ||
            blockType == Material.SNOW ||
            blockType == Material.SNOW_BLOCK) {
            
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 1, false, false));
        }
        
        // Handle powdered snow
        if (blockType == Material.POWDER_SNOW) {
            // Allow flying through powdered snow
            player.setAllowFlight(true);
            player.setFlying(true);
            
            // Schedule flight disable when leaving powdered snow
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (player.getLocation().getBlock().getType() != Material.POWDER_SNOW) {
                    player.setAllowFlight(false);
                    player.setFlying(false);
                }
            }, 1L);
        }
    }

    private void freezeTarget(LivingEntity target) {
        // Apply slowness and mining fatigue
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, FREEZE_DURATION, 4));
        target.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, FREEZE_DURATION, 4));
        
        // Visual and sound effects
        target.getWorld().playSound(target.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.0f, 1.0f);
        
        if (target instanceof Player) {
            ((Player) target).sendMessage(Component.text("❄️ You've been frozen!")
                    .color(NamedTextColor.AQUA));
        }
    }

    private boolean isSparkActive(UUID playerId) {
        Long endTime = sparkEndTimes.get(playerId);
        return endTime != null && System.currentTimeMillis() < endTime;
    }

    private boolean hasEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.FROST && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.FROST && data.isSecondaryEnabled());
    }
}
