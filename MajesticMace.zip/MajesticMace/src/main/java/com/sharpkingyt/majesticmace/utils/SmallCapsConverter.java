package com.sharpkingyt.majesticmace.utils;

public class SmallCapsConverter {
    
    private static final String NORMAL = "abcdefghijklmnopqrstuvwxyz";
    private static final String SMALL_CAPS = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ";
    
    public static String convert(String text) {
        if (text == null) return null;
        
        StringBuilder result = new StringBuilder();
        for (char c : text.toCharArray()) {
            int index = NORMAL.indexOf(Character.toLowerCase(c));
            if (index != -1) {
                result.append(SMALL_CAPS.charAt(index));
            } else {
                result.append(c);
            }
        }
        return result.toString();
    }
}