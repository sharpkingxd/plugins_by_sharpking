package me.pipewasxd.strengthsmp;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;

public class ShieldUltimate implements Listener {
   private final StrengthSMP plugin;
   private final WeaponManager weaponManager;
   private final StrengthManager strengthManager;
   private final Map<UUID, Boolean> ultimateActive = new HashMap();
   private final Map<UUID, Long> ultimateCooldown = new HashMap();
   private final Map<UUID, BukkitRunnable> cooldownTasks = new HashMap();
   private final Map<UUID, BukkitRunnable> particleTasks = new HashMap();
   private final Map<UUID, Long> passiveActiveUntil = new HashMap();
   private final Map<UUID, Long> lastShieldDisable = new HashMap();

   public ShieldUltimate(StrengthSMP plugin, WeaponManager weaponManager, StrengthManager strengthManager) {
      this.plugin = plugin;
      this.weaponManager = weaponManager;
      this.strengthManager = strengthManager;
   }

   public boolean onAbilityCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (this.weaponManager.getPlayerWeapon(player) != WeaponType.SHIELD) {
            return true;
         } else if (!this.strengthManager.isAtMaxStrength(player)) {
            return true;
         } else {
            UUID uuid = player.getUniqueId();
            if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
               return true;
            } else if (this.isOnCooldown(player)) {
               long remaining = ((Long)this.ultimateCooldown.get(uuid) - System.currentTimeMillis()) / 1000L;
               return true;
            } else {
               this.activateUltimate(player);
               return true;
            }
         }
      } else {
         sender.sendMessage("Only players can use this command.");
         return true;
      }
   }

   @EventHandler
   public void onShieldDisable(EntityDamageByEntityEvent event) {
      Entity var3 = event.getEntity();
      if (var3 instanceof Player victim) {
         if (event.getDamager() instanceof Player) {
            if (this.weaponManager.getPlayerWeapon(victim) == WeaponType.SHIELD) {
               if (this.strengthManager.isAtMaxStrength(victim)) {
                  if (victim.getInventory().getItemInMainHand().getType() == Material.SHIELD || victim.getInventory().getItemInOffHand().getType() == Material.SHIELD) {
                     if (victim.hasCooldown(Material.SHIELD)) {
                        UUID uuid = victim.getUniqueId();
                        Long lastDisable = (Long)this.lastShieldDisable.get(uuid);
                        long currentTime = System.currentTimeMillis();
                        if (lastDisable == null || currentTime - lastDisable > 1000L) {
                           this.lastShieldDisable.put(uuid, currentTime);
                           this.activatePassive(victim);
                        }
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onDamage(EntityDamageEvent event) {
      Entity var3 = event.getEntity();
      if (var3 instanceof Player player) {
         UUID var5 = player.getUniqueId();
         if ((Boolean)this.ultimateActive.getOrDefault(var5, false)) {
            event.setCancelled(true);
         } else {
            Long passiveEnd = (Long)this.passiveActiveUntil.get(var5);
            if (passiveEnd != null && System.currentTimeMillis() < passiveEnd) {
               event.setDamage(event.getDamage() * (double)0.75F);
            }

         }
      }
   }

   private void activatePassive(final Player player) {
      UUID uuid = player.getUniqueId();
      final long endTime = System.currentTimeMillis() + 5000L;
      this.passiveActiveUntil.put(uuid, endTime);
      player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0F, 1.5F);
      BukkitRunnable passiveParticles = new BukkitRunnable() {
         public void run() {
            if (System.currentTimeMillis() < endTime && player.isOnline()) {
               player.getWorld().spawnParticle(Particle.ENCHANT, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 5, 0.3, (double)0.5F, 0.3, 0.1);
            } else {
               this.cancel();
            }
         }
      };
      passiveParticles.runTaskTimer(this.plugin, 0L, 10L);
   }

   @EventHandler
   public void onSwapHands(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (player.isSneaking()) {
         if (this.weaponManager.getPlayerWeapon(player) == WeaponType.SHIELD) {
            if (this.strengthManager.isAtMaxStrength(player)) {
               UUID uuid = player.getUniqueId();
               event.setCancelled(true);
               if (!(Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
                  if (!this.isOnCooldown(player)) {
                     this.activateUltimate(player);
                  }
               }
            }
         }
      }
   }

   private void activateUltimate(final Player player) {
      final UUID uuid = player.getUniqueId();
      this.ultimateActive.put(uuid, true);
      player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#8B0000:#B22222>ᴜʟᴛɪᴍᴀᴛᴇ ᴀᴄᴛɪᴠᴀᴛᴇᴅ</gradient></bold>"));
      player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1.0F, 0.8F);
      BukkitRunnable particleTask = new BukkitRunnable() {
         public void run() {
            if ((Boolean)ShieldUltimate.this.ultimateActive.getOrDefault(uuid, false) && player.isOnline()) {
               ShieldUltimate.this.spawnHitboxOutline(player);
            } else {
               this.cancel();
            }
         }
      };
      particleTask.runTaskTimer(this.plugin, 0L, 2L);
      this.particleTasks.put(uuid, particleTask);
      (new BukkitRunnable() {
         public void run() {
            ShieldUltimate.this.deactivateUltimate(player);
         }
      }).runTaskLater(this.plugin, 300L);
   }

   private void spawnHitboxOutline(Player player) {
      BoundingBox box = player.getBoundingBox();
      World world = player.getWorld();
      double minX = box.getMinX();
      double minY = box.getMinY();
      double minZ = box.getMinZ();
      double maxX = box.getMaxX();
      double maxY = box.getMaxY();
      double maxZ = box.getMaxZ();
      double step = 0.15;
      this.drawLine(world, minX, minY, minZ, maxX, minY, minZ, step, true);
      this.drawLine(world, maxX, minY, minZ, maxX, minY, maxZ, step, false);
      this.drawLine(world, maxX, minY, maxZ, minX, minY, maxZ, step, true);
      this.drawLine(world, minX, minY, maxZ, minX, minY, minZ, step, false);
      this.drawLine(world, minX, maxY, minZ, maxX, maxY, minZ, step, true);
      this.drawLine(world, maxX, maxY, minZ, maxX, maxY, maxZ, step, false);
      this.drawLine(world, maxX, maxY, maxZ, minX, maxY, maxZ, step, true);
      this.drawLine(world, minX, maxY, maxZ, minX, maxY, minZ, step, false);
      this.drawLine(world, minX, minY, minZ, minX, maxY, minZ, step, true);
      this.drawLine(world, maxX, minY, minZ, maxX, maxY, minZ, step, false);
      this.drawLine(world, maxX, minY, maxZ, maxX, maxY, maxZ, step, true);
      this.drawLine(world, minX, minY, maxZ, minX, maxY, maxZ, step, false);
   }

   private void drawLine(World world, double x1, double y1, double z1, double x2, double y2, double z2, double step, boolean isFirst) {
      double distance = Math.sqrt(Math.pow(x2 - x1, (double)2.0F) + Math.pow(y2 - y1, (double)2.0F) + Math.pow(z2 - z1, (double)2.0F));
      double dx = (x2 - x1) / distance;
      double dy = (y2 - y1) / distance;
      double dz = (z2 - z1) / distance;

      for(double d = (double)0.0F; d <= distance; d += step) {
         Location particleLoc = new Location(world, x1 + dx * d, y1 + dy * d, z1 + dz * d);
         Particle.DustOptions cyanData = new Particle.DustOptions(Color.fromRGB(0, 255, 255), 0.75F);
         world.spawnParticle(Particle.DUST, particleLoc, 1, cyanData);
      }

   }

   private void deactivateUltimate(final Player player) {
      final UUID uuid = player.getUniqueId();
      if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
         BukkitRunnable particleTask = (BukkitRunnable)this.particleTasks.remove(uuid);
         if (particleTask != null) {
            particleTask.cancel();
         }

         this.ultimateActive.put(uuid, false);
         this.ultimateCooldown.put(uuid, System.currentTimeMillis() + 120000L);
         player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#A9A9A9:#D3D3D3>ᴏɴ ᴄᴏᴏʟᴅᴏᴡɴ</gradient></bold>"));
         player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5F, 1.0F);
         BukkitRunnable cooldownTask = new BukkitRunnable() {
            public void run() {
               player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#006400:#008000>ᴜʟᴛɪᴍᴀᴛᴇ ʀᴇᴀᴅʏ</gradient></bold>"));
               player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
               ShieldUltimate.this.cooldownTasks.remove(uuid);
            }
         };
         cooldownTask.runTaskLater(this.plugin, 2400L);
         this.cooldownTasks.put(uuid, cooldownTask);
      }
   }

   private boolean isOnCooldown(Player player) {
      Long cooldownEnd = (Long)this.ultimateCooldown.get(player.getUniqueId());
      if (cooldownEnd == null) {
         return false;
      } else {
         return System.currentTimeMillis() < cooldownEnd;
      }
   }
}
