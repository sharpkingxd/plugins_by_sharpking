package me.pipewasxd.strengthsmp;

import org.bukkit.Material;

public record ConfigManager(StrengthSMP plugin) {
   public ConfigManager(StrengthSMP plugin) {
      this.plugin = plugin;
      plugin.getConfig().addDefault("max-strength", 5);
      plugin.getConfig().addDefault("min-strength", 1);
      plugin.getConfig().addDefault("default-strength", 3);
      plugin.getConfig().addDefault("recipe.strength.top-left", "ENCHANTED_GOLDEN_APPLE");
      plugin.getConfig().addDefault("recipe.strength.top", "NETHERITE_INGOT");
      plugin.getConfig().addDefault("recipe.strength.top-right", "ENCHANTED_GOLDEN_APPLE");
      plugin.getConfig().addDefault("recipe.strength.left", "NETHERITE_INGOT");
      plugin.getConfig().addDefault("recipe.strength.center", "NETHER_STAR");
      plugin.getConfig().addDefault("recipe.strength.right", "NETHERITE_INGOT");
      plugin.getConfig().addDefault("recipe.strength.bottom-left", "ENCHANTED_GOLDEN_APPLE");
      plugin.getConfig().addDefault("recipe.strength.bottom", "NETHERITE_INGOT");
      plugin.getConfig().addDefault("recipe.strength.bottom-right", "ENCHANTED_GOLDEN_APPLE");
      plugin.getConfig().addDefault("recipe.reroll.top-left", "DIAMOND_BLOCK");
      plugin.getConfig().addDefault("recipe.reroll.top", "NETHERITE_HOE");
      plugin.getConfig().addDefault("recipe.reroll.top-right", "DIAMOND_BLOCK");
      plugin.getConfig().addDefault("recipe.reroll.left", "ECHO_SHARD");
      plugin.getConfig().addDefault("recipe.reroll.center", "WITHER_SKELETON_SKULL");
      plugin.getConfig().addDefault("recipe.reroll.right", "ECHO_SHARD");
      plugin.getConfig().addDefault("recipe.reroll.bottom-left", "DIAMOND_BLOCK");
      plugin.getConfig().addDefault("recipe.reroll.bottom", "TRIDENT");
      plugin.getConfig().addDefault("recipe.reroll.bottom-right", "DIAMOND_BLOCK");
      plugin.getConfig().options().copyDefaults(true);
      plugin.saveConfig();
   }

   public int getMaxStrength() {
      return this.plugin.getConfig().getInt("max-strength", 5);
   }

   public int getMinStrength() {
      return this.plugin.getConfig().getInt("min-strength", 1);
   }

   public int getDefaultStrength() {
      return this.plugin.getConfig().getInt("default-strength", 3);
   }

   private Material getRecipeMaterial(String recipePath) {
      String material = this.plugin.getConfig().getString(recipePath, "AIR");

      try {
         return Material.valueOf(material.toUpperCase());
      } catch (IllegalArgumentException var4) {
         this.plugin.getLogger().warning("Invalid recipe material at " + recipePath + ": " + material + ", using AIR");
         return Material.AIR;
      }
   }

   public Material getRecipeTopLeft() {
      return this.getRecipeMaterial("recipe.strength.top-left");
   }

   public Material getRecipeTop() {
      return this.getRecipeMaterial("recipe.strength.top");
   }

   public Material getRecipeTopRight() {
      return this.getRecipeMaterial("recipe.strength.top-right");
   }

   public Material getRecipeLeft() {
      return this.getRecipeMaterial("recipe.strength.left");
   }

   public Material getRecipeCenter() {
      return this.getRecipeMaterial("recipe.strength.center");
   }

   public Material getRecipeRight() {
      return this.getRecipeMaterial("recipe.strength.right");
   }

   public Material getRecipeBottomLeft() {
      return this.getRecipeMaterial("recipe.strength.bottom-left");
   }

   public Material getRecipeBottom() {
      return this.getRecipeMaterial("recipe.strength.bottom");
   }

   public Material getRecipeBottomRight() {
      return this.getRecipeMaterial("recipe.strength.bottom-right");
   }

   public Material getRerollRecipeTopLeft() {
      return this.getRecipeMaterial("recipe.reroll.top-left");
   }

   public Material getRerollRecipeTop() {
      return this.getRecipeMaterial("recipe.reroll.top");
   }

   public Material getRerollRecipeTopRight() {
      return this.getRecipeMaterial("recipe.reroll.top-right");
   }

   public Material getRerollRecipeLeft() {
      return this.getRecipeMaterial("recipe.reroll.left");
   }

   public Material getRerollRecipeCenter() {
      return this.getRecipeMaterial("recipe.reroll.center");
   }

   public Material getRerollRecipeRight() {
      return this.getRecipeMaterial("recipe.reroll.right");
   }

   public Material getRerollRecipeBottomLeft() {
      return this.getRecipeMaterial("recipe.reroll.bottom-left");
   }

   public Material getRerollRecipeBottom() {
      return this.getRecipeMaterial("recipe.reroll.bottom");
   }

   public Material getRerollRecipeBottomRight() {
      return this.getRecipeMaterial("recipe.reroll.bottom-right");
   }
}
