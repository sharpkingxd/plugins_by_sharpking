package me.pipewasxd.strengthsmp;

import org.bukkit.ChatColor;

public enum WeaponType {
   SWORD(String.valueOf(ChatColor.DARK_RED) + "sᴡᴏʀᴅ"),
   TRIDENT(String.valueOf(ChatColor.DARK_RED) + "ᴛʀɪᴅᴇɴᴛ"),
   AXE(String.valueOf(ChatColor.DARK_RED) + "ᴀxᴇ"),
   SHIELD(String.valueOf(ChatColor.DARK_RED) + "sʜɪᴇʟᴅ"),
   BOW(String.valueOf(ChatColor.DARK_RED) + "ʙᴏᴡ"),
   CROSSBOW(String.valueOf(ChatColor.DARK_RED) + "ᴄʀᴏssʙᴏᴡ");

   private final String displayName;

   private WeaponType(String displayName) {
      this.displayName = displayName;
   }

   public String getDisplayName() {
      return this.displayName;
   }

   public static WeaponType random() {
      WeaponType[] values = values();
      return values[(int)(Math.random() * (double)values.length)];
   }

   public static WeaponType fromString(String name) {
      for(WeaponType type : values()) {
         if (type.name().equalsIgnoreCase(name)) {
            return type;
         }
      }

      return null;
   }

   // $FF: synthetic method
   private static WeaponType[] $values() {
      return new WeaponType[]{SWORD, TRIDENT, AXE, SHIELD, BOW, CROSSBOW};
   }
}
