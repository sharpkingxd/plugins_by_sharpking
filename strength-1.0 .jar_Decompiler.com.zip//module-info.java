/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
module org.jetbrains.annotations {
    requires static java.desktop; // version: 11.0.14.1

    exports org.intellij.lang.annotations;
    exports org.jetbrains.annotations;

}

