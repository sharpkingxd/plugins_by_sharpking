package com.infusesmp.listeners;

import com.infusesmp.InfuseSMPPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class AnvilListener implements Listener {
    
    private final InfuseSMPPlugin plugin;
    private static final String INFUSE_CRAFTER_NAME = "Infuse Potion Crafter";
    
    public AnvilListener(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onPrepareAnvil(PrepareAnvilEvent event) {
        AnvilInventory inventory = event.getInventory();
        ItemStack firstItem = inventory.getFirstItem();
        
        if (firstItem == null || firstItem.getType() != Material.BREWING_STAND) return;
        
        String newName = inventory.getRenameText();
        if (newName == null) return;
        
        // Check if the new name matches our crafter name
        if (INFUSE_CRAFTER_NAME.equals(newName)) {
            // Create the custom crafter item
            ItemStack result = new ItemStack(Material.BREWING_STAND);
            ItemMeta meta = result.getItemMeta();
            
            meta.displayName(Component.text(INFUSE_CRAFTER_NAME)
                    .color(NamedTextColor.DARK_PURPLE));
            
            // Add lore
            meta.lore(java.util.Arrays.asList(
                Component.text("A special brewing stand that")
                    .color(NamedTextColor.GRAY),
                Component.text("can craft Infuse Potions.")
                    .color(NamedTextColor.GRAY),
                Component.empty(),
                Component.text("✨ Place to create an Infuse Potion Crafter")
                    .color(NamedTextColor.LIGHT_PURPLE)
            ));
            
            result.setItemMeta(meta);
            event.setResult(result);
            
            // Set cost to 1 level
            inventory.setRepairCost(1);
        }
    }
} 