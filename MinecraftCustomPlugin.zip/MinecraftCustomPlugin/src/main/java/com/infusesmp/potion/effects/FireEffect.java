package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.data.Levelled;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.*;

public class FireEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Long> sparkEndTimes = new HashMap<>();
    private final Map<UUID, Integer> hitCounter = new HashMap<>();
    private final Map<UUID, Integer> fireDamageLevel = new HashMap<>();
    private static final long SPARK_DURATION = 5 * 1000; // 5 seconds in milliseconds
    private static final double IGNITE_RADIUS = 5.0;
    private static final int HITS_FOR_FIRE = 10;
    private static final int FIRE_TICKS = 100; // 5 seconds
    private static final double LAUNCH_VELOCITY = 1.5;
    private static final Map<Material, Material> SMELTABLE_BLOCKS = new HashMap<>();
    private static final double SPARK_RADIUS = 7.0; // Circle radius for spark
    private static final int SPARK_DURATION_TICKS = 100; // 5 seconds

    static {
        // Initialize smeltable blocks
        SMELTABLE_BLOCKS.put(Material.IRON_ORE, Material.IRON_INGOT);
        SMELTABLE_BLOCKS.put(Material.DEEPSLATE_IRON_ORE, Material.IRON_INGOT);
        SMELTABLE_BLOCKS.put(Material.GOLD_ORE, Material.GOLD_INGOT);
        SMELTABLE_BLOCKS.put(Material.DEEPSLATE_GOLD_ORE, Material.GOLD_INGOT);
        SMELTABLE_BLOCKS.put(Material.COPPER_ORE, Material.COPPER_INGOT);
        SMELTABLE_BLOCKS.put(Material.DEEPSLATE_COPPER_ORE, Material.COPPER_INGOT);
        SMELTABLE_BLOCKS.put(Material.SAND, Material.GLASS);
        SMELTABLE_BLOCKS.put(Material.COBBLESTONE, Material.STONE);
        SMELTABLE_BLOCKS.put(Material.RAW_IRON, Material.IRON_INGOT);
        SMELTABLE_BLOCKS.put(Material.RAW_GOLD, Material.GOLD_INGOT);
        SMELTABLE_BLOCKS.put(Material.RAW_COPPER, Material.COPPER_INGOT);
        SMELTABLE_BLOCKS.put(Material.CLAY, Material.TERRACOTTA);
        // Add more smeltable blocks as needed
    }
    
    public FireEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    @Override
    public void activatePassive(Player player) {
        safeRemoveAndAddFire(player);
        hitCounter.put(player.getUniqueId(), 0);
        fireDamageLevel.put(player.getUniqueId(), 1);
    }
    
    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        sparkEndTimes.remove(playerId);
        hitCounter.remove(playerId);
        fireDamageLevel.remove(playerId);
        PotionEffect effect = player.getPotionEffect(PotionEffectType.FIRE_RESISTANCE);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        }
    }
    
    @Override
    public void useSpark(Player player) {
        if (!hasEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Fire effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        sparkEndTimes.put(playerId, System.currentTimeMillis() + SPARK_DURATION);
        
        // Start ignition effect
        startIgnitionEffect(player);
        
        // Visual and sound effects
        player.playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.5f);
        player.sendMessage(Component.text("🔥 Ignition activated!")
                .color(NamedTextColor.RED));
        
        // Start fire circle visual and effect
        startFireCircleSpark(player);
    }
    
    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        int hits = hitCounter.getOrDefault(attackerId, 0) + 1;
        
        if (hits >= HITS_FOR_FIRE) {
            hits = 0;
            // Set attacker on fire
            attacker.setFireTicks(FIRE_TICKS);
            
            // Visual feedback
            attacker.sendMessage(Component.text("🔥 Self-ignition!")
                    .color(NamedTextColor.RED));
        }
        
        hitCounter.put(attackerId, hits);
    }
    
    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        if (event.getCause() == EntityDamageEvent.DamageCause.FIRE || 
            event.getCause() == EntityDamageEvent.DamageCause.FIRE_TICK ||
            event.getCause() == EntityDamageEvent.DamageCause.LAVA) {
            
            // Increase fire damage level
            UUID defenderId = defender.getUniqueId();
            int currentLevel = fireDamageLevel.getOrDefault(defenderId, 1);
            fireDamageLevel.put(defenderId, currentLevel + 1);
            
            // Apply increased damage
            event.setDamage(event.getDamage() * currentLevel);
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (!hasEffect(player)) return;

        Block block = event.getBlock();
        Material smeltedMaterial = SMELTABLE_BLOCKS.get(block.getType());
        
        if (smeltedMaterial != null) {
            event.setDropItems(false);
            Location dropLoc = block.getLocation().add(0.5, 0.5, 0.5);
            ItemStack smeltedItem = new ItemStack(smeltedMaterial);
            
            // Drop the smelted item
            block.getWorld().dropItemNaturally(dropLoc, smeltedItem);
            
            // Visual and sound effects
            block.getWorld().spawnParticle(Particle.FLAME, dropLoc, 10, 0.2, 0.2, 0.2, 0.05);
            block.getWorld().playSound(dropLoc, Sound.BLOCK_FIRE_EXTINGUISH, 0.5f, 1.0f);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!hasEffect(player)) return;

        Location loc = player.getLocation();
        Block block = loc.getBlock();
        
        // Handle lava swimming
        if (block.getType() == Material.LAVA) {
            player.setVelocity(player.getLocation().getDirection().multiply(0.5));
                }
                
        // Handle water evaporation
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    Block nearby = loc.clone().add(x, y, z).getBlock();
                    if (nearby.getType() == Material.WATER) {
                        nearby.setType(Material.AIR);
                        nearby.getWorld().spawnParticle(Particle.CLOUD, 
                            nearby.getLocation().add(0.5, 0.5, 0.5),
                            10, 0.2, 0.2, 0.2, 0.05);
    }
                }
            }
        }
        
        // Handle lava cauldron fall damage cancellation
        Block blockBelow = loc.clone().subtract(0, 1, 0).getBlock();
        if (blockBelow.getType() == Material.LAVA_CAULDRON) {
            player.setFallDistance(0);
        }
    }
    
    public void handleFireDamage(Player player, EntityDamageEvent event) {
        // Fire effect users are immune to fire/lava damage
            event.setCancelled(true);
        
        // Visual feedback
        player.getWorld().spawnParticle(Particle.FLAME,
            player.getLocation().add(0, 1, 0),
            5, 0.2, 0.5, 0.2, 0.05);
    }
    
    private void startIgnitionEffect(Player player) {
        new BukkitRunnable() {
            private final Location center = player.getLocation();
            private int ticksRemaining = 100; // 5 seconds

            @Override
            public void run() {
                if (!player.isOnline() || !isSparkActive(player.getUniqueId()) || ticksRemaining <= 0) {
                    if (ticksRemaining <= 0 && player.isOnline()) {
                        // Final eruption
                        Collection<Entity> nearbyEntities = player.getWorld().getNearbyEntities(
                            center,
                            IGNITE_RADIUS,
                            IGNITE_RADIUS,
                            IGNITE_RADIUS
                        );

                        for (Entity entity : nearbyEntities) {
                            if (entity instanceof LivingEntity target && entity != player) {
                                // Trust check: skip if trusted player
                                if (target instanceof Player targetPlayer) {
                                    PlayerData playerData = plugin.getDataManager().getPlayerData(player.getUniqueId());
                                    if (playerData.isTrustedPlayer(targetPlayer.getUniqueId())) {
                                        continue;
                                    }
                                }
                                // Launch upward
                                Vector launchVec = new Vector(0, LAUNCH_VELOCITY, 0);
                                target.setVelocity(target.getVelocity().add(launchVec));
                                
                                // Extra fire damage
                                target.setFireTicks(FIRE_TICKS * 2);
                            }
                        }
                        
                        // Visual and sound effects
                        for (int i = 0; i < 3; i++) {
                            player.getWorld().spawnParticle(Particle.FLAME,
                                center.clone().add(
                                    Math.random() * 4 - 2,
                                    Math.random() * 2,
                                    Math.random() * 4 - 2
                                ),
                                20, 0.5, 0.5, 0.5, 0.2);
                        }
                        player.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.5f);
                                }
                    cancel();
                    return;
    }
    
                // Get nearby entities
                Collection<Entity> nearbyEntities = player.getWorld().getNearbyEntities(
                    player.getLocation(),
                    IGNITE_RADIUS,
                    IGNITE_RADIUS,
                    IGNITE_RADIUS
                );

                for (Entity entity : nearbyEntities) {
                    if (entity instanceof LivingEntity target && entity != player) {
                        // Trust check: skip if trusted player
                        if (target instanceof Player targetPlayer) {
                            PlayerData playerData = plugin.getDataManager().getPlayerData(player.getUniqueId());
                            if (playerData.isTrustedPlayer(targetPlayer.getUniqueId())) {
                                continue;
                            }
                        }
                        // Set on fire
                        target.setFireTicks(FIRE_TICKS);
                        
                        // Visual effects
                        target.getWorld().spawnParticle(Particle.FLAME,
                            target.getLocation().add(0, 1, 0),
                            10, 0.2, 0.5, 0.2, 0.05);
                    }
                }

                ticksRemaining--;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private boolean isSparkActive(UUID playerId) {
        Long endTime = sparkEndTimes.get(playerId);
        return endTime != null && System.currentTimeMillis() < endTime;
    }
    
    private boolean hasEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.FIRE && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.FIRE && data.isSecondaryEnabled());
    }

    private void startFireCircleSpark(Player player) {
        UUID playerId = player.getUniqueId();
        Location center = player.getLocation();
        Set<UUID> affected = new HashSet<>();
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline() || ticks > SPARK_DURATION_TICKS) {
                    cancel();
                    return;
                }
                
                // Draw multiple layers of fire particles for a more dramatic effect
                for (int layer = 0; layer < 3; layer++) {
                    double layerHeight = layer * 0.4;
                    
                    // Draw circle of fire particles
                    for (int i = 0; i < 36; i++) {
                        double angle = 2 * Math.PI * i / 36;
                        double x = center.getX() + SPARK_RADIUS * Math.cos(angle);
                        double z = center.getZ() + SPARK_RADIUS * Math.sin(angle);
                        
                        // Main fire circle
                        Location particleLoc = new Location(center.getWorld(), x, center.getY() + layerHeight, z);
                        center.getWorld().spawnParticle(Particle.FLAME, particleLoc, 1, 0.05, 0.05, 0.05, 0.01);
                        
                        // Add some smoke for effect
                        if (i % 4 == 0 && layer == 1) {
                            center.getWorld().spawnParticle(Particle.SMOKE, particleLoc, 1, 0.05, 0.1, 0.05, 0.01);
                        }
                        
                        // Add occasional lava particles for a more intense look
                        if (i % 9 == 0 && layer == 0 && ticks % 5 == 0) {
                            center.getWorld().spawnParticle(Particle.LAVA, particleLoc, 1, 0.1, 0.1, 0.1, 0.01);
                        }
                    }
                }
                
                // Add rising embers from the circle
                if (ticks % 3 == 0) {
                    for (int i = 0; i < 5; i++) {
                        double angle = 2 * Math.PI * Math.random();
                        double distance = SPARK_RADIUS * Math.random();
                        double x = center.getX() + distance * Math.cos(angle);
                        double z = center.getZ() + distance * Math.sin(angle);
                        Location emberLoc = new Location(center.getWorld(), x, center.getY(), z);
                        center.getWorld().spawnParticle(Particle.FLAME, emberLoc, 1, 0.1, 0.5, 0.1, 0.05);
                    }
                }
                
                // Affect entities inside the circle (once per entity)
                for (Entity entity : center.getWorld().getNearbyEntities(center, SPARK_RADIUS, 3, SPARK_RADIUS)) {
                    if (entity instanceof org.bukkit.entity.LivingEntity living && !entity.equals(player)) {
                        double dist = entity.getLocation().distance(center);
                        if (dist <= SPARK_RADIUS && !affected.contains(entity.getUniqueId())) {
                            // Trust check: skip if trusted player
                            if (living instanceof Player targetPlayer) {
                                PlayerData playerData = plugin.getDataManager().getPlayerData(player.getUniqueId());
                                if (playerData.isTrustedPlayer(targetPlayer.getUniqueId())) {
                                    continue;
                                }
                            }
                            living.setFireTicks(100); // 5 seconds fire
                            living.damage(3.0, player); // 1.5 hearts
                            affected.add(entity.getUniqueId());
                        }
                    }
                }
                
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 2L); // Every 2 ticks for smoothness
    }

    private void safeRemoveAndAddFire(Player player) {
        PotionEffect effect = player.getPotionEffect(PotionEffectType.FIRE_RESISTANCE);
        if (effect == null || effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
            player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0));
        }
    }
}
