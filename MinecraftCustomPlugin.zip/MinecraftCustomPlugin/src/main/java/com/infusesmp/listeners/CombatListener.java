package com.infusesmp.listeners;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import com.infusesmp.potion.effects.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;

public class CombatListener implements Listener {
    
    private final InfuseSMPPlugin plugin;
    
    public CombatListener(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        // Handle attacker effects
        if (event.getDamager() instanceof Player attacker) {
            PlayerData attackerData = plugin.getDataManager().getPlayerData(attacker.getUniqueId());
            
            // Process primary potion effects
            if (attackerData.getPrimaryPotion() != null && attackerData.isPrimaryEnabled()) {
                processAttackerEffect(attacker, event, attackerData.getPrimaryPotion());
            }
            
            // Process secondary potion effects
            if (attackerData.getSecondaryPotion() != null && attackerData.isSecondaryEnabled()) {
                processAttackerEffect(attacker, event, attackerData.getSecondaryPotion());
            }
        }
        
        // Handle defender effects
        if (event.getEntity() instanceof Player defender) {
            PlayerData defenderData = plugin.getDataManager().getPlayerData(defender.getUniqueId());
            
            // Process primary potion effects
            if (defenderData.getPrimaryPotion() != null && defenderData.isPrimaryEnabled()) {
                processDefenderEffect(defender, event, defenderData.getPrimaryPotion());
            }
            
            // Process secondary potion effects
            if (defenderData.getSecondaryPotion() != null && defenderData.isSecondaryEnabled()) {
                processDefenderEffect(defender, event, defenderData.getSecondaryPotion());
            }
        }
    }
    
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        
        // Handle fire damage for fire effect
        if (event.getCause() == EntityDamageEvent.DamageCause.FIRE ||
            event.getCause() == EntityDamageEvent.DamageCause.FIRE_TICK ||
            event.getCause() == EntityDamageEvent.DamageCause.LAVA) {
            
            if ((data.getPrimaryPotion() == PotionType.FIRE && data.isPrimaryEnabled()) ||
                (data.getSecondaryPotion() == PotionType.FIRE && data.isSecondaryEnabled())) {
                
                Object handler = plugin.getEffectManager().getEffectHandler(PotionType.FIRE);
                if (handler instanceof FireEffect fireEffect) {
                    fireEffect.handleFireDamage(player, event);
                }
            }
        }
    }
    
    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        
        // Handle emerald effect food consumption
        if ((data.getPrimaryPotion() == PotionType.EMERALD && data.isPrimaryEnabled()) ||
            (data.getSecondaryPotion() == PotionType.EMERALD && data.isSecondaryEnabled())) {
            
            // No need to handle here as EmeraldEffect has its own @EventHandler
            // for PlayerItemConsumeEvent
        }
        
        // Handle heart effect food consumption
        if ((data.getPrimaryPotion() == PotionType.HEART && data.isPrimaryEnabled()) ||
            (data.getSecondaryPotion() == PotionType.HEART && data.isSecondaryEnabled())) {
            
            // No need to handle here as HeartEffect has its own @EventHandler
            // for PlayerItemConsumeEvent
        }
    }
    
    private void processAttackerEffect(Player attacker, EntityDamageByEntityEvent event, PotionType potionType) {
        Object handler = plugin.getEffectManager().getEffectHandler(potionType);
        if (handler == null) return;
        
        switch (potionType) {
            case REGEN -> ((RegenEffect) handler).handleAttack(attacker, event);
            case FEATHER -> ((FeatherEffect) handler).handleAttack(attacker, event);
            case THUNDER -> ((ThunderEffect) handler).handleAttack(attacker, event);
            case STRENGTH -> ((StrengthEffect) handler).handleAttack(attacker, event);
            case HEART -> ((HeartEffect) handler).handleAttack(attacker, event);
            case FROST -> ((FrostEffect) handler).handleAttack(attacker, event);
            case EMERALD -> ((EmeraldEffect) handler).handleAttack(attacker, event);
            case OCEAN -> ((OceanEffect) handler).handleAttack(attacker, event);
            case FIRE -> ((FireEffect) handler).handleAttack(attacker, event);
            case SPEED -> ((SpeedEffect) handler).handleAttack(attacker, event);
            case HASTE -> ((HasteEffect) handler).handleAttack(attacker, event);
            case INVIS -> ((InvisEffect) handler).handleAttack(attacker, event);
        }
    }
    
    private void processDefenderEffect(Player defender, EntityDamageByEntityEvent event, PotionType potionType) {
        Object handler = plugin.getEffectManager().getEffectHandler(potionType);
        if (handler == null) return;
        
        switch (potionType) {
            case REGEN -> ((RegenEffect) handler).handleDefense(defender, event);
            case FEATHER -> ((FeatherEffect) handler).handleDefense(defender, event);
            case THUNDER -> ((ThunderEffect) handler).handleDefense(defender, event);
            case STRENGTH -> ((StrengthEffect) handler).handleDefense(defender, event);
            case HEART -> ((HeartEffect) handler).handleDefense(defender, event);
            case FROST -> ((FrostEffect) handler).handleDefense(defender, event);
            case EMERALD -> ((EmeraldEffect) handler).handleDefense(defender, event);
            case OCEAN -> ((OceanEffect) handler).handleDefense(defender, event);
            case FIRE -> ((FireEffect) handler).handleDefense(defender, event);
            case SPEED -> ((SpeedEffect) handler).handleDefense(defender, event);
            case HASTE -> ((HasteEffect) handler).handleDefense(defender, event);
            case INVIS -> ((InvisEffect) handler).handleDefense(defender, event);
        }
    }
}
