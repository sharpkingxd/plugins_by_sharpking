package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RegenEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private static final long SPARK_DURATION = 12_000; // 12 seconds in milliseconds
    private static final double MAX_HEAL_PER_SPARK = 16.0; // 8 hearts (16 health)
    private static final long HEAL_COOLDOWN = 1000; // 1 second in ms
    private final Map<UUID, Long> sparkEndTimes = new HashMap<>();
    private final Map<UUID, Long> lastHitTimes = new HashMap<>();
    private final Map<UUID, Double> sparkHealAccum = new HashMap<>();
    private final Map<UUID, Long> lastHealTime = new HashMap<>();
    
    public RegenEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    @Override
    public void activatePassive(Player player) {
        // Passive effects are handled through events
    }
    
    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        sparkEndTimes.remove(playerId);
        lastHitTimes.remove(playerId);
        sparkHealAccum.remove(playerId);
        lastHealTime.remove(playerId);
    }
    
    @Override
    public void useSpark(Player player) {
        if (!hasRegenEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Regen effect active!").color(NamedTextColor.RED));
            return;
        }
        // Activate spark effect for 12 seconds
        UUID playerId = player.getUniqueId();
        sparkEndTimes.put(playerId, System.currentTimeMillis() + SPARK_DURATION);
        sparkHealAccum.put(playerId, 0.0);
        player.sendMessage(Component.text("Regen Spark activated! Damage will heal you for 12 seconds! (max 8 hearts)")
                .color(NamedTextColor.GREEN));
    }
    
    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        
        // Check if target is a trusted player
        if (event.getEntity() instanceof Player target) {
            PlayerData playerData = plugin.getDataManager().getPlayerData(attacker.getUniqueId());
            if (playerData.isTrustedPlayer(target.getUniqueId())) {
                // Skip effects for trusted players
                return;
            }
        }
        
        // Check if spark is active
        Long sparkEnd = sparkEndTimes.get(attackerId);
        if (sparkEnd != null && System.currentTimeMillis() < sparkEnd) {
            // Add 1s cooldown between heals
            long now = System.currentTimeMillis();
            Long lastHeal = lastHealTime.getOrDefault(attackerId, 0L);
            if (now - lastHeal < HEAL_COOLDOWN) return;
            lastHealTime.put(attackerId, now);
            // Cap total healing per spark
            double totalHealed = sparkHealAccum.getOrDefault(attackerId, 0.0);
            double damage = event.getFinalDamage();
            double healing = Math.min(damage, attacker.getMaxHealth() - attacker.getHealth());
            if (totalHealed + healing > MAX_HEAL_PER_SPARK) {
                healing = Math.max(0, MAX_HEAL_PER_SPARK - totalHealed);
            }
            if (healing > 0) {
                attacker.setHealth(attacker.getHealth() + healing);
                sparkHealAccum.put(attackerId, totalHealed + healing);
                attacker.sendMessage(Component.text("Healed for " + String.format("%.1f", healing) + " hearts! (" + String.format("%.1f", (MAX_HEAL_PER_SPARK - (totalHealed + healing))) + " left this spark)")
                        .color(NamedTextColor.GREEN));
            }
        }
        
        // Apply Regeneration I for 2 seconds on hit
        lastHitTimes.put(attackerId, System.currentTimeMillis());
        attacker.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 40, 0, false, true));
    }
    
    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // No special defense handling needed
    }
    
    @EventHandler
    public void onEntityRegainHealth(EntityRegainHealthEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        
        // Check if player has regen effect active
        if (hasRegenEffect(player)) {
            // Increase healing by 50%
            event.setAmount(event.getAmount() * 1.5);
        }
    }
    
    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        
        // Check if player has regen effect active
        if (hasRegenEffect(player)) {
            // Add 3 saturation bars when eating
            float currentSaturation = player.getSaturation();
            player.setSaturation(Math.min(currentSaturation + 6.0f, 20.0f)); // Each bar is 2.0f
        }
    }
    
    private boolean hasRegenEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == com.infusesmp.potion.PotionType.REGEN && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == com.infusesmp.potion.PotionType.REGEN && data.isSecondaryEnabled());
    }
}
