package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import com.infusesmp.data.PlayerData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.Set;
import java.util.HashSet;

public class FeatherEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Integer> hitCounter = new HashMap<>();
    private final Map<UUID, Long> slamStartTime = new HashMap<>();
    private final Map<UUID, Location> slamStartLocation = new HashMap<>();
    private final Set<UUID> noFallDamage = new HashSet<>();
    private static final int HITS_FOR_WINDCHARGE = 10;
    private static final double SLAM_DAMAGE = 8.0; // 4 hearts
    private static final double HIGH_FALL_THRESHOLD = 7.0; // 7 blocks for bonus damage
    
    // Configurable visual/performance options
    private final double particleDensity;
    private final boolean enableSpiral;
    private final boolean enableShockwave;
    private final boolean enableTrails;
    private final boolean enableGlow;
    private final boolean enableTitles;
    private final boolean performanceMode;

    public FeatherEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        var config = plugin.getConfig().getConfigurationSection("feather_effect");
        this.particleDensity = config != null ? config.getDouble("particle_density", 1.0) : 1.0;
        this.enableSpiral = config != null && config.getBoolean("enable_spiral", true);
        this.enableShockwave = config != null && config.getBoolean("enable_shockwave", true);
        this.enableTrails = config != null && config.getBoolean("enable_trails", true);
        this.enableGlow = config != null && config.getBoolean("enable_glow", true);
        this.enableTitles = config != null && config.getBoolean("enable_titles", true);
        this.performanceMode = config != null && config.getBoolean("performance_mode", false);
    }
    
    @Override
    public void activatePassive(Player player) {
        hitCounter.put(player.getUniqueId(), 0);
        // Add player to noFallDamage set to ensure they have fall damage protection
        noFallDamage.add(player.getUniqueId());
        player.sendMessage(Component.text("☁ Feather Effect activated! You now have fall damage protection.")
                .color(NamedTextColor.AQUA));
    }
    
    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        hitCounter.remove(playerId);
        slamStartTime.remove(playerId);
        slamStartLocation.remove(playerId);
        // Remove player from noFallDamage set to ensure fall damage protection is removed
        noFallDamage.remove(playerId);
        player.sendMessage(Component.text("☁ Feather Effect deactivated! Fall damage protection removed.")
                .color(NamedTextColor.AQUA));
    }
    
    @Override
    public void useSpark(Player player) {
        // Double check if player still has effect
        if (!hasFeatherEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Feather effect active!").color(NamedTextColor.RED));
            return;
        }
        
        // Check cooldown before allowing spark usage
        UUID playerId = player.getUniqueId();
        if (plugin.getCooldownManager().isOnCooldown(playerId, PotionType.FEATHER)) {
            long remaining = plugin.getCooldownManager().getRemainingCooldown(playerId, PotionType.FEATHER);
            player.sendMessage(Component.text("❌ Feather Spark on cooldown! (" + (remaining / 1000) + "s)")
                    .color(NamedTextColor.RED));
            return;
        }
        
        // Enhanced launch mechanics
        for (Entity entity : player.getNearbyEntities(6, 6, 6)) {
            if (entity instanceof LivingEntity victim && !victim.equals(player)) {
                // Skip trusted players
                if (victim instanceof Player targetPlayer) {
                    PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
                    if (data != null && data.isTrustedPlayer(targetPlayer.getUniqueId())) {
                        continue;
                    }
                }
                // Calculate upward launch vector with horizontal spread
                // Updated launch velocity
                Vector velocity = new Vector(
                    (Math.random() - 0.5) * 0.3, // Horizontal variation
                    3.5, // Increased vertical launch force
                    (Math.random() - 0.5) * 0.3
                );
                victim.setVelocity(velocity);
                
                // Add temporary no-fall to launched entities
                if (entity instanceof Player) {
                    noFallDamage.add(entity.getUniqueId());
                    Bukkit.getScheduler().runTaskLater(plugin, () -> 
                        noFallDamage.remove(entity.getUniqueId()), 60L);
                }
            }
        }
        
        // Set cooldown after successful use
        plugin.getCooldownManager().setCooldown(playerId, PotionType.FEATHER);
        
        // Layered sounds
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 1.0f, 1.0f);
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 0.7f, 1.2f);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 0.5f, 1.5f);
    
        // Enhanced spiral effect
        if (enableSpiral && !performanceMode) {
            createSpiralEffect(player.getLocation());
        } else {
            createWhiteCircleEffect(player.getLocation());
        }
    
        // Still show particles around the player for visual effect
        player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), (int)(10 * particleDensity), 0.3, 0.3, 0.3, 0.1);
        
        // Only show action bar, remove title/subtitle
        player.sendActionBar(Component.text("☁ Feather Spark activated! Nearby entities launched!").color(NamedTextColor.AQUA));
    }
    
    // Add this new method to create a particle circle at the exact radius
    private void createRadiusCircle(Location center, double radius, Particle particle) {
        // Create a complete circle at the exact radius
        for (int i = 0; i < 72; i++) { // More points for a smoother circle
            double angle = i * 5 * Math.PI / 180; // 5 degrees per point
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            
            // Create particles at player height and slightly above
            Location particleLoc = new Location(center.getWorld(), x, center.getY() + 0.1, z);
            center.getWorld().spawnParticle(particle, particleLoc, 1, 0, 0, 0, 0);
            
            // Add a second layer slightly higher for better visibility
            Location particleLocUpper = new Location(center.getWorld(), x, center.getY() + 0.5, z);
            center.getWorld().spawnParticle(particle, particleLocUpper, 1, 0, 0, 0, 0);
        }
    }
    
    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        
        // Check for high fall attack
        if (attacker.getFallDistance() >= HIGH_FALL_THRESHOLD) {
            event.setDamage(event.getDamage() * 1.15); // 15% more damage
            attacker.getWorld().spawnParticle(Particle.CLOUD, attacker.getLocation(), 10, 0.5, 0.5, 0.5, 0.1);
        }
        
        // Increment hit counter
        int hits = hitCounter.getOrDefault(attackerId, 0) + 1;
        if (hits >= HITS_FOR_WINDCHARGE) {
            hits = 0;
            // Only reset cooldown if it's not already active
            if (!plugin.getCooldownManager().isOnCooldown(attackerId, PotionType.FEATHER)) {
                attacker.sendMessage(Component.text("Windcharge ready!")
                        .color(NamedTextColor.AQUA));
            }
        }
        hitCounter.put(attackerId, hits);
    }
    
    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        UUID defenderId = defender.getUniqueId();
        
        // Increment hit counter when taking damage
        int hits = hitCounter.getOrDefault(defenderId, 0) + 1;
        if (hits >= HITS_FOR_WINDCHARGE) {
            hits = 0;
            // Only reset cooldown if it's not already active
            if (!plugin.getCooldownManager().isOnCooldown(defenderId, PotionType.FEATHER)) {
                defender.sendMessage(Component.text("Windcharge ready!")
                        .color(NamedTextColor.AQUA));
            }
        }
        hitCounter.put(defenderId, hits);
    }
    
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        // Check if player has feather effect
        if (!hasFeatherEffect(player)) return;
        // Cancel fall damage if in noFallDamage set
        if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            if (noFallDamage.remove(player.getUniqueId())) {
                event.setCancelled(true);
                player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 20, 0.5, 0, 0.5, 0.1);
                player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 0.5f, 1.5f);
                return;
            }
            // Otherwise, normal feather effect fall cancel
            event.setCancelled(true);
            player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 20, 0.5, 0, 0.5, 0.1);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PHANTOM_FLAP, 0.5f, 1.5f);
        }
    }
    
    private boolean hasFeatherEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.FEATHER && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.FEATHER && data.isSecondaryEnabled());
    }
    
    // Add this new method for the enhanced white circle effect
    private void createWhiteCircleEffect(Location center) {
        // Create multiple layers of white particles for a dramatic effect
        for (int layer = 0; layer < 3; layer++) {
            double layerHeight = layer * 0.3;
            
            // Draw circle of white particles - more dense for better visibility
            for (int i = 0; i < 72; i++) {
                double angle = 2 * Math.PI * i / 72;
                double x = center.getX() + 6 * Math.cos(angle);
                double z = center.getZ() + 6 * Math.sin(angle);
                Location particleLoc = new Location(center.getWorld(), x, center.getY() + layerHeight, z);
                
                // Main white particle circle
                center.getWorld().spawnParticle(Particle.CLOUD, particleLoc, 2, 0.05, 0.05, 0.05, 0);
                
                // Add some snowflake particles for effect
                if (i % 4 == 0) {
                    center.getWorld().spawnParticle(Particle.SNOWFLAKE, particleLoc, 1, 0.05, 0.05, 0.05, 0.01);
                }
                
                // Add occasional end rod particles for a more intense look
                if (i % 9 == 0 && layer == 1) {
                    center.getWorld().spawnParticle(Particle.END_ROD, particleLoc, 1, 0.1, 0.1, 0.1, 0.01);
                }
            }
        }
        
        // Add some floating particles inside the circle
        for (int i = 0; i < 15; i++) {
            double angle = 2 * Math.PI * Math.random();
            double distance = 6 * 0.8 * Math.random();
            double x = center.getX() + distance * Math.cos(angle);
            double z = center.getZ() + distance * Math.sin(angle);
            Location particleLoc = new Location(center.getWorld(), x, center.getY() + 0.5 + Math.random(), z);
            center.getWorld().spawnParticle(Particle.CLOUD, particleLoc, 1, 0.1, 0.1, 0.1, 0.01);
        }
    }

    // --- Visual Utility Methods ---
    private void createSpiralEffect(Location center) {
        int points = (int)(100 * particleDensity);
        double spiralHeight = 2.5;
        double spiralRadius = 6.0;
        for (int i = 0; i < points; i++) {
            double t = (double) i / points;
            double angle = 4 * Math.PI * t;
            double radius = spiralRadius * t;
            double x = center.getX() + Math.cos(angle) * radius;
            double z = center.getZ() + Math.sin(angle) * radius;
            double y = center.getY() + spiralHeight * t;
            Particle particle = (i % 8 == 0) ? Particle.END_ROD : (i % 5 == 0) ? Particle.SNOWFLAKE : (i % 3 == 0) ? Particle.CRIT : Particle.CLOUD;
            center.getWorld().spawnParticle(particle, x, y, z, 1, 0, 0, 0, 0);
        }
    }

    private void createShockwaveEffect(Location center) {
        int rings = 3;
        int pointsPerRing = (int)(48 * particleDensity);
        double baseRadius = 2.5;
        for (int ring = 0; ring < rings; ring++) {
            double radius = baseRadius + ring * 1.5;
            double y = center.getY() + 0.1 + ring * 0.1;
            for (int i = 0; i < pointsPerRing; i++) {
                double angle = 2 * Math.PI * i / pointsPerRing;
                double x = center.getX() + Math.cos(angle) * radius;
                double z = center.getZ() + Math.sin(angle) * radius;
                Particle particle = (i % 8 == 0) ? Particle.END_ROD : (i % 4 == 0) ? Particle.SNOWFLAKE : Particle.CLOUD;
                center.getWorld().spawnParticle(particle, x, y, z, 1, 0, 0, 0, 0);
            }
        }
    }

    private void createTrailEffect(Entity entity) {
        new BukkitRunnable() {
            int ticks = 0;
            Location lastLoc = entity.getLocation();
            @Override
            public void run() {
                if (ticks++ > 20 || entity.isOnGround() || entity.isDead()) {
                    cancel();
                    return;
                }
                Location loc = entity.getLocation();
                if (loc.distanceSquared(lastLoc) > 0.01) {
                    entity.getWorld().spawnParticle(Particle.CLOUD, loc, (int)(2 * particleDensity), 0.1, 0.1, 0.1, 0.01);
                    if (ticks % 4 == 0) {
                        entity.getWorld().spawnParticle(Particle.END_ROD, loc, 1, 0.05, 0.05, 0.05, 0.01);
                    }
                    lastLoc = loc.clone();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }
}