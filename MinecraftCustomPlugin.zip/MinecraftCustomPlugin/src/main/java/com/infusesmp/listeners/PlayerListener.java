package com.infusesmp.listeners;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.InfusePotion;
import com.infusesmp.potion.PotionType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.event.block.Action;
import java.util.List;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.inventory.EquipmentSlot;

public class PlayerListener implements Listener {
    
    private final InfuseSMPPlugin plugin;
    
    public PlayerListener(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
    }
    
    private void showPassiveEffects(Player player, PotionType potionType) {
        // Get passive effects based on potion type
        List<String> passiveEffects = getEffectDescription(potionType);
        
        // Show header
        player.sendMessage(Component.empty());
        player.sendMessage(Component.text("✨ " + potionType.getIcon() + " " + potionType.getDisplayName() + " Passive Effects:")
                .color(NamedTextColor.LIGHT_PURPLE)
                .decorate(TextDecoration.BOLD));
        
        // Show each passive effect
        for (String effect : passiveEffects) {
            player.sendMessage(Component.text(" • ").color(NamedTextColor.DARK_PURPLE)
                    .append(Component.text(effect).color(NamedTextColor.GRAY)));
        }
        
        player.sendMessage(Component.empty());
    }
    
    private List<String> getEffectDescription(PotionType type) {
        return switch (type) {
            case REGEN -> List.of(
                "Passive: Increased natural regeneration",
                "Spark: Burst heal and brief regeneration boost"
            );
            case FEATHER -> List.of(
                "Passive: Reduced fall damage",
                "Spark: Launch into the air and slam down"
            );
            case THUNDER -> List.of(
                "Passive: Chain lightning on hits",
                "Spark: Call down lightning strikes"
            );
            case STRENGTH -> List.of(
                "Passive: Increased melee damage",
                "Spark: Shield break and temporary strength boost"
            );
            case HEART -> List.of(
                "Passive: Health regeneration",
                "Spark: Massive heal and brief invulnerability"
            );
            case FROST -> List.of(
                "Passive: Slow enemies on hit",
                "Spark: Create an ice field that slows enemies"
            );
            case EMERALD -> List.of(
                "Passive: Increased XP gain",
                "Spark: Convert nearby items to XP"
            );
            case OCEAN -> List.of(
                "Passive: Water breathing and swimming speed",
                "Spark: Create a water bubble and push enemies"
            );
            case FIRE -> List.of(
                "Passive: Fire resistance and burning attacks",
                "Spark: Create a ring of fire"
            );
            case SPEED -> List.of(
                "Passive: Movement speed boost",
                "Spark: Brief speed burst and no cooldown"
            );
            case HASTE -> List.of(
                "Passive: Mining speed increase",
                "Spark: Temporary super-haste"
            );
            case INVIS -> List.of(
                "Passive: Partial invisibility",
                "Spark: Full invisibility burst"
            );
        };
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        
        // Initialize player data if not exists
        plugin.getDataManager().getPlayerData(player.getUniqueId());
        
        // Update HUD
        plugin.getInfuseHUD().updateHUD(player);
        
        // Reactivate passive effects and show them
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        // Auto-set active slot if only one potion and activeSlot is null
        if (data.getActiveSlot() == null) {
            if (data.getPrimaryPotion() != null && data.getSecondaryPotion() == null) {
                data.setActiveSlot(data.getPrimaryPotion());
            } else if (data.getSecondaryPotion() != null && data.getPrimaryPotion() == null) {
                data.setActiveSlot(data.getSecondaryPotion());
            }
        }
        if (data.getPrimaryPotion() != null && data.isPrimaryEnabled()) {
            plugin.getEffectManager().activatePassiveEffects(player, data.getPrimaryPotion());
            showPassiveEffects(player, data.getPrimaryPotion());
        }
        if (data.getSecondaryPotion() != null && data.isSecondaryEnabled()) {
            plugin.getEffectManager().activatePassiveEffects(player, data.getSecondaryPotion());
            showPassiveEffects(player, data.getSecondaryPotion());
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        
        // Save player data
        plugin.getDataManager().savePlayerData(player.getUniqueId());
        
        // Cancel brewing if player is brewing
        // if (plugin.getBrewingManager().isPlayerBrewing(player)) {
        //     plugin.getBrewingManager().cancelBrewing(
        //             plugin.getBrewingManager().getPlayerBrewingLocation(player));
        // }
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        boolean isCustomPotion = item != null && item.getType() == Material.POTION && InfusePotion.getPotionType(item) != null;
        // Allow spark trigger on shift+right-click regardless of item in hand
        if ((event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK)
                && player.isSneaking() && (!isCustomPotion || item == null)) {
            PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
            PotionType activePotion = data.getActiveSlot();
            if (activePotion == null) {
                player.sendMessage(Component.text("No active potion selected!").color(NamedTextColor.RED));
                return;
            }
            boolean isEnabled = activePotion == data.getPrimaryPotion() ? data.isPrimaryEnabled() : data.isSecondaryEnabled();
            if (!isEnabled) {
                player.sendMessage(Component.text("Active potion is disabled!").color(NamedTextColor.RED));
                return;
            }
            event.setCancelled(true);
            plugin.getEffectManager().useSpark(player, activePotion);
            return;
        }
        // If right-clicking with a custom potion, let vanilla drinking handle it (do not cancel event or trigger spark)
        // If right-clicking with anything else, do nothing
    }
    
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        
        // Drop active potions as items
        if (data.getPrimaryPotion() != null) {
            ItemStack potionItem = plugin.getPotionManager().createPotionItem(data.getPrimaryPotion());
            if (potionItem != null) {
                event.getDrops().add(potionItem);
            }
        }
        
        if (data.getSecondaryPotion() != null) {
            ItemStack potionItem = plugin.getPotionManager().createPotionItem(data.getSecondaryPotion());
            if (potionItem != null) {
                event.getDrops().add(potionItem);
            }
        }
        
        // Clear player data
        plugin.getDataManager().clearPlayerPotions(player);
        
        // Clear cooldowns
        plugin.getCooldownManager().clearPlayerCooldowns(player.getUniqueId());
    }
    
    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        PotionType potionType = InfusePotion.getPotionType(item);
        if (potionType == null) return; // Not an infuse potion
        event.setCancelled(true); // Prevent vanilla consumption (no empty bottle)
        
        // Fix for offhand consumption bug
        if (event.getHand() == EquipmentSlot.OFF_HAND) {
            player.getInventory().setItemInOffHand(null);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
        
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        PotionType previousActive = data.getActiveSlot();
        boolean isPrimary = potionType.isPrimary();
        // If replacing an existing potion, convert it back to an item and give to player
        if (isPrimary && data.getPrimaryPotion() != null) {
            if (data.getPrimaryPotion() != potionType) {
                ItemStack oldPotion = plugin.getPotionManager().createPotionItem(data.getPrimaryPotion());
                if (oldPotion != null) player.getInventory().addItem(oldPotion);
                plugin.getEffectManager().disablePassiveEffects(player, data.getPrimaryPotion());
            }
        } else if (!isPrimary && data.getSecondaryPotion() != null) {
            if (data.getSecondaryPotion() != potionType) {
                ItemStack oldPotion = plugin.getPotionManager().createPotionItem(data.getSecondaryPotion());
                if (oldPotion != null) player.getInventory().addItem(oldPotion);
                plugin.getEffectManager().disablePassiveEffects(player, data.getSecondaryPotion());
            }
        }
        if (isPrimary) {
            data.setPrimaryPotion(potionType);
            data.setPrimaryEnabled(true);
            data.setActiveSlot(potionType);
        } else {
            data.setSecondaryPotion(potionType);
            data.setSecondaryEnabled(true);
            data.setActiveSlot(potionType);
        }
        if (previousActive != null && previousActive != potionType) {
            plugin.getEffectManager().disablePassiveEffects(player, previousActive);
        }
        plugin.getEffectManager().activatePassiveEffects(player, potionType);
        plugin.getInfuseHUD().updateHUD(player);
        plugin.getDataManager().savePlayerData(player.getUniqueId());
        player.sendMessage(Component.text("Potion activated: " + potionType.getDisplayName()).color(NamedTextColor.LIGHT_PURPLE));
        // Broadcast passive effects to the player
        showPassiveEffects(player, potionType);
    }

    @EventHandler
    public void onMilkOrVanillaPotion(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        
        // Check if it's a custom potion
        if (InfusePotion.getPotionType(item) != null) return; // Let the other handler deal with custom potions
        
        // Only handle milk buckets - vanilla potions should work normally
        if (item.getType() != Material.MILK_BUCKET) return;
        
        // For milk buckets, we need to reapply our custom effects after they are cleared
        // Delay to let milk apply its effects
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
            // Only reapply our infinite duration effects
            if (data.getPrimaryPotion() != null && data.isPrimaryEnabled()) {
                // Check if the effect was actually removed (had infinite duration)
                PotionEffect effect = player.getPotionEffect(getEffectType(data.getPrimaryPotion()));
                if (effect == null || effect.getDuration() > 9999) {
                    plugin.getEffectManager().activatePassiveEffects(player, data.getPrimaryPotion());
                }
            }
            if (data.getSecondaryPotion() != null && data.isSecondaryEnabled()) {
                // Check if the effect was actually removed (had infinite duration)
                PotionEffect effect = player.getPotionEffect(getEffectType(data.getSecondaryPotion()));
                if (effect == null || effect.getDuration() > 9999) {
                    plugin.getEffectManager().activatePassiveEffects(player, data.getSecondaryPotion());
                }
            }
        }, 2L); // Reduced delay to 2 ticks to minimize the gap
    }
    
    // Helper method to get the effect type for a potion type
    private PotionEffectType getEffectType(PotionType type) {
        switch (type) {
            case STRENGTH: return PotionEffectType.STRENGTH;
            case HASTE: return PotionEffectType.HASTE;
            case INVIS: return PotionEffectType.INVISIBILITY;
            case FIRE: return PotionEffectType.FIRE_RESISTANCE;
            case OCEAN: return PotionEffectType.WATER_BREATHING;
            default: return null;
        }
    }

    // --- NEW: Reapply passives after totem pop ---
    @EventHandler
    public void onTotemPop(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        // Only care if the resurrection was successful (totem used)
        if (!event.isCancelled()) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
                if (data.getPrimaryPotion() != null && data.isPrimaryEnabled()) {
                    plugin.getEffectManager().activatePassiveEffects(player, data.getPrimaryPotion());
                }
                if (data.getSecondaryPotion() != null && data.isSecondaryEnabled()) {
                    plugin.getEffectManager().activatePassiveEffects(player, data.getSecondaryPotion());
                }
            }, 2L); // 2 ticks to ensure vanilla effects are cleared
        }
    }
}
