package com.sharpkingyt.majesticmace.managers;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.configuration.ConfigurationSection;

import com.sharpkingyt.majesticmace.MajesticMace;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class GUIManager {
    
    private final MajesticMace plugin;
    private final Map<UUID, Long> guiCooldowns;
    
    public GUIManager(MajesticMace plugin) {
        this.plugin = plugin;
        this.guiCooldowns = new HashMap<>();
    }
    
    public void openRecipeEditorGUI(Player player) {
        if (isOnCooldown(player)) {
            player.sendMessage("§c§lᴘʟᴇᴀꜱᴇ ᴡᴀɪᴛ ʙᴇꜰᴏʀᴇ ᴏᴘᴇɴɪɴɢ ᴛʜᴇ ɢᴜɪ ᴀɢᴀɪɴ!");
            plugin.getSoundManager().playSound(player, "access-denied");
            return;
        }
        
        guiCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
        
        String title = "§6§lᴍᴀᴊᴇꜱᴛɪᴄ ᴍᴀᴄᴇ §8» §eʀᴇᴄɪᴘᴇ ᴇᴅɪᴛᴏʀ";
        Inventory gui = Bukkit.createInventory(null, 54, title);
        
        setupEditorLayout(gui);
        loadCurrentRecipe(gui);
        
        player.openInventory(gui);
        plugin.getSoundManager().playSound(player, "gui-open");
    }
    
    private void setupEditorLayout(Inventory gui) {
        ItemStack blackGlass = createBlackGlass();
        
        // Fill all slots with black glass first
        for (int i = 0; i < 54; i++) {
            gui.setItem(i, blackGlass);
        }
        
        // Clear crafting slots (10-12, 19-21, 28-30)
        int[] craftingSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        for (int slot : craftingSlots) {
            gui.setItem(slot, null);
        }
        
        // Result preview in slot 24
        gui.setItem(24, createResultPreview());
        
        // Control buttons
        gui.setItem(48, createSaveButton());
        gui.setItem(50, createCloseButton());
    }
    
    private void loadCurrentRecipe(Inventory gui) {
        ConfigurationSection ingredients = plugin.getConfig().getConfigurationSection("custom-recipe.ingredients");
        if (ingredients == null) return;
        
        // Map config slots to GUI crafting slots
        int[] configSlots = {36, 37, 38, 39, 40, 41, 42, 43, 44};
        int[] guiSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        
        for (int i = 0; i < configSlots.length; i++) {
            String materialName = ingredients.getString("slot-" + configSlots[i], "AIR");
            if (!materialName.equals("AIR")) {
                try {
                    Material material = Material.valueOf(materialName.toUpperCase());
                    gui.setItem(guiSlots[i], new ItemStack(material));
                } catch (IllegalArgumentException e) {
                    // Invalid material, skip
                }
            }
        }
    }
    
    private ItemStack createBlackGlass() {
        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = glass.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            glass.setItemMeta(meta);
        }
        return glass;
    }
    
    private ItemStack createResultPreview() {
        ItemStack mace = new ItemStack(Material.MACE);
        ItemMeta meta = mace.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§6ᴄʀᴀꜰᴛɪɴɢ ʀᴇꜱᴜʟᴛ");
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            List<String> lore = new ArrayList<>();
            lore.add("§7ᴄʀᴀꜰᴛɪɴɢ ʀᴇꜱᴜʟᴛ");
            meta.setLore(lore);
            mace.setItemMeta(meta);
        }
        return mace;
    }
    
    private ItemStack createSaveButton() {
        ItemStack save = new ItemStack(Material.GREEN_CONCRETE);
        ItemMeta meta = save.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§a§lꜱᴀᴠᴇ ʀᴇᴄɪᴘᴇ");
            save.setItemMeta(meta);
        }
        return save;
    }
    
    private ItemStack createCloseButton() {
        ItemStack close = new ItemStack(Material.RED_CONCRETE);
        ItemMeta meta = close.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§c§lᴄʟᴏꜱᴇ");
            close.setItemMeta(meta);
        }
        return close;
    }
    
    public void openViewRecipeGUI(Player player) {
        String title = "§6§lᴍᴀᴊᴇꜱᴛɪᴄ ᴍᴀᴄᴇ §8» §bᴠɪᴇᴡ ʀᴇᴄɪᴘᴇ";
        Inventory gui = Bukkit.createInventory(null, 54, title);
        
        setupViewLayout(gui);
        loadViewRecipe(gui);
        
        player.openInventory(gui);
        plugin.getSoundManager().playSound(player, "gui-open");
    }
    
    private void setupViewLayout(Inventory gui) {
        ItemStack cyanGlass = createCyanGlass();
        
        // Fill all slots with cyan glass
        for (int i = 0; i < 54; i++) {
            gui.setItem(i, cyanGlass);
        }
        
        // Clear recipe display slots
        int[] recipeSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        for (int slot : recipeSlots) {
            gui.setItem(slot, null);
        }
        
        // Arrow pointing to result
        gui.setItem(22, createArrow());
        
        // Result slot
        gui.setItem(24, createViewResult());
        
        // Close button
        gui.setItem(49, createViewCloseButton());
    }
    
    private void loadViewRecipe(Inventory gui) {
        ConfigurationSection ingredients = plugin.getConfig().getConfigurationSection("custom-recipe.ingredients");
        if (ingredients == null) return;
        
        int[] configSlots = {36, 37, 38, 39, 40, 41, 42, 43, 44};
        int[] guiSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        
        for (int i = 0; i < configSlots.length; i++) {
            String materialName = ingredients.getString("slot-" + configSlots[i], "AIR");
            if (!materialName.equals("AIR")) {
                try {
                    Material material = Material.valueOf(materialName.toUpperCase());
                    ItemStack item = new ItemStack(material);
                    ItemMeta meta = item.getItemMeta();
                    if (meta != null) {
                        meta.addEnchant(Enchantment.UNBREAKING, 1, true);
                        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                        item.setItemMeta(meta);
                    }
                    gui.setItem(guiSlots[i], item);
                } catch (IllegalArgumentException e) {
                    // Invalid material, skip
                }
            }
        }
    }
    
    private ItemStack createCyanGlass() {
        ItemStack glass = new ItemStack(Material.CYAN_STAINED_GLASS_PANE);
        ItemMeta meta = glass.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            glass.setItemMeta(meta);
        }
        return glass;
    }
    
    private ItemStack createArrow() {
        ItemStack arrow = new ItemStack(Material.SPECTRAL_ARROW);
        ItemMeta meta = arrow.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§e§l➜");
            arrow.setItemMeta(meta);
        }
        return arrow;
    }
    
    private ItemStack createViewResult() {
        ItemStack mace = new ItemStack(Material.MACE);
        ItemMeta meta = mace.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§6ᴄʀᴀꜰᴛɪɴɢ ʀᴇꜱᴜʟᴛ");
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            List<String> lore = new ArrayList<>();
            lore.add("§7➜");
            meta.setLore(lore);
            mace.setItemMeta(meta);
        }
        return mace;
    }
    
    private ItemStack createViewCloseButton() {
        ItemStack close = new ItemStack(Material.BARRIER);
        ItemMeta meta = close.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§c§lᴄʟᴏꜱᴇ");
            close.setItemMeta(meta);
        }
        return close;
    }
    
    private boolean isOnCooldown(Player player) {
        if (!guiCooldowns.containsKey(player.getUniqueId())) {
            return false;
        }
        
        long lastUsed = guiCooldowns.get(player.getUniqueId());
        long cooldownTime = plugin.getConfig().getLong("security.gui-cooldown", 3) * 1000;
        
        return (System.currentTimeMillis() - lastUsed) < cooldownTime;
    }
    
    public boolean isRecipeEditorGUI(Inventory inventory) {
        return inventory.getSize() == 54 && inventory.getViewers().size() > 0;
    }
    
    public boolean isViewRecipeGUI(Inventory inventory) {
        return inventory.getSize() == 54 && inventory.getViewers().size() > 0;
    }
}