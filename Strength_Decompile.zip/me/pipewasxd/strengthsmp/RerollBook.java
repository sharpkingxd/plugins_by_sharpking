package me.pipewasxd.strengthsmp;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public record RerollBook(StrengthSMP plugin, WeaponManager weaponManager) implements Listener {
   public static ItemStack createRerollBook(StrengthSMP plugin) {
      ItemStack book = new ItemStack(Material.BOOK);
      ItemMeta meta = book.getItemMeta();
      if (meta != null) {
         meta.setCustomModelData(12346);

         try {
            NamespacedKey modelKey = new NamespacedKey("strengthsmp", "reroll_book");
            Method setItemModel = meta.getClass().getMethod("setItemModel", NamespacedKey.class);
            setItemModel.invoke(meta, modelKey);
         } catch (Exception var5) {
         }

         String var10001 = String.valueOf(ChatColor.DARK_RED);
         meta.setDisplayName(var10001 + String.valueOf(ChatColor.BOLD) + "ʀᴇʀᴏʟʟ ʙᴏᴏᴋ");
         List<String> lore = new ArrayList();
         var10001 = String.valueOf(ChatColor.WHITE);
         lore.add(var10001 + "Right-click to " + String.valueOf(ChatColor.GREEN) + "reroll" + String.valueOf(ChatColor.WHITE) + " your weapon!");
         lore.add("" + String.valueOf(ChatColor.GRAY));
         lore.add(String.valueOf(ChatColor.GREEN) + "This will randomly assign you a new weapon type!");
         meta.setLore(lore);
         NamespacedKey key = plugin != null ? new NamespacedKey(plugin, "reroll_book") : new NamespacedKey("strengthsmp", "reroll_book");
         meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte)1);
         book.setItemMeta(meta);
      }

      return book;
   }

   public static boolean isRerollBook(ItemStack item, StrengthSMP plugin) {
      if (item != null && item.hasItemMeta()) {
         ItemMeta meta = item.getItemMeta();
         NamespacedKey key = plugin != null ? new NamespacedKey(plugin, "reroll_book") : new NamespacedKey("strengthsmp", "reroll_book");
         return meta.getPersistentDataContainer().has(key, PersistentDataType.BYTE);
      } else {
         return false;
      }
   }

   @EventHandler
   public void onRerollBookUse(PlayerInteractEvent event) {
      Player player = event.getPlayer();
      ItemStack item = event.getItem();
      if (item != null && (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK)) {
         if (isRerollBook(item, this.plugin)) {
            event.setCancelled(true);
            WeaponType oldWeapon = this.weaponManager.getPlayerWeapon(player);

            WeaponType newWeapon;
            do {
               newWeapon = WeaponType.random();
            } while(newWeapon == oldWeapon);

            this.weaponManager.setPlayerWeapon(player, newWeapon);
            item.setAmount(item.getAmount() - 1);
            player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#006400:#00FF00>ʏᴏᴜʀ ᴡᴇᴀᴘᴏɴ ʜᴀs ʙᴇᴇɴ ʀᴇʀᴏʟʟᴇᴅ!</gradient></bold>"));
            String var10001 = String.valueOf(ChatColor.GRAY);
            player.sendMessage(var10001 + "Old Weapon: " + oldWeapon.getDisplayName());
            var10001 = String.valueOf(ChatColor.GRAY);
            player.sendMessage(var10001 + "New Weapon: " + newWeapon.getDisplayName());
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.2F);
            player.playSound(player.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0F, 1.5F);
            player.playSound(player.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1.0F, 1.0F);
            player.getWorld().spawnParticle(Particle.ENCHANT, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)0.5F, (double)1.0F, (double)0.5F, (double)1.0F);
            player.getWorld().spawnParticle(Particle.END_ROD, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, 0.3, (double)0.5F, 0.3, 0.1);
            player.getWorld().spawnParticle(Particle.WITCH, player.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, 0.4, 0.6, 0.4, 0.1);
         }
      }
   }

   @EventHandler
   public void onBookEdit(PlayerEditBookEvent event) {
      if (isRerollBook(event.getPlayer().getInventory().getItemInMainHand(), this.plugin)) {
         event.setCancelled(true);
      }

   }
}
