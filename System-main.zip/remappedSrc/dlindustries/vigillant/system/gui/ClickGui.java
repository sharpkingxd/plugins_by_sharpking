package dlindustries.vigillant.system.gui;

import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.module.setting.MinMaxSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.module.setting.StringSetting;
import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.utils.KeyUtils;
import dlindustries.vigillant.system.utils.RenderUtils;
import dlindustries.vigillant.system.utils.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public final class ClickGui extends Screen {
	private final List<TabCategory> tabs = new ArrayList<>();
	private boolean tabsInitialized = false;
	private int lastWidth = -1;
	private int lastHeight = -1;

	private boolean searchFocused = false;
	private static String searchQuery = "";

	private KeybindSetting listeningBind = null;
	private StringSetting editingStringSetting = null;
	private String editingStringValue = "";

	private static long time = System.currentTimeMillis();
	private static long deltaTime = 16L;

	private final Color outlineColor = new Color(255, 255, 255, 200);

	private ClickGUI getClickGUIModule() {
		if (system.INSTANCE != null && system.INSTANCE.getModuleManager() != null) {
			Module module = system.INSTANCE.getModuleManager().getModule(ClickGUI.class);
			if (module instanceof ClickGUI) {
				return (ClickGUI) module;
			}
		}
		return null;
	}

	private Color getAccentColor() {
		ClickGUI module = getClickGUIModule();
		if (module != null) {

			return dlindustries.vigillant.system.utils.Utils.getMainColor(255, 0);
		}
		return new Color(255, 80, 140, 255);
	}

	private Color getBackgroundColor() {
		return new Color(25, 25, 30, 245);
	}

	private Color getPanelBackground() {
		return new Color(35, 35, 42, 255);
	}

	private Color getHeaderBackground() {
		return new Color(40, 40, 48, 255);
	}

	private Color getTextPrimary() {
		return new Color(255, 255, 255, 255);
	}

	private Color getTextSecondary() {
		return new Color(180, 180, 190, 255);
	}

	private static final int SETTING_ROW_HEIGHT = 20;

	public ClickGui() {
		super(Text.empty());
	}

	public static long getDeltaTime() {
		return deltaTime;
	}

	public String getSearchQuery() {
		return searchQuery;
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		updateDeltaTime();

		ensureTabsInitialized();
		context.fill(0, 0, this.width, this.height, getBackgroundColor().getRGB());

		for (TabCategory tab : tabs) {
			tab.render(this, context, mouseX, mouseY, delta);
		}

		renderSearchBar(context, mouseX, mouseY);

		if (editingStringSetting != null) {
			renderStringInputOverlay(context);
		}

		super.render(context, mouseX, mouseY, delta);

		renderSearchBarText(context);
	}

	private void updateDeltaTime() {
		long now = System.currentTimeMillis();
		deltaTime = now - time;
		time = now;
	}

	private String fitText(CharSequence text, int maxWidth) {
		if (text == null) {
			return "";
		}
		String value = text.toString();
		if (maxWidth <= 0) {
			return "";
		}
		int width = TextRenderer.getWidth(value);
		if (width <= maxWidth) {
			return value;
		}
		String ellipsis = "...";
		int target = maxWidth - TextRenderer.getWidth(ellipsis);
		if (target <= 0) {
			return ellipsis;
		}
		while (value.length() > 0 && TextRenderer.getWidth(value) > target) {
			value = value.substring(0, value.length() - 1);
		}
		return value + ellipsis;
	}

	private String fitSmallText(CharSequence text, int maxWidth) {
		if (text == null) {
			return "";
		}
		String value = text.toString();
		if (maxWidth <= 0) {
			return "";
		}

		int width = TextRenderer.getSmallWidth(value);
		if (width <= maxWidth) {
			return value;
		}
		String ellipsis = "...";
		int ellipsisWidth = TextRenderer.getSmallWidth(ellipsis);
		int target = maxWidth - ellipsisWidth;
		if (target <= 0) {
			return ellipsis;
		}
		while (value.length() > 0 && TextRenderer.getSmallWidth(value) > target) {
			value = value.substring(0, value.length() - 1);
		}
		return value + ellipsis;
	}

	private void ensureTabsInitialized() {
		if (tabsInitialized && this.width == lastWidth && this.height == lastHeight) {
			return;
		}

		tabs.clear();
		float startX = this.width / 2.0f - Category.values().length * 65.0f + 5.0f;
		float tabY = 5.0f;
		for (Category category : Category.values()) {
			tabs.add(new TabCategory(category, startX, tabY, 120.0f, 20.0f));
			startX += 130.0f;
		}

		tabsInitialized = true;
		lastWidth = this.width;
		lastHeight = this.height;
	}

	private void renderSearchBar(DrawContext context, int mouseX, int mouseY) {
		int barWidth = 200;
		int barHeight = 20;
		int x = this.width / 2 - barWidth / 2;
		int y = this.height - 40;

		context.fill(x, y, x + barWidth, y + barHeight, getPanelBackground().getRGB());
		RenderUtils.drawRoundedOutline(context, x, y, barWidth, barHeight, 0, 1, outlineColor);

		int iconSize = 12;
		int iconX = x + 6;
		int iconY = y + (barHeight - iconSize) / 2;

		try {
			net.minecraft.util.Identifier searchIconId = net.minecraft.util.Identifier.of("system", "images/search.png");
			net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();

			if (client == null || client.getTextureManager() == null) {
				return;
			}

			net.minecraft.client.texture.AbstractTexture texture = client.getTextureManager().getTexture(searchIconId);

			if (texture == null) {
				try {

					net.minecraft.client.texture.NativeImageBackedTexture nativeTexture =
						new net.minecraft.client.texture.NativeImageBackedTexture(() -> "search_icon",
							net.minecraft.client.texture.NativeImage.read(
								client.getResourceManager().getResource(searchIconId).orElseThrow().getInputStream()));
					client.getTextureManager().registerTexture(searchIconId, nativeTexture);
					texture = nativeTexture;
				} catch (Exception loadEx) {

					return;
				}
			}

			int glId = -1;
			try {
				java.lang.reflect.Method getGlIdMethod = texture.getClass().getMethod("getGlId");
				glId = (Integer) getGlIdMethod.invoke(texture);
			} catch (Exception e) {

				try {
					java.lang.reflect.Method bindMethod = texture.getClass().getMethod("bind");
					bindMethod.invoke(texture);

					try {
						java.lang.reflect.Method getGlIdMethod2 = texture.getClass().getMethod("getGlId");
						glId = (Integer) getGlIdMethod2.invoke(texture);
					} catch (Exception ignored) {
					}
				} catch (Exception ignored) {
					return;
				}
			}

			if (glId <= 0) {
				return;
			}

			org.lwjgl.opengl.GL11.glBindTexture(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, glId);

			net.minecraft.client.util.math.MatrixStack matrices = new net.minecraft.client.util.math.MatrixStack();
			net.minecraft.client.render.Tessellator tessellator = net.minecraft.client.render.Tessellator.getInstance();
			net.minecraft.client.render.BufferBuilder buffer = tessellator.begin(
				com.mojang.blaze3d.vertex.VertexFormat.DrawMode.QUADS,
				net.minecraft.client.render.VertexFormats.POSITION_TEXTURE_COLOR
			);

			try {
				java.lang.reflect.Method shaderMethod = null;
				boolean isStatic = false;

				java.lang.reflect.Method[] allMethods = net.minecraft.client.render.GameRenderer.class.getDeclaredMethods();
				for (java.lang.reflect.Method m : allMethods) {
					if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
						Class<?> returnType = m.getReturnType();
						String returnTypeName = returnType.getName();
						if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
							returnTypeName.startsWith("net.minecraft.client.gl.")) {
							m.setAccessible(true);
							shaderMethod = m;
							isStatic = true;
							break;
						}
					}
				}

				if (shaderMethod != null) {
					final java.lang.reflect.Method finalShaderMethod = shaderMethod;
					final boolean finalIsStatic = isStatic;

					java.util.function.Supplier<?> shaderSupplier = () -> {
						try {
							return finalIsStatic ? finalShaderMethod.invoke(null) : null;
						} catch (Exception ex) {
							return null;
						}
					};

					java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
					setShaderMethod.invoke(null, shaderSupplier);
				}
			} catch (Exception ignored) {
			}

			org.joml.Matrix4f matrix = matrices.peek().getPositionMatrix();
			float r = getTextSecondary().getRed() / 255f;
			float g = getTextSecondary().getGreen() / 255f;
			float b = getTextSecondary().getBlue() / 255f;
			float a = getTextSecondary().getAlpha() / 255f;

			buffer.vertex(matrix, iconX, iconY + iconSize, 0).color(r, g, b, a).texture(0.0f, 1.0f);
			buffer.vertex(matrix, iconX + iconSize, iconY + iconSize, 0).color(r, g, b, a).texture(1.0f, 1.0f);
			buffer.vertex(matrix, iconX + iconSize, iconY, 0).color(r, g, b, a).texture(1.0f, 0.0f);
			buffer.vertex(matrix, iconX, iconY, 0).color(r, g, b, a).texture(0.0f, 0.0f);

			buffer.end();
		} catch (Exception e) {

		}

	}

	private void renderSearchBarText(DrawContext context) {
		int barWidth = 200;
		int barHeight = 20;
		int x = this.width / 2 - barWidth / 2;
		int y = this.height - 40;
		int iconSize = 12;

		String display = searchQuery.isEmpty() ? "Search modules..." : searchQuery;
		if (searchFocused && ((System.currentTimeMillis() / 500) % 2 == 0)) {
			display += "|";
		}

		int textX = x + 6 + iconSize + 4;

		int textY = y + (barHeight - 9) / 2;

		int textColor;
		if (searchQuery.isEmpty()) {

			textColor = 0xFFC8C8D2;
		} else {

			textColor = 0xFFFFFFFF;
		}

		net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
		if (client != null && client.textRenderer != null && !display.isEmpty()) {

			context.drawText(client.textRenderer, display, textX + 1, textY + 1, 0x80000000, false);

			context.drawText(client.textRenderer, display, textX, textY, textColor, false);
		}
	}

	private void renderStringInputOverlay(DrawContext context) {
		context.fill(0, 0, this.width, this.height, new Color(0, 0, 0, 180).getRGB());

		int boxWidth = 280;
		int boxHeight = 120;
		int x = this.width / 2 - boxWidth / 2;
		int y = this.height / 2 - boxHeight / 2;

		context.fill(x, y, x + boxWidth, y + boxHeight, getPanelBackground().getRGB());
		RenderUtils.drawRoundedOutline(context, x, y, boxWidth, boxHeight, 0, 1, outlineColor);

		String title = "Editing " + editingStringSetting.getName();
		TextRenderer.drawString(title, context, x + 12, y + 12, getTextPrimary().getRGB());

		int inputY = y + 45;
		context.fill(x + 12, inputY, x + boxWidth - 12, inputY + 28, getHeaderBackground().getRGB());
		RenderUtils.drawRoundedOutline(context, x + 12, inputY, boxWidth - 24, 28, 0, 1, outlineColor);

		String value = editingStringValue;
		if ((System.currentTimeMillis() / 500) % 2 == 0) {
			value += "|";
		}
		TextRenderer.drawString(value, context, x + 18, inputY + 1, getTextPrimary().getRGB());

		TextRenderer.drawString("Enter to save • ESC to cancel", context, x + 12, y + 92, getTextSecondary().getRGB());
	}

	private boolean isPointInRect(double mouseX, double mouseY, double x, double y, double width, double height) {
		return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		int searchX = this.width / 2 - 200 / 2;
		int searchY = this.height - 40;
		if (isPointInRect(mouseX, mouseY, searchX, searchY, 200, 20)) {
			searchFocused = true;
			return true;
		}

		searchFocused = false;

		for (int i = tabs.size() - 1; i >= 0; i--) {
			TabCategory tab = tabs.get(i);
			if (tab.mouseClicked(mouseX, mouseY, button, this)) {
				tabs.remove(i);
				tabs.add(tab);
				return true;
			}
		}

		return super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int button) {
		for (TabCategory tab : tabs) {
			tab.mouseReleased(mouseX, mouseY, button, this);
		}
		return super.mouseReleased(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
		for (TabCategory tab : tabs) {
			tab.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
		}
		return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		for (TabCategory tab : tabs) {
			tab.scroll(verticalAmount * 8.0);
		}
		return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (listeningBind != null) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
				listeningBind.setKey(-1);
			} else {
				listeningBind.setKey(keyCode);
			}
			listeningBind = null;
			return true;
		}

		if (editingStringSetting != null) {
			if (keyCode == GLFW.GLFW_KEY_ENTER) {
				editingStringSetting.setValue(editingStringValue);
				editingStringSetting = null;
				editingStringValue = "";
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
				editingStringSetting = null;
				editingStringValue = "";
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !editingStringValue.isEmpty()) {
				editingStringValue = editingStringValue.substring(0, editingStringValue.length() - 1);
				return true;
			}
			return true;
		}

		if (searchFocused) {
			if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
				searchFocused = false;
				return true;
			}
			if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !searchQuery.isEmpty()) {
				searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
				return true;
			}
		}

		if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
			this.close();
			return true;
		}

		for (TabCategory tab : tabs) {
			if (tab.keyPressed(keyCode, scanCode, modifiers, this)) {
				return true;
			}
		}

		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@Override
	public boolean charTyped(char chr, int modifiers) {
		if (editingStringSetting != null) {
			if (chr >= 32 && chr != 127) {
				editingStringValue += chr;
			}
			return true;
		}

		if (searchFocused) {
			if (chr >= 32 && chr != 127) {
				searchQuery += chr;
			}
			return true;
		}

		for (TabCategory tab : tabs) {
			tab.charTyped(chr, modifiers);
		}

		return super.charTyped(chr, modifiers);
	}

	public void startListening(KeybindSetting setting) {
		listeningBind = setting;
		editingStringSetting = null;
		searchFocused = false;
	}

	public boolean isListening(KeybindSetting setting) {
		return listeningBind == setting;
	}

	public void beginStringEdit(StringSetting setting) {
		editingStringSetting = setting;
		editingStringValue = setting.getValue();
		searchFocused = false;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		super.close();
		listeningBind = null;
		editingStringSetting = null;
		editingStringValue = "";
		searchFocused = false;
		system.INSTANCE.getModuleManager().getModule(ClickGUI.class).setEnabled(false);
	}

	public void onGuiClose() {

	}

	public boolean isDraggingAlready() {

		return false;
	}

	private static class TabCategory {
		private final Category category;
		private final List<ModuleButton> modules = new ArrayList<>();
		private float x;
		private float y;
		private final float width;
		private boolean dragging = false;
		private float dragOffsetX;
		private float dragOffsetY;

		public TabCategory(Category category, float x, float y, float width, float headerHeight) {
			this.category = category;
			this.x = x;
			this.y = y;
			this.width = width;
			populateModules();
		}

		private void populateModules() {
			modules.clear();
			if (system.INSTANCE != null && system.INSTANCE.getModuleManager() != null) {
				List<Module> moduleList = system.INSTANCE.getModuleManager().getModulesInCategory(category);
				for (Module module : moduleList) {
					modules.add(new ModuleButton(module));
				}
			}
		}

		public void render(ClickGui gui, DrawContext context, int mouseX, int mouseY, float delta) {
			if (dragging) {
				this.x = (float) (mouseX + dragOffsetX);
				this.y = (float) (mouseY + dragOffsetY);
			}

			int baseX = (int) this.x;
			int baseY = (int) this.y;
			int panelWidth = (int) this.width;
			int headerHeight = 20;

			int contentHeight = 0;
			int visibleModules = 0;
			for (ModuleButton button : modules) {
				if (!button.matches(gui.getSearchQuery())) {
					continue;
				}
				contentHeight += (int) button.getHeight() + 2;
				visibleModules++;
			}

			int panelHeight = headerHeight + 4 + contentHeight + 4;

			if (visibleModules == 0) {
				panelHeight = headerHeight + 20;
			}

			context.fill(baseX, baseY, baseX + panelWidth, baseY + panelHeight, gui.getPanelBackground().getRGB());

			RenderUtils.drawRoundedOutline(context, baseX, baseY, panelWidth, panelHeight, 0, 1, gui.outlineColor);

			context.fill(baseX, baseY, baseX + panelWidth, baseY + headerHeight, gui.getHeaderBackground().getRGB());

			context.fill(baseX, baseY + headerHeight - 1, baseX + panelWidth, baseY + headerHeight,
				new Color(60, 60, 70, 255).getRGB());

			String categoryName = category.name.toString();
			int textWidth = TextRenderer.getWidth(categoryName);
			int textX = baseX + (panelWidth - textWidth) / 2;
			int textY = baseY + 6;
			TextRenderer.drawString(categoryName, context, textX, textY, gui.getTextPrimary().getRGB());

			if (visibleModules > 0) {
				int moduleY = baseY + headerHeight + 4;

				for (ModuleButton button : modules) {
					if (!button.matches(gui.getSearchQuery())) {
						continue;
					}

					button.render(gui, context, baseX + 4, moduleY, panelWidth - 8, mouseX, mouseY, delta);
					moduleY += (int) button.getHeight() + 2;
				}
			} else {
			String noModulesText = "No modules";
			int noModulesWidth = TextRenderer.getWidth(noModulesText);
			int noModulesX = baseX + (panelWidth - noModulesWidth) / 2;
			TextRenderer.drawString(noModulesText, context, noModulesX, baseY + headerHeight + 6,
				gui.getTextSecondary().getRGB());
			}

		}

		public boolean mouseClicked(double mouseX, double mouseY, int button, ClickGui gui) {
			if (isInHeader(mouseX, mouseY)) {
				if (button == 0) {
					dragging = true;
					dragOffsetX = (float) (x - mouseX);
					dragOffsetY = (float) (y - mouseY);
				}
				return true;
			}

			for (int i = modules.size() - 1; i >= 0; i--) {
				ModuleButton moduleButton = modules.get(i);
				if (moduleButton.mouseClicked(gui, mouseX, mouseY, button)) {
					return true;
				}
			}
			return false;
		}

		public void mouseReleased(double mouseX, double mouseY, int button, ClickGui gui) {
			if (button == 0) {
				dragging = false;
			}
			for (ModuleButton moduleButton : modules) {
				moduleButton.mouseReleased(mouseX, mouseY, button);
			}
		}

		public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
			if (dragging && button == 0) {
				this.x = (float) (mouseX + dragOffsetX);
				this.y = (float) (mouseY + dragOffsetY);
			}
		}

		public void scroll(double amount) {
			this.y += amount;
		}

		public void charTyped(char chr, int modifiers) {
			for (ModuleButton moduleButton : modules) {
				moduleButton.charTyped(chr, modifiers);
			}
		}

		public boolean keyPressed(int keyCode, int scanCode, int modifiers, ClickGui gui) {
			for (ModuleButton moduleButton : modules) {
				if (moduleButton.keyPressed(keyCode, scanCode, modifiers, gui)) {
					return true;
				}
			}
			return false;
		}

		private boolean isInHeader(double mouseX, double mouseY) {
			return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + 20;
		}
	}

	private static class ModuleButton {
		private static final int MODULE_HEIGHT = 15;

		private final Module module;
		private final List<SettingWidget> widgets = new ArrayList<>();
		private boolean expanded = false;

		private int lastX;
		private int lastY;
		private int lastWidth;
		private float displayHeight = MODULE_HEIGHT;
		private float targetAlpha = 0.0f;
		private float currentAlpha = 0.0f;

		public ModuleButton(Module module) {
			this.module = module;
			for (Setting<?> setting : module.getSettings()) {
				SettingWidget widget = SettingWidget.create(setting);
				if (widget != null) {
					widgets.add(widget);
				}
			}
		}

		public void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta) {
			this.lastX = x;
			this.lastY = y;
			this.lastWidth = width;

			targetAlpha = module.isEnabled() ? 1.0f : 0.0f;
			currentAlpha += (targetAlpha - currentAlpha) * 0.15f;

			Color accent = gui.getAccentColor();
			Color base = module.isEnabled()
				? new Color(accent.getRed(), accent.getGreen(), accent.getBlue(),
				Math.max(60, (int) (currentAlpha * 120)))
				: new Color(0, 0, 0, 0);

			context.fill(x, y, x + width, y + MODULE_HEIGHT, base.getRGB());

			if (module.isEnabled()) {
				Color outlineColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 200);

				context.fill(x, y, x + width, y + 1, outlineColor.getRGB());

				context.fill(x, y + MODULE_HEIGHT - 1, x + width, y + MODULE_HEIGHT, outlineColor.getRGB());

				context.fill(x, y, x + 1, y + MODULE_HEIGHT, outlineColor.getRGB());

				context.fill(x + width - 1, y, x + width, y + MODULE_HEIGHT, outlineColor.getRGB());
			}

			String name = gui.fitText(module.getName(), width - 30);
			int textY = y + 4;
			TextRenderer.drawString(name, context, x + 6, textY, gui.getTextPrimary().getRGB());
			if (!widgets.isEmpty()) {
				String hint = expanded ? "▲" : "▼";
				TextRenderer.drawString(hint, context, x + width - 12, textY, gui.getTextSecondary().getRGB());
			}

			float currentY = y + MODULE_HEIGHT;
			if (expanded && !widgets.isEmpty()) {
				context.fill(x + 4, (int) currentY, x + width - 4, (int) currentY + 1,
					new Color(60, 60, 70, 255).getRGB());
				currentY += 1;

				for (SettingWidget widget : widgets) {
					currentY += 4;
					widget.render(gui, context, x + 8, (int) currentY, width - 16, mouseX, mouseY, delta);
					currentY += widget.getHeight();
				}
				currentY += 4;
			}

			float targetHeight = Math.max(MODULE_HEIGHT, currentY - y);
			displayHeight += (targetHeight - displayHeight) * 0.3f;
		}

		public boolean mouseClicked(ClickGui gui, double mouseX, double mouseY, int button) {
			boolean inModuleArea = mouseX >= lastX && mouseX <= lastX + lastWidth &&
				mouseY >= lastY && mouseY <= lastY + displayHeight;

			if (!inModuleArea) {
				return false;
			}

			if (expanded && mouseY > lastY + MODULE_HEIGHT) {
				for (SettingWidget widget : widgets) {
					if (widget.mouseClicked(gui, mouseX, mouseY, button)) {
						return true;
					}
				}
			}

			if (mouseY >= lastY && mouseY <= lastY + MODULE_HEIGHT) {
				if (button == 0) {
					module.toggle();
					return true;
				}
				if (button == 1 && !widgets.isEmpty()) {
					expanded = !expanded;
					return true;
				}
			}

			return false;
		}

		public void mouseReleased(double mouseX, double mouseY, int button) {
			if (expanded) {
				for (SettingWidget widget : widgets) {
					widget.mouseReleased(mouseX, mouseY, button);
				}
			}
		}

		public void charTyped(char chr, int modifiers) {
			if (expanded) {
				for (SettingWidget widget : widgets) {
					widget.charTyped(chr, modifiers);
				}
			}
		}

		public boolean keyPressed(int keyCode, int scanCode, int modifiers, ClickGui gui) {
			if (expanded) {
				for (SettingWidget widget : widgets) {
					if (widget.keyPressed(keyCode, scanCode, modifiers, gui)) {
						return true;
					}
				}
			}
			return false;
		}

		public float getHeight() {
			return displayHeight;
		}

		public boolean matches(String query) {
			if (query == null || query.isEmpty()) {
				return true;
			}
			String lower = query.toLowerCase();
			if (module.getName().toString().toLowerCase().contains(lower)) {
				return true;
			}
			for (SettingWidget widget : widgets) {
				if (widget.matches(lower)) {
					return true;
				}
			}
			return false;
		}
	}

	private abstract static class SettingWidget {
		protected final Setting<?> setting;
		protected int lastX;
		protected int lastY;
		protected int lastWidth;

		protected SettingWidget(Setting<?> setting) {
			this.setting = setting;
		}

		public abstract void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta);

		public boolean mouseClicked(ClickGui gui, double mouseX, double mouseY, int button) {
			return false;
		}

		public void mouseReleased(double mouseX, double mouseY, int button) {
		}

		public void charTyped(char chr, int modifiers) {
		}

		public boolean keyPressed(int keyCode, int scanCode, int modifiers, ClickGui gui) {
			return false;
		}

		public float getHeight() {
			return SETTING_ROW_HEIGHT;
		}

		public boolean matches(String query) {
			return setting.getName().toString().toLowerCase().contains(query);
		}

		protected boolean isInside(double mouseX, double mouseY, int height) {
			return mouseX >= lastX && mouseX <= lastX + lastWidth && mouseY >= lastY && mouseY <= lastY + height;
		}

		public static SettingWidget create(Setting<?> setting) {

			String settingName = setting.getName().toString();
			if (settingName.equals("Window Alpha") || settingName.equals("Roundness")) {
				return null;
			}

			if (setting instanceof BooleanSetting booleanSetting) {
				return new BooleanWidget(booleanSetting);
			}
			if (setting instanceof NumberSetting numberSetting) {
				return new NumberWidget(numberSetting);
			}
			if (setting instanceof ModeSetting<?> modeSetting) {
				return new ModeWidget(modeSetting);
			}
			if (setting instanceof KeybindSetting keybindSetting) {
				return new BindWidget(keybindSetting);
			}
			if (setting instanceof StringSetting stringSetting) {
				return new StringWidget(stringSetting);
			}
			if (setting instanceof MinMaxSetting minMaxSetting) {
				return new MinMaxWidget(minMaxSetting);
			}
			return new LabelWidget(setting);
		}
	}

	private static class BooleanWidget extends SettingWidget {
		private final BooleanSetting booleanSetting;

		private BooleanWidget(BooleanSetting setting) {
			super(setting);
			this.booleanSetting = setting;
		}

		@Override
		public void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta) {
			this.lastX = x;
			this.lastY = y;
			this.lastWidth = width;

			String label = gui.fitSmallText(booleanSetting.getName().toString(), width - 20);
			TextRenderer.drawSmallString(label, context, x, y + 5, gui.getTextPrimary().getRGB());

			int boxSize = 12;
			int boxX = x + width - boxSize;
			int boxY = y + (SETTING_ROW_HEIGHT - boxSize) / 2;
			context.fill(boxX, boxY, boxX + boxSize, boxY + boxSize, gui.getHeaderBackground().getRGB());
			RenderUtils.drawRoundedOutline(context, boxX, boxY, boxSize, boxSize, 0, 1, gui.outlineColor);
			if (booleanSetting.getValue()) {
				context.fill(boxX + 3, boxY + 3, boxX + boxSize - 3, boxY + boxSize - 3, gui.getAccentColor().getRGB());
			}
		}

		@Override
		public boolean mouseClicked(ClickGui gui, double mouseX, double mouseY, int button) {
			if (button == 0 && isInside(mouseX, mouseY, (int) getHeight())) {
				booleanSetting.toggle();
				return true;
			}
			return false;
		}
	}

	private static class NumberWidget extends SettingWidget {
		private final NumberSetting numberSetting;
		private boolean sliding = false;

		private NumberWidget(NumberSetting setting) {
			super(setting);
			this.numberSetting = setting;
		}

		@Override
		public void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta) {
			this.lastX = x;
			this.lastY = y;
			this.lastWidth = width;

			String label = gui.fitSmallText(numberSetting.getName().toString(), width - 50);
			TextRenderer.drawSmallString(label, context, x, y + 5, gui.getTextPrimary().getRGB());
			String valueText = String.format("%.2f", numberSetting.getValue());
			int valueWidth = TextRenderer.getSmallWidth(valueText);
			TextRenderer.drawSmallString(valueText, context, x + width - valueWidth, y + 5, gui.getTextSecondary().getRGB());

			int sliderX = x;
			int sliderY = y + 14;
			int sliderWidth = width;
			int sliderHeight = 4;

			context.fill(sliderX, sliderY, sliderX + sliderWidth, sliderY + sliderHeight, new Color(55, 55, 65, 255).getRGB());

			double ratio = (numberSetting.getValue() - numberSetting.getMin()) / (numberSetting.getMax() - numberSetting.getMin());
			ratio = Math.max(0.0, Math.min(1.0, ratio));
			int fillWidth = (int) (sliderWidth * ratio);

			if (fillWidth > 0) {
				context.fill(sliderX, sliderY, sliderX + fillWidth, sliderY + sliderHeight, gui.getAccentColor().getRGB());
			}

			int dotX = sliderX + fillWidth - 4;
			int dotY = sliderY - 3;
			int dotSize = 10;

			context.fill(dotX, dotY, dotX + dotSize, dotY + dotSize, new Color(255, 255, 255, 255).getRGB());

			context.fill(dotX + 2, dotY + 2, dotX + dotSize - 2, dotY + dotSize - 2, gui.getAccentColor().getRGB());

			if (sliding) {
				double relative = Math.max(0.0, Math.min(1.0, (mouseX - sliderX) / (double) sliderWidth));
				double newValue = numberSetting.getMin() + relative * (numberSetting.getMax() - numberSetting.getMin());
				double increment = numberSetting.getIncrement();
				numberSetting.setValue(Math.round(newValue / increment) * increment);
			}
		}

		@Override
		public boolean mouseClicked(ClickGui gui, double mouseX, double mouseY, int button) {
			int sliderTop = lastY + 14;
			int sliderBottom = sliderTop + 12;
			if (button == 0 && mouseX >= lastX && mouseX <= lastX + lastWidth &&
				mouseY >= sliderTop && mouseY <= sliderBottom) {
				sliding = true;
				return true;
			}
			return false;
		}

		@Override
		public void mouseReleased(double mouseX, double mouseY, int button) {
			if (button == 0) {
				sliding = false;
			}
		}

		@Override
		public float getHeight() {
			return 28.0f;
		}
	}

	private static class ModeWidget extends SettingWidget {
		private final ModeSetting<?> modeSetting;

		private ModeWidget(ModeSetting<?> setting) {
			super(setting);
			this.modeSetting = setting;
		}

		@Override
		public void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta) {
			this.lastX = x;
			this.lastY = y;
			this.lastWidth = width;

			String label = gui.fitSmallText(modeSetting.getName().toString(), width - 60);
			TextRenderer.drawSmallString(label, context, x, y + 5, gui.getTextPrimary().getRGB());

			String value = gui.fitSmallText(modeSetting.getMode().toString(), 60);
			int valueWidth = TextRenderer.getSmallWidth(value);
			TextRenderer.drawSmallString(value, context, x + width - valueWidth, y + 5, gui.getTextSecondary().getRGB());
		}

		@Override
		public boolean mouseClicked(ClickGui gui, double mouseX, double mouseY, int button) {
			if (button == 0 && isInside(mouseX, mouseY, (int) getHeight())) {
				modeSetting.cycle();
				return true;
			}
			return false;
		}
	}

	private static class BindWidget extends SettingWidget {
		private final KeybindSetting keybindSetting;

		private BindWidget(KeybindSetting setting) {
			super(setting);
			this.keybindSetting = setting;
		}

		@Override
		public void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta) {
			this.lastX = x;
			this.lastY = y;
			this.lastWidth = width;

			String label = gui.fitSmallText(keybindSetting.getName().toString(), width - 60);
			TextRenderer.drawSmallString(label, context, x, y + 5, gui.getTextPrimary().getRGB());

			String value = gui.isListening(keybindSetting) ? "Press key..." : KeyUtils.getKey(keybindSetting.getKey()).toString();
			value = gui.fitSmallText(value, 70);
			int valueWidth = TextRenderer.getSmallWidth(value);
			Color valueColor = gui.isListening(keybindSetting) ? gui.getAccentColor() : gui.getTextSecondary();
			TextRenderer.drawSmallString(value, context, x + width - valueWidth, y + 5, valueColor.getRGB());
		}

		@Override
		public boolean mouseClicked(ClickGui gui, double mouseX, double mouseY, int button) {
			if (button == 0 && isInside(mouseX, mouseY, (int) getHeight())) {
				gui.startListening(keybindSetting);
				return true;
			}
			return false;
		}
	}

	private static class StringWidget extends SettingWidget {
		private final StringSetting stringSetting;

		private StringWidget(StringSetting setting) {
			super(setting);
			this.stringSetting = setting;
		}

		@Override
		public void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta) {
			this.lastX = x;
			this.lastY = y;
			this.lastWidth = width;

			String label = gui.fitSmallText(stringSetting.getName().toString(), width - 60);
			TextRenderer.drawSmallString(label, context, x, y + 5, gui.getTextPrimary().getRGB());

			String value = gui.fitSmallText(stringSetting.getValue(), 70);
			int valueWidth = TextRenderer.getSmallWidth(value);
			TextRenderer.drawSmallString(value, context, x + width - valueWidth, y + 5, gui.getTextSecondary().getRGB());
		}

		@Override
		public boolean mouseClicked(ClickGui gui, double mouseX, double mouseY, int button) {
			if (button == 0 && isInside(mouseX, mouseY, (int) getHeight())) {
				gui.beginStringEdit(stringSetting);
				return true;
			}
			return false;
		}
	}

	private static class MinMaxWidget extends SettingWidget {
		private final MinMaxSetting minMaxSetting;

		private MinMaxWidget(MinMaxSetting setting) {
			super(setting);
			this.minMaxSetting = setting;
		}

		@Override
		public void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta) {
			this.lastX = x;
			this.lastY = y;
			this.lastWidth = width;

			String label = gui.fitSmallText(minMaxSetting.getName().toString(), width - 60);
			TextRenderer.drawSmallString(label, context, x, y + 5, gui.getTextPrimary().getRGB());

			String values = String.format("%.1f - %.1f", minMaxSetting.getMinValue(), minMaxSetting.getMaxValue());
			values = gui.fitSmallText(values, 70);
			int valueWidth = TextRenderer.getSmallWidth(values);
			TextRenderer.drawSmallString(values, context, x + width - valueWidth, y + 5, gui.getTextSecondary().getRGB());
		}
	}

	private static class LabelWidget extends SettingWidget {

		private LabelWidget(Setting<?> setting) {
			super(setting);
	}

	@Override
		public void render(ClickGui gui, DrawContext context, int x, int y, int width, int mouseX, int mouseY, float delta) {
			this.lastX = x;
			this.lastY = y;
			this.lastWidth = width;

			String label = gui.fitSmallText(setting.getName().toString(), width);
			TextRenderer.drawSmallString(label, context, x, y + 5, gui.getTextPrimary().getRGB());
		}
	}
}
