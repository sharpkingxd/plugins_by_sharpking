package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class HasteEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, BukkitTask> sparkTasks;
    private final Map<UUID, Long> lastSparkTime;
    // Store original enchantments for each player's tool slot
    private final Map<UUID, Map<Integer, Map<Enchantment, Integer>>> originalEnchants = new HashMap<>();
    private static final long SPARK_DURATION = 15 * 1000; // 15 seconds in milliseconds
    private static final long SPARK_COOLDOWN = 60 * 1000; // 60 seconds in milliseconds
    
    public HasteEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.sparkTasks = new HashMap<>();
        this.lastSparkTime = new HashMap<>();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    @Override
    public void activatePassive(Player player) {
        safeRemoveAndAddHaste(player);
        saveAndApplyToolEnchantments(player);
        player.sendMessage(Component.text("⚒️ Haste Effect activated!")
                .color(NamedTextColor.YELLOW));
    }
    
    @Override
    public void deactivatePassive(Player player) {
        // Remove only our infinite-duration effect (like OceanEffect)
        PotionEffect effect = player.getPotionEffect(PotionEffectType.HASTE);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.HASTE);
        }
        restoreToolEnchantments(player);
        BukkitTask task = sparkTasks.remove(player.getUniqueId());
        if (task != null && !task.isCancelled()) {
            task.cancel();
        }
        player.sendMessage(Component.text("⚒️ Haste Effect deactivated!")
                .color(NamedTextColor.YELLOW));
    }
    
    @Override
    public void useSpark(Player player) {
        if (!hasHasteEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Haste effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        long currentTime = System.currentTimeMillis();
        if (lastSparkTime.containsKey(playerId)) {
            long timeLeft = SPARK_COOLDOWN - (currentTime - lastSparkTime.get(playerId));
            if (timeLeft > 0) {
                player.sendMessage(Component.text("❌ Haste Spark on cooldown! (" + (timeLeft / 1000) + "s)")
                        .color(NamedTextColor.RED));
                return;
            }
        }
        BukkitTask existingTask = sparkTasks.get(playerId);
        if (existingTask != null && !existingTask.isCancelled()) {
            existingTask.cancel();
        }
        // For spark, we want to override any effect, so we can apply directly
        player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 300, 4)); // Haste V for 15 seconds
        player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 1.0f, 1.5f);
        player.getWorld().spawnParticle(Particle.CRIT, 
            player.getLocation().add(0, 1, 0),
            30, 0.5, 0.5, 0.5, 0.1);
        BukkitTask sparkTask = new BukkitRunnable() {
            @Override
            public void run() {
                sparkTasks.remove(playerId);
                player.sendMessage(Component.text("⚒️ Haste Spark ended!")
                        .color(NamedTextColor.YELLOW));
                player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 0.8f);
            }
        }.runTaskLater(plugin, 300L);
        sparkTasks.put(playerId, sparkTask);
        lastSparkTime.put(playerId, currentTime);
        player.sendMessage(Component.text("⚒️ Haste Spark activated! Mining and attack speed increased!")
                .color(NamedTextColor.YELLOW));
    }
    
    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        // Check if target is a trusted player
        if (event.getEntity() instanceof Player target) {
            PlayerData playerData = plugin.getDataManager().getPlayerData(attacker.getUniqueId());
            if (playerData.isTrustedPlayer(target.getUniqueId())) {
                // Skip effects for trusted players
                return;
            }
        }
        
        // If spark is active, attack faster (simulate with slight damage boost)
        if (sparkTasks.containsKey(attacker.getUniqueId())) {
            event.setDamage(event.getDamage() * 1.25); // 25% more damage to simulate faster attacks
            
            // Visual effect
            event.getEntity().getWorld().spawnParticle(Particle.CRIT,
                event.getEntity().getLocation().add(0, 1, 0),
                10, 0.3, 0.3, 0.3, 0.1);
        }
    }
    
    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // Shield cooldown halved (handled in shield mechanics)
        if (event.getDamage() > 0 && defender.isBlocking()) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    defender.setCooldown(Material.SHIELD, 10); // Half of default 20 ticks
                }
            }.runTaskLater(plugin, 1L);
        }
    }
    
    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (!hasHasteEffect(player)) return;
        
        Block block = event.getBlock();
        
        // Vein miner when crouched
        if (player.isSneaking()) {
            performVeinMining(player, block);
        }
    }
    
    @EventHandler
    public void onItemDamage(PlayerItemDamageEvent event) {
        Player player = event.getPlayer();
        if (!hasHasteEffect(player)) return;
        
        // Reduce damage due to Unbreaking V
        if (event.getItem().getType().name().contains("PICKAXE") ||
            event.getItem().getType().name().contains("AXE") ||
            event.getItem().getType().name().contains("SHOVEL") ||
            event.getItem().getType().name().contains("HOE")) {
            
            if (Math.random() < 0.8) { // 80% chance to prevent damage
                event.setCancelled(true);
            }
        }
    }
    
    private void performVeinMining(Player player, Block originalBlock) {
        Material blockType = originalBlock.getType();
        
        // Only vein mine certain blocks
        if (!isVeinMineable(blockType)) return;
        
        List<Block> veinBlocks = findConnectedBlocks(originalBlock, blockType, new ArrayList<>(), 32);
        
        for (Block veinBlock : veinBlocks) {
            if (!veinBlock.equals(originalBlock)) {
                // Break the block with the same tool effects
                veinBlock.breakNaturally(player.getInventory().getItemInMainHand());
                
                // Visual effect
                veinBlock.getWorld().spawnParticle(Particle.CLOUD,
                    veinBlock.getLocation().add(0.5, 0.5, 0.5),
                    10, 0.3, 0.3, 0.3, 0);
                
                // Add slight delay for visual effect
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        if (veinBlock.getType() == blockType) {
                            veinBlock.breakNaturally(player.getInventory().getItemInMainHand());
                        }
                    }
                }.runTaskLater(plugin, 1L);
            }
        }
        
        if (veinBlocks.size() > 1) {
            player.sendMessage(Component.text("⚒️ Vein mined " + veinBlocks.size() + " blocks!")
                    .color(NamedTextColor.YELLOW));
            player.playSound(player.getLocation(), Sound.BLOCK_CHAIN_BREAK, 1.0f, 1.0f);
        }
    }
    
    private boolean isVeinMineable(Material material) {
        return material.name().contains("ORE") || 
               material.name().contains("LOG") ||
               material.name().contains("LEAVES") ||
               material == Material.COAL_BLOCK ||
               material == Material.IRON_BLOCK ||
               material == Material.GOLD_BLOCK ||
               material == Material.DIAMOND_BLOCK ||
               material == Material.EMERALD_BLOCK ||
               material == Material.ANCIENT_DEBRIS;
    }
    
    private List<Block> findConnectedBlocks(Block start, Material type, List<Block> found, int maxBlocks) {
        if (found.size() >= maxBlocks || found.contains(start)) {
            return found;
        }
        
        if (start.getType() != type) {
            return found;
        }
        
        found.add(start);
        
        // Check adjacent blocks
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    if (x == 0 && y == 0 && z == 0) continue;
                    
                    Block adjacent = start.getRelative(x, y, z);
                    findConnectedBlocks(adjacent, type, found, maxBlocks);
                }
            }
        }
        
        return found;
    }
    
    private void saveAndApplyToolEnchantments(Player player) {
        UUID uuid = player.getUniqueId();
        Map<Integer, Map<Enchantment, Integer>> playerEnchants = new HashMap<>();
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item != null && isTool(item.getType())) {
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    // Save original enchants
                    Map<Enchantment, Integer> enchants = new HashMap<>(meta.getEnchants());
                    playerEnchants.put(i, enchants);
                    // Apply/upgrade custom enchants
                    if (meta.getEnchantLevel(Enchantment.FORTUNE) < 5) {
                        meta.addEnchant(Enchantment.FORTUNE, 5, true);
                    }
                    if (meta.getEnchantLevel(Enchantment.UNBREAKING) < 5) {
                        meta.addEnchant(Enchantment.UNBREAKING, 5, true);
                    }
                    if (meta.getEnchantLevel(Enchantment.EFFICIENCY) < 10) {
                        meta.addEnchant(Enchantment.EFFICIENCY, 10, true);
                    }
                    item.setItemMeta(meta);
                }
            }
        }
        originalEnchants.put(uuid, playerEnchants);
    }

    private void restoreToolEnchantments(Player player) {
        UUID uuid = player.getUniqueId();
        Map<Integer, Map<Enchantment, Integer>> playerEnchants = originalEnchants.remove(uuid);
        if (playerEnchants == null) return;
        ItemStack[] contents = player.getInventory().getContents();
        for (Map.Entry<Integer, Map<Enchantment, Integer>> entry : playerEnchants.entrySet()) {
            int slot = entry.getKey();
            if (slot < 0 || slot >= contents.length) continue;
            ItemStack item = contents[slot];
            if (item != null && isTool(item.getType())) {
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    // Remove all custom enchants
                    meta.removeEnchant(Enchantment.FORTUNE);
                    meta.removeEnchant(Enchantment.UNBREAKING);
                    meta.removeEnchant(Enchantment.EFFICIENCY);
                    // Restore original enchants
                    for (Map.Entry<Enchantment, Integer> ench : entry.getValue().entrySet()) {
                        meta.addEnchant(ench.getKey(), ench.getValue(), true);
                    }
                    item.setItemMeta(meta);
                }
            }
        }
    }
    
    private boolean isTool(Material material) {
        String name = material.name();
        return name.contains("PICKAXE") || name.contains("AXE") || name.contains("SHOVEL") || 
               name.contains("HOE") || name.contains("SWORD");
    }
    
    private boolean hasHasteEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.HASTE && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.HASTE && data.isSecondaryEnabled());
    }
    
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (hasHasteEffect(player)) {
            PotionEffect effect = player.getPotionEffect(PotionEffectType.HASTE);
            if (effect != null && effect.getDuration() > 9999) {
                player.removePotionEffect(PotionEffectType.HASTE);
            }
        }
        UUID playerId = player.getUniqueId();
        BukkitTask task = sparkTasks.remove(playerId);
        if (task != null && !task.isCancelled()) {
            task.cancel();
        }
        lastSparkTime.remove(playerId);
    }
    
    @EventHandler
    public void onPotionDrain(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        if (hasHasteEffect(player)) {
            PotionEffect effect = player.getPotionEffect(PotionEffectType.HASTE);
            if (effect != null && effect.getDuration() > 9999) {
                player.removePotionEffect(PotionEffectType.HASTE);
            }
        }
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (hasHasteEffect(player)) {
            safeRemoveAndAddHaste(player);
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        PotionEffect effect = player.getPotionEffect(PotionEffectType.HASTE);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.HASTE);
        }
        UUID playerId = player.getUniqueId();
        BukkitTask task = sparkTasks.remove(playerId);
        if (task != null && !task.isCancelled()) {
            task.cancel();
        }
        lastSparkTime.remove(playerId);
    }
    
    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        new BukkitRunnable() {
            @Override
            public void run() {
                if (hasHasteEffect(player)) {
                    safeRemoveAndAddHaste(player);
                }
            }
        }.runTaskLater(plugin, 1L);
    }

    private void safeRemoveAndAddHaste(Player player) {
        PotionEffect effect = player.getPotionEffect(PotionEffectType.HASTE);
        if (effect == null || effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.HASTE);
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, Integer.MAX_VALUE, 1));
        }
    }
}
