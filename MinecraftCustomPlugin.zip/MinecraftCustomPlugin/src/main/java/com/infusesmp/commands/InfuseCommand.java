package com.infusesmp.commands;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class InfuseCommand implements CommandExecutor, TabCompleter {
    
    private final InfuseSMPPlugin plugin;
    
    public InfuseCommand(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("resetpotioncounter")) {
            if (!sender.hasPermission("infuse.admin")) {
                sender.sendMessage(Component.text("You don't have permission to use this command!").color(NamedTextColor.RED));
                return true;
            }
            if (args.length != 1) {
                sender.sendMessage(Component.text("Usage: /resetpotioncounter <potionname>").color(NamedTextColor.RED));
                return true;
            }
            PotionType type = PotionType.fromString(args[0]);
            if (type == null) {
                sender.sendMessage(Component.text("Invalid potion type! Available: " + java.util.Arrays.toString(PotionType.values())).color(NamedTextColor.RED));
                return true;
            }
            plugin.getPotionCounterManager().reset(type);
            sender.sendMessage(Component.text("Reset craft counter for " + type.getDisplayName()).color(NamedTextColor.GREEN));
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.isOp() || p.hasPermission("infuse.admin")) {
                    p.sendMessage(Component.text("[InfuseSMP] " + sender.getName() + " reset the craft counter for " + type.getDisplayName()).color(NamedTextColor.YELLOW));
                }
            }
            return true;
        }
        
        if (!sender.hasPermission("infuse.admin")) {
            sender.sendMessage(Component.text("You don't have permission to use this command!")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        if (args.length < 3) {
            sender.sendMessage(Component.text("Usage: /infuse effects give <player> <all|potionName>")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        if (!args[0].equalsIgnoreCase("effects") || !args[1].equalsIgnoreCase("give")) {
            sender.sendMessage(Component.text("Usage: /infuse effects give <player> <all|potionName>")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        Player target = Bukkit.getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage(Component.text("Player not found!")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        String potionName = args[3];
        
        if (potionName.equalsIgnoreCase("all")) {
            // Give all potions
            for (PotionType type : PotionType.values()) {
                ItemStack potion = plugin.getPotionManager().createPotionItem(type);
                if (potion != null) {
                    target.getInventory().addItem(potion);
                }
            }
            
            sender.sendMessage(Component.text("Gave all infuse potions to " + target.getName())
                    .color(NamedTextColor.GREEN));
            target.sendMessage(Component.text("You have been given all infuse potions!")
                    .color(NamedTextColor.GREEN));
        } else {
            // Give specific potion
            PotionType type = PotionType.fromString(potionName);
            if (type == null) {
                sender.sendMessage(Component.text("Invalid potion type! Available: " + 
                        Arrays.toString(PotionType.values()))
                        .color(NamedTextColor.RED));
                return true;
            }
            
            ItemStack potion = plugin.getPotionManager().createPotionItem(type);
            if (potion != null) {
                target.getInventory().addItem(potion);
                
                sender.sendMessage(Component.text("Gave " + type.getDisplayName() + " to " + target.getName())
                        .color(NamedTextColor.GREEN));
                target.sendMessage(Component.text("You have been given " + type.getDisplayName() + "!")
                        .color(NamedTextColor.GREEN));
            } else {
                sender.sendMessage(Component.text("Failed to create potion!")
                        .color(NamedTextColor.RED));
            }
        }
        
        return true;
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (!sender.hasPermission("infuse.admin")) {
            return completions;
        }
        
        if (command.getName().equalsIgnoreCase("resetpotioncounter")) {
            if (args.length == 1) {
                String partial = args[0].toLowerCase();
                for (PotionType type : PotionType.values()) {
                    String name = type.name().toLowerCase();
                    if (name.startsWith(partial)) {
                        // Only add the name itself for proper tab completion
                        completions.add(name);
                    }
                }
            }
            return completions;
        }
        
        if (args.length == 1) {
            completions.add("effects");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("effects")) {
            completions.add("give");
        } else if (args.length == 3 && args[0].equalsIgnoreCase("effects") && args[1].equalsIgnoreCase("give")) {
            // Player names
            for (Player player : Bukkit.getOnlinePlayers()) {
                completions.add(player.getName());
            }
        } else if (args.length == 4 && args[0].equalsIgnoreCase("effects") && args[1].equalsIgnoreCase("give")) {
            // Potion types
            completions.add("all");
            for (PotionType type : PotionType.values()) {
                completions.add(type.name().toLowerCase());
            }
        }
        
        return completions;
    }
}
