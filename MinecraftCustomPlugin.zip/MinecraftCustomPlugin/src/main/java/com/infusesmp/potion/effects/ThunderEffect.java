package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData; // Add this import
import com.infusesmp.potion.PotionType;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class ThunderEffect implements PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Integer> hitCounter = new HashMap<>();
    private final Map<UUID, Set<UUID>> smiteCounter = new HashMap<>();
    private static final int HITS_FOR_STRIKE = 10;
    private static final int HITS_FOR_STRIKE_RAIN = 5;
    private static final double CHAIN_RANGE = 5.0;
    private static final double SPARK_RANGE = 10.0;
    private static final int MAX_SMITES_PER_PLAYER = 3;
    private static final double SMITE_DAMAGE = 4.0; // 2 hearts

    public ThunderEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void activatePassive(Player player) {
        hitCounter.put(player.getUniqueId(), 0);
    }

    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        hitCounter.remove(playerId);
        smiteCounter.remove(playerId);
    }

    @Override
    public void useSpark(Player player) {
        if (!hasThunderEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Thunder effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        World world = player.getWorld();
        Location playerLoc = player.getLocation();
    
        // Initialize smite counter for this spark use
        smiteCounter.put(playerId, new HashSet<>());
    
        // Get nearby players
        List<Entity> nearbyEntities = player.getNearbyEntities(SPARK_RANGE, SPARK_RANGE, SPARK_RANGE);
        
        // Strike each nearby player 3 times
        for (Entity entity : nearbyEntities) {
            if (entity instanceof Player target && !target.equals(player)) {
                // Check if target is a trusted player
                PlayerData playerData = plugin.getDataManager().getPlayerData(player.getUniqueId());
                if (playerData.isTrustedPlayer(target.getUniqueId())) {
                    // Skip damage for trusted players
                    continue;
                }
                
                // Strike lightning 3 times with delay
                new BukkitRunnable() {
                    int strikes = 0;
                    
                    @Override
                    public void run() {
                        if (strikes >= 3 || !target.isOnline()) {
                            cancel();
                            return;
                        }
                        
                        // Apply smite damage
                        target.damage(SMITE_DAMAGE, player);
                        world.strikeLightningEffect(target.getLocation());
                        
                        // Visual and sound effects
                        world.playSound(target.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0f, 1.0f);
                        target.sendMessage(Component.text("⚡ You've been struck by thunder! (" + (strikes + 1) + "/3)")
                                .color(NamedTextColor.YELLOW));
                        
                        strikes++;
                    }
                }.runTaskTimer(plugin, 0L, 10L); // Strike every 0.5 seconds (10 ticks)
            }
        }

        // Visual and sound effects for caster
        world.strikeLightningEffect(playerLoc);
        world.playSound(playerLoc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
        player.sendMessage(Component.text("⚡ Thunder Spark activated!")
                .color(NamedTextColor.YELLOW));
    }

    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        int hits = hitCounter.getOrDefault(attackerId, 0) + 1;
        hitCounter.put(attackerId, hits);
        int threshold = attacker.getWorld().hasStorm() ? HITS_FOR_STRIKE_RAIN : HITS_FOR_STRIKE;
        if (hits >= threshold) {
            hitCounter.put(attackerId, 0);
            // Only strike lightning once per threshold
            if (event.getEntity() instanceof Player target) {
                target.getWorld().strikeLightningEffect(target.getLocation());
                attacker.sendMessage(Component.text("⚡ Thunder strikes after " + threshold + " hits!").color(NamedTextColor.YELLOW));
            }
        }
    }

    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // No special defense handling needed
    }

    @EventHandler
    public void onProjectileLaunch(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof Trident trident)) return;
        if (!(event.getEntity().getShooter() instanceof Player player)) return;

        // Check if player has thunder effect
        if (!hasThunderEffect(player)) return;

        // Tag the trident for later identification
        trident.setGlowing(true);
        trident.customName(Component.text("Thunder Trident").color(NamedTextColor.YELLOW));
    }

    @EventHandler
    public void onTridentHit(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Trident trident)) return;
        if (!(trident.getShooter() instanceof Player attacker)) return;
        if (!(event.getEntity() instanceof Player target)) return;

        // Check if it's a thunder trident
        if (!trident.isGlowing() || !hasThunderEffect(attacker)) return;

        // Smite the target
        smitePlayer(attacker, target);
    }

    private void smitePlayer(Player attacker, Player target) {
        UUID attackerId = attacker.getUniqueId();
        UUID targetId = target.getUniqueId();
        World world = target.getWorld();
    
        // Check if target is a trusted player
        PlayerData playerData = plugin.getDataManager().getPlayerData(attacker.getUniqueId());
        if (playerData.isTrustedPlayer(targetId)) {
            // Skip damage for trusted players
            return;
        }
    
        // Check if target has been smited too many times
        Set<UUID> smitedPlayers = smiteCounter.getOrDefault(attackerId, new HashSet<>());
        if (smitedPlayers.contains(targetId) && smitedPlayers.size() >= MAX_SMITES_PER_PLAYER) {
            return;
        }
    
        // Apply smite damage
        target.damage(SMITE_DAMAGE, attacker);
        world.strikeLightningEffect(target.getLocation());
        
        // Add target to smited players set
        smitedPlayers.add(targetId);
        smiteCounter.put(attackerId, smitedPlayers);
    
        // Visual and sound effects
        world.playSound(target.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0f, 1.0f);
        target.sendMessage(Component.text("⚡ You've been struck by thunder!")
                .color(NamedTextColor.YELLOW));
    }

    private boolean hasThunderEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.THUNDER && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.THUNDER && data.isSecondaryEnabled());
    }
}
