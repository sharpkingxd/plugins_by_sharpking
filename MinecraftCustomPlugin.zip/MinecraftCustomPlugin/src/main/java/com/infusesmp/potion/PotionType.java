package com.infusesmp.potion;

import org.bukkit.Material;

public enum PotionType {
    REGEN("Regen Infuse Potion", "💗", Material.GHAST_TEAR, false, 1001),
    FEATHER("Feather Infuse Potion", "🪶", Material.FEATHER, false, 1002),
    THUNDER("Thunder Infuse Potion", "⚡", Material.LIGHTNING_ROD, true, 1003),
    STRENGTH("Strength Infuse Potion", "💪", Material.BLAZE_ROD, true, 1004),
    HEART("Heart Infuse Potion", "❤️‍🔥", Material.GOLDEN_APPLE, true, 1005),
    FROST("Frost Infuse Potion", "❄️", Material.SNOWBALL, true, 1006),
    EMERALD("Emerald Infuse Potion", "💚", Material.EMERALD, false, 1007),
    OCEAN("Ocean Infuse Potion", "🌊", Material.PRISMARINE, false, 1008),
    FIRE("Fire Infuse Potion", "🔥", Material.BLAZE_POWDER, true, 1009),
    SPEED("Speed Infuse Potion", "🏃", Material.SUGAR, true, 1010),
    HASTE("Haste Infuse Potion", "⛏️", Material.GOLDEN_PICKAXE, true, 1011),
    INVIS("Invis Infuse Potion", "🫥", Material.FERMENTED_SPIDER_EYE, false, 1012);
    
    private final String displayName;
    private final String icon;
    private final Material representativeMaterial;
    private final boolean isPrimary; // true for primary effects, false for secondary
    private final int customModelData;
    
    PotionType(String displayName, String icon, Material representativeMaterial, boolean isPrimary, int customModelData) {
        this.displayName = displayName;
        this.icon = icon;
        this.representativeMaterial = representativeMaterial;
        this.isPrimary = isPrimary;
        this.customModelData = customModelData;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public String getIcon() {
        return icon;
    }
    
    public Material getRepresentativeMaterial() {
        return representativeMaterial;
    }
    
    public boolean isPrimary() {
        return isPrimary;
    }
    
    public int getCustomModelData() {
        return customModelData;
    }
    
    public static PotionType fromString(String name) {
        for (PotionType type : values()) {
            if (type.name().equalsIgnoreCase(name)) {
                return type;
            }
        }
        return null;
    }
}
