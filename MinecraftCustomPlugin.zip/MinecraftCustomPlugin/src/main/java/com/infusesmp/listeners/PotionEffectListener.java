package com.infusesmp.listeners;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import com.infusesmp.potion.effects.InvisEffect;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PotionEffectListener implements Listener {
    
    private final InfuseSMPPlugin plugin;
    
    public PotionEffectListener(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPotionEffectChange(EntityPotionEffectEvent event) {
        // Only care about players
        if (!(event.getEntity() instanceof Player player)) return;
        
        // Only care about effect removals
        if (event.getAction() != EntityPotionEffectEvent.Action.REMOVED && 
            event.getAction() != EntityPotionEffectEvent.Action.CLEARED) return;
        
        // Get the effect type and old effect
        PotionEffectType effectType = event.getModifiedType();
        PotionEffect oldEffect = event.getOldEffect();
        
        // If there's no old effect, nothing to preserve
        if (oldEffect == null) return;
        
        // Get player data
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        
        // Check if this is one of our custom effects that needs to be preserved
        boolean shouldPreserve = false;
        
        // Only check for custom effects that we want to preserve
        // AND make sure it's our infinite duration effect (>9999 ticks)
        if (oldEffect.getDuration() > 9999) {
            if (effectType == PotionEffectType.STRENGTH && 
                oldEffect.getAmplifier() == 1 && // Our strength effect uses amplifier 1
                ((data.getPrimaryPotion() == PotionType.STRENGTH && data.isPrimaryEnabled()) ||
                 (data.getSecondaryPotion() == PotionType.STRENGTH && data.isSecondaryEnabled()))) {
                shouldPreserve = true;
            } 
            else if (effectType == PotionEffectType.HASTE && 
                     oldEffect.getAmplifier() == 1 && // Our haste effect uses amplifier 1
                     ((data.getPrimaryPotion() == PotionType.HASTE && data.isPrimaryEnabled()) ||
                      (data.getSecondaryPotion() == PotionType.HASTE && data.isSecondaryEnabled()))) {
                shouldPreserve = true;
            } 
            else if (effectType == PotionEffectType.INVISIBILITY) {
                // Special case for invisibility - use the InvisEffect handler to check
                var effectManager = plugin.getEffectManager();
                var invisHandler = effectManager.getEffectHandler(PotionType.INVIS);
                
                if (invisHandler instanceof InvisEffect invisEffect) {
                    // Only preserve if it's our effect (infinite duration and amplifier 0)
                    if (oldEffect.getAmplifier() == 0 && invisEffect.hasInvisEffect(player)) {
                        shouldPreserve = true;
                    }
                }
            }
            else if (effectType == PotionEffectType.FIRE_RESISTANCE && 
                     oldEffect.getAmplifier() == 0 && // Fire effect uses amplifier 0
                     ((data.getPrimaryPotion() == PotionType.FIRE && data.isPrimaryEnabled()) ||
                      (data.getSecondaryPotion() == PotionType.FIRE && data.isSecondaryEnabled()))) {
                shouldPreserve = true;
            }
        }
        
        // Only preserve if it's our custom effect
        if (shouldPreserve) {
            event.setCancelled(true);
        }
    }
}