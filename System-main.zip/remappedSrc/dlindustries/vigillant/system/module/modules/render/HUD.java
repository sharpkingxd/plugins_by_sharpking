package dlindustries.vigillant.system.module.modules.render;

import dlindustries.vigillant.system.event.events.HudListener;
import dlindustries.vigillant.system.gui.ClickGui;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.RenderUtils;
import dlindustries.vigillant.system.utils.TextRenderer;
import dlindustries.vigillant.system.utils.Utils;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.awt.*;
import java.util.List;

public final class HUD extends Module implements HudListener {
	public enum ImageOption {
		CAT("cat.png"),
		COLD("cold.png"),
		FRIEREN("frieren.png"),
		JOE("joe.png"),
		SKIBIDI("skibidi.png"),
		JOHN("john.png"),
		NUMBERCRAC("67.png");

		private final String fileName;

		ImageOption(String fileName) {
			this.fileName = fileName;
		}

		public String getFileName() {
			return fileName;
		}
	}

	private static final CharSequence system = EncryptedString.of("System |");
	private final BooleanSetting info = new BooleanSetting(EncryptedString.of("Info"), true);
	private final BooleanSetting modules = new BooleanSetting("Modules", false)
			.setDescription(EncryptedString.of("Renders module array list"));

	private final ModeSetting<ImageOption> imageMode = new ModeSetting<>(
			EncryptedString.of("Image"),
			ImageOption.CAT,
			ImageOption.class
	).setDescription(EncryptedString.of("Choose which image to display in HUD"));

	public HUD() {
		super(EncryptedString.of("HUD"),
				EncryptedString.of("Overlay the system as you play"),
				-1,
				Category.RENDER);
		addSettings(info, modules, imageMode);
	}

	@Override
	public void onEnable() {
		eventManager.add(HudListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(HudListener.class, this);
		super.onDisable();
	}
	@Override
	public void onRenderHud(HudEvent event) {
		if (mc.currentScreen != dlindustries.vigillant.system.system.INSTANCE.clickGui) {
			DrawContext context = event.context;

			if (!(mc.currentScreen instanceof ClickGui)) {
				if (info.getValue() && mc.player != null) {

					String playerName = mc.player.getName().getString();
					dlindustries.vigillant.system.module.modules.client.NameProtect nameProtect =
							dlindustries.vigillant.system.system.INSTANCE.getModuleManager().getModule(
									dlindustries.vigillant.system.module.modules.client.NameProtect.class);
					if (nameProtect != null) {
						playerName = nameProtect.replaceName(playerName);
					}

					String serverName = (mc.getCurrentServerEntry() == null ? "None" : mc.getCurrentServerEntry().address);

					String headerText = "System";
					String usernameText = playerName;
					String serverText = serverName;

					int headerWidth = TextRenderer.getWidth(headerText);
					int usernameWidth = TextRenderer.getWidth(usernameText);
					int serverWidth = TextRenderer.getWidth(serverText);
					int maxTextWidth = Math.max(Math.max(headerWidth, usernameWidth), serverWidth);

					int boxX = 10;
					int boxY = 10;
					int boxPaddingX = 16;
					int boxPaddingY = 12;
					int lineSpacing = 4;
					int boxWidth = maxTextWidth + (boxPaddingX * 2);
					int boxHeight = (mc.textRenderer.fontHeight * 3) + (lineSpacing * 2) + (boxPaddingY * 2);

					int cornerRadius = 10;
					int cornerSegments = 20;

					Color panelBg = new Color(35, 35, 42, 255);
					Color outlineColor = new Color(255, 255, 255, 200);
					Color headerColor = Utils.getMainColor(255, 0);
					Color textColor = new Color(255, 255, 255, 255);
					Color secondaryTextColor = new Color(180, 180, 190, 255);

					MatrixStack matrices = new MatrixStack();
					RenderUtils.renderRoundedQuad(
							matrices,
							panelBg,
							boxX,
							boxY,
							boxX + boxWidth,
							boxY + boxHeight,
							cornerRadius,
							cornerSegments
					);

					RenderUtils.drawRoundedOutline(
							context,
							boxX, boxY, boxWidth, boxHeight,
							cornerRadius, 1,
							outlineColor
					);

					int headerX = boxX + boxPaddingX;
					int headerY = boxY + boxPaddingY;
					TextRenderer.drawString(
							headerText,
							context,
							headerX,
							headerY,
							headerColor.getRGB()
					);

					int usernameX = boxX + boxPaddingX;
					int usernameY = headerY + mc.textRenderer.fontHeight + lineSpacing;
					TextRenderer.drawString(
							usernameText,
							context,
							usernameX,
							usernameY,
							textColor.getRGB()
					);

					int serverX = boxX + boxPaddingX;
					int serverY = usernameY + mc.textRenderer.fontHeight + lineSpacing;
					TextRenderer.drawString(
							serverText,
							context,
							serverX,
							serverY,
							secondaryTextColor.getRGB()
					);
				}

				if (modules.getValue()) {

					int offset = 10 + (mc.textRenderer.fontHeight * 3) + (4 * 2) + (12 * 2) + 10;
					List<Module> enabledModules = dlindustries.vigillant.system.system.INSTANCE
							.getModuleManager()
							.getEnabledModules()
							.stream()
							.sorted((m1, m2) ->
									Integer.compare(
											TextRenderer.getWidth(m2.getName()),
											TextRenderer.getWidth(m1.getName())
									)
							)
							.toList();

					Color modulePanelBg = new Color(35, 35, 42, 255);
					Color moduleOutlineColor = new Color(255, 255, 255, 200);
					int moduleCornerRadius = 8;
					int moduleCornerSegments = 15;

					int moduleHeight = (int)(mc.textRenderer.fontHeight * 1.5);
					int modulePadding = 3;

					for (Module module : enabledModules) {

						int charOffset = 6 + TextRenderer.getWidth(module.getName());

						MatrixStack matrices = new MatrixStack();
						RenderUtils.renderRoundedQuad(
								matrices,
								modulePanelBg,
								0,
								offset - modulePadding,
								charOffset + 8,
								offset + moduleHeight + modulePadding,
								moduleCornerRadius,
								moduleCornerSegments
						);

						RenderUtils.drawRoundedOutline(
								context,
								0,
								offset - modulePadding,
								charOffset + 8,
								offset + moduleHeight + modulePadding,
								moduleCornerRadius, 1,
								moduleOutlineColor
						);

						Color accentColor = Utils.getMainColor(255, enabledModules.indexOf(module));
						context.fillGradient(
								0,
								offset - modulePadding,
								3,
								offset + moduleHeight + modulePadding,
								accentColor.getRGB(),
								Utils.getMainColor(255, enabledModules.indexOf(module) + 1).getRGB()
						);

						int charOffset2 = 8;

						Color moduleTextColor = new Color(255, 255, 255, 255);
						TextRenderer.drawString(
								module.getName(),
								context,
								charOffset2,
								offset + 1,
								moduleTextColor.getRGB()
						);

						offset += moduleHeight + 4;
					}
				}
			}
		}
	}

}