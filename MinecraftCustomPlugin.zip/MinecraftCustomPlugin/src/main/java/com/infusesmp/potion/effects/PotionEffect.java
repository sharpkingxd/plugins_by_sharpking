package com.infusesmp.potion.effects;

import org.bukkit.entity.Player;

public interface PotionEffect {
    void activatePassive(Player player);
    void deactivatePassive(Player player);
    void useSpark(Player player);
    default boolean shouldTriggerSpark(Player player) {
        return player.isSneaking() && player.isBlocking();
    }
} 