package com.infusesmp.utils;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.Particle;
import org.bukkit.Color;
import org.bukkit.util.Vector;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scheduler.BukkitRunnable;
import com.infusesmp.InfuseSMPPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BeaconBeamUtil {
    private static final Map<Location, BukkitTask> activeBeams = new HashMap<>();
    private final InfuseSMPPlugin plugin;

    public BeaconBeamUtil(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
    }
    
    /**
     * Spawns a vertical column of particles above the given location, creating a ritual beam effect.
     * @param location The base location (brewing stand)
     * @param height The height of the beam
     */
    public static void showParticleBeam(Location location, int height) {
        World world = location.getWorld();
        if (world == null) return;
    
        // Cancel any existing beam at this location
        removeBeaconBeam(location);
    
        // Create a new beam task
        BukkitTask task = new BukkitRunnable() {
            double angle = 0;
            
            @Override
            public void run() {
                double baseX = location.getBlockX() + 0.5;
                double baseZ = location.getBlockZ() + 0.5;
    
                // Main beam particles - using END_ROD for a bright central beam that passes through blocks
                for (int y = 0; y < height; y += 2) { // Increased spacing to reduce particles
                    double yPos = location.getBlockY() + 1 + y;
                    // Skip the very base (brewing stand head) for all special particles
                    boolean isBase = (y == 0);
                    
                    // Central beam using END_ROD particles - reduced count but still visible
                    if (!isBase) {
                        // Core beam - reduced particle count
                        world.spawnParticle(Particle.END_ROD, 
                            baseX, yPos, baseZ, 
                            3, 0.05, 0.05, 0.05, 0.01);
                    } else {
                        // At the very base, spawn only a single END_ROD for continuity
                        world.spawnParticle(Particle.END_ROD, 
                            baseX, yPos, baseZ, 
                            1, 0.01, 0.01, 0.01, 0.001);
                    }
                    
                    // Add SOUL_FIRE_FLAME particles less frequently but still visible
                    if (!isBase && y % 8 == 0) {
                        world.spawnParticle(Particle.SOUL_FIRE_FLAME,
                            baseX, yPos, baseZ,
                            2, 0.08, 0.08, 0.08, 0.01);
                    }
                    
                    // Add FLASH particles for visibility from afar, but much less frequently
                    if (!isBase && y % 30 == 0) {
                        world.spawnParticle(Particle.FLASH,
                            baseX, yPos, baseZ,
                            1, 0.05, 0.05, 0.05, 0);
                    }
                    
                    // Create spiral effects with fewer layers and particles
                    if (y % 4 == 0) { // Only create spirals every 4 blocks
                        for (int layer = 0; layer < 2; layer++) { // Reduced from 8 to 2 layers
                            double spiralRadius = 0.3 + (layer * 0.15);
                            // First spiral
                            double spiralX1 = baseX + spiralRadius * Math.cos(angle + (y * 0.2));
                            double spiralZ1 = baseZ + spiralRadius * Math.sin(angle + (y * 0.2));
                            world.spawnParticle(Particle.DUST_COLOR_TRANSITION, 
                                spiralX1, yPos, spiralZ1, 
                                1, 0.02, 0.02, 0.02, 0.01,
                                new Particle.DustTransition(Color.fromRGB(255, 0, 255), Color.fromRGB(0, 255, 255), 1.0f));
                            
                            // Second spiral (opposite direction)
                            double spiralX2 = baseX + spiralRadius * Math.cos(-angle + (y * 0.2));
                            double spiralZ2 = baseZ + spiralRadius * Math.sin(-angle + (y * 0.2));
                            world.spawnParticle(Particle.DUST_COLOR_TRANSITION, 
                                spiralX2, yPos, spiralZ2, 
                                1, 0.02, 0.02, 0.02, 0.01,
                                new Particle.DustTransition(Color.fromRGB(0, 255, 255), Color.fromRGB(255, 0, 255), 1.0f));
                        }
                    }
                    
                    // Add ring effects at intervals but much less frequently
                    if (!isBase && y % 20 == 0) { // Reduced frequency from 8 to 20
                        for (int ring = 0; ring < 2; ring++) { // Reduced from 4 to 2 rings
                            double ringRadius = 0.4 + (ring * 0.2);
                            for (int i = 0; i < 8; i++) { // Reduced from 16 to 8 points
                                double ringAngle = 2 * Math.PI * i / 8;
                                double ringX = baseX + ringRadius * Math.cos(ringAngle);
                                double ringZ = baseZ + ringRadius * Math.sin(ringAngle);
                                world.spawnParticle(Particle.DUST_COLOR_TRANSITION, 
                                    ringX, yPos, ringZ, 
                                    1, 0.02, 0.02, 0.02, 0.01,
                                    new Particle.DustTransition(Color.fromRGB(255, 255, 0), Color.fromRGB(255, 0, 255), 1.0f));
                            }
                        }
                    }
                }
            // Increment angle for spiral rotation
            angle += 0.1;
        }
    }.runTaskTimer(InfuseSMPPlugin.getInstance(), 0L, 4L); // Run every 4 ticks instead of 2
    
    // Store the task for later cancellation
    activeBeams.put(location, task);
}
    
    public static void removeBeaconBeam(Location location) {
        BukkitTask task = activeBeams.remove(location);
        if (task != null) {
            task.cancel();
        }
    }
    
    public static void removeAllBeaconBeams() {
        for (BukkitTask task : activeBeams.values()) {
            task.cancel();
        }
        activeBeams.clear();
    }
}
