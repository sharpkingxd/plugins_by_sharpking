package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.Sound;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.Particle;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public class StrengthEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Long> shieldDisabledPlayers = new HashMap<>();
    private final Map<UUID, Long> autoCritPlayers = new HashMap<>();
    private final Map<UUID, Long> lastRegenTime = new HashMap<>();
    private static final long SHIELD_DISABLE_DURATION = 10 * 1000; // 10 seconds in milliseconds
    private static final long AUTO_CRIT_DURATION = 15 * 1000; // 15 seconds in milliseconds
    private static final long REGEN_COOLDOWN = 3000; // 3 seconds in ms

    public StrengthEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        startCleanupTask();
    }

    private void startCleanupTask() {
        // Cleanup expired entries every second
        new BukkitRunnable() {
            @Override
            public void run() {
                long currentTime = System.currentTimeMillis();
                shieldDisabledPlayers.entrySet().removeIf(entry -> 
                    currentTime - entry.getValue() > SHIELD_DISABLE_DURATION);
                autoCritPlayers.entrySet().removeIf(entry -> 
                    currentTime - entry.getValue() > AUTO_CRIT_DURATION);
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    @Override
    public void activatePassive(Player player) {
        safeRemoveAndAddStrength(player);
        player.sendMessage(Component.text("💪 Strength Effect activated!")
                .color(NamedTextColor.RED));
    }

    @Override
    public void deactivatePassive(Player player) {
        // Remove only our infinite-duration effect (like OceanEffect)
        PotionEffect effect = player.getPotionEffect(PotionEffectType.STRENGTH);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.STRENGTH);
        }
        UUID playerId = player.getUniqueId();
        shieldDisabledPlayers.remove(playerId);
        autoCritPlayers.remove(playerId);
        player.sendMessage(Component.text("💪 Strength Effect deactivated!")
                .color(NamedTextColor.RED));
    }
    
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (hasStrengthEffect(player)) {
            PotionEffect effect = player.getPotionEffect(PotionEffectType.STRENGTH);
            if (effect != null && effect.getDuration() > 9999) {
                player.removePotionEffect(PotionEffectType.STRENGTH);
            }
        }
        UUID playerId = player.getUniqueId();
        autoCritPlayers.remove(playerId);
        lastRegenTime.remove(playerId);
    }
    
    @EventHandler
    public void onPotionDrain(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        if (hasStrengthEffect(player)) {
            PotionEffect effect = player.getPotionEffect(PotionEffectType.STRENGTH);
            if (effect != null && effect.getDuration() > 9999) {
                player.removePotionEffect(PotionEffectType.STRENGTH);
            }
        }
    }
    
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (hasStrengthEffect(player)) {
            safeRemoveAndAddStrength(player);
        }
    }
    
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        PotionEffect effect = player.getPotionEffect(PotionEffectType.STRENGTH);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.STRENGTH);
        }
        UUID playerId = player.getUniqueId();
        autoCritPlayers.remove(playerId);
        lastRegenTime.remove(playerId);
    }
    
    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        new BukkitRunnable() {
            @Override
            public void run() {
                if (hasStrengthEffect(player)) {
                    safeRemoveAndAddStrength(player);
                }
            }
        }.runTaskLater(plugin, 1L);
    }

    @Override
    public void useSpark(Player player) {
        if (!hasStrengthEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Strength effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        
        // Activate auto-crit
        autoCritPlayers.put(playerId, System.currentTimeMillis());
        
        // Visual and sound effects
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
        player.sendMessage(Component.text("💪 Auto-Crit activated for 15 seconds!")
                .color(NamedTextColor.RED));
        
        // Schedule auto-crit deactivation message
        new BukkitRunnable() {
            @Override
            public void run() {
                if (System.currentTimeMillis() - autoCritPlayers.getOrDefault(playerId, 0L) >= AUTO_CRIT_DURATION) {
                    player.sendMessage(Component.text("💪 Auto-Crit has worn off!")
                            .color(NamedTextColor.RED));
                }
            }
        }.runTaskLater(plugin, 15 * 20L); // 15 seconds
    }

    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        Entity target = event.getEntity();
    
        // Double damage to mobs
        if (target instanceof Monster || target instanceof Animals) {
            event.setDamage(event.getDamage() * 2.0);
        }
    
        // Handle auto-crit
        if (isAutoCritActive(attackerId)) {
            // Apply critical hit damage (1.5x is standard for Minecraft crits)
            event.setDamage(event.getDamage() * 1.5);
            
            // Add visual and sound effects to simulate a critical hit
            attacker.getWorld().playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 1.0f);
            
            // Spawn critical hit particles at the target's location
            if (target instanceof LivingEntity) {
                // Standard critical hit particles
                target.getWorld().spawnParticle(Particle.CRIT, 
                    target.getLocation().add(0, 1, 0), 
                    15, 0.5, 0.5, 0.5, 0.1);
                
                // Add enchantment particles for extra effect
                target.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, 
                    target.getLocation().add(0, 1, 0), 
                    10, 0.5, 0.5, 0.5, 0.1);
            }
        }
    
        // Regeneration II for 2 seconds on hit, but only every 3 seconds
        long now = System.currentTimeMillis();
        if (!lastRegenTime.containsKey(attackerId) || now - lastRegenTime.get(attackerId) > REGEN_COOLDOWN) {
            attacker.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.REGENERATION, 40, 1, false, true));
            lastRegenTime.put(attackerId, now);
        }
    
        // Disable shield if target is a player
        if (target instanceof Player defender) {
            shieldDisabledPlayers.put(defender.getUniqueId(), System.currentTimeMillis());
            defender.sendMessage(Component.text("💪 Your shield has been disabled for 10 seconds!")
                    .color(NamedTextColor.RED));
            if (defender.isBlocking()) {
                defender.setCooldown(Material.SHIELD, 200); // 10 seconds cooldown
            }
        }
    }

    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // Check if shield is disabled
        if (event.getDamager() instanceof Player attacker && hasStrengthEffect(attacker)) {
            if (isShieldDisabled(defender.getUniqueId()) && defender.isBlocking()) {
                // Prevent shield blocking
                defender.setCooldown(Material.SHIELD, 200); // 10 seconds cooldown
                defender.sendMessage(Component.text("💪 Your shield is currently disabled!")
                        .color(NamedTextColor.RED));
            }
            
            // Handle ranged weapon pierce
            Entity damager = event.getDamager();
            if ((damager instanceof Arrow || damager instanceof Trident) && defender.isBlocking()) {
                defender.setCooldown(Material.SHIELD, 40); // 2 second cooldown for ranged pierce
                defender.sendMessage(Component.text("💪 Your shield was pierced by a ranged attack!")
                        .color(NamedTextColor.RED));
            }
        }
    }

    @EventHandler
    public void onPlayerItemHeld(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack newItem = player.getInventory().getItem(event.getNewSlot());
        
        // Check if player is trying to use a shield while disabled
        if (newItem != null && newItem.getType() == Material.SHIELD) {
            if (isShieldDisabled(player.getUniqueId())) {
                player.setCooldown(Material.SHIELD, 200); // 10 seconds cooldown
                player.sendMessage(Component.text("💪 You cannot use your shield while it's disabled!")
                        .color(NamedTextColor.RED));
            }
        }
    }

    private boolean isShieldDisabled(UUID playerId) {
        long disabledTime = shieldDisabledPlayers.getOrDefault(playerId, 0L);
        return System.currentTimeMillis() - disabledTime < SHIELD_DISABLE_DURATION;
    }

    private boolean isAutoCritActive(UUID playerId) {
        long activationTime = autoCritPlayers.getOrDefault(playerId, 0L);
        return System.currentTimeMillis() - activationTime < AUTO_CRIT_DURATION;
    }

    private boolean hasStrengthEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.STRENGTH && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.STRENGTH && data.isSecondaryEnabled());
    }

    private void safeRemoveAndAddStrength(Player player) {
        PotionEffect effect = player.getPotionEffect(PotionEffectType.STRENGTH);
        if (effect == null || effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.STRENGTH);
            player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1));
        }
    }
}
