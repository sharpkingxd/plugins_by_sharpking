package dlindustries.vigillant.system.module.modules.render;

import dlindustries.vigillant.system.event.events.HudListener;
import dlindustries.vigillant.system.event.events.PacketSendListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.utils.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.awt.*;
import java.util.Arrays;

public final class TargetHud extends Module implements HudListener, PacketSendListener {
	private final BooleanSetting glow = new BooleanSetting(EncryptedString.of("Glow"), true)
			.setDescription(EncryptedString.of("Renders a glow around the target hud"));

	private static final float PANEL_WIDTH = 150.0f;
	private static final float PANEL_HEIGHT = 40.0f;

	private PlayerEntity target;
	private long targetSetTime;
	private boolean shouldToBack;
	private float healthval = 0.0f;
	private float prevHealthval = 0.0f;
	private float animation = 0.0f;
	private long deltaTime = 16L;
	private long time = System.currentTimeMillis();
	private String name = "";
	private net.minecraft.util.Identifier playerTexture = null;
	private java.util.List<ItemStack> items = null;
	private static final long TIMEOUT = 3000L;

	public TargetHud() {
		super(EncryptedString.of("Target HUD"),
				EncryptedString.of("Gives you information about the enemy player"),
				-1,
				Category.RENDER);
		addSettings(glow);
	}

	@Override
	public void onEnable() {
		eventManager.add(HudListener.class, this);
		eventManager.add(PacketSendListener.class, this);
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(HudListener.class, this);
		eventManager.remove(PacketSendListener.class, this);
		super.onDisable();
	}

	@Override
	public void onRenderHud(HudEvent event) {
		DrawContext context = event.context;

		target = getTarget(target);

		boolean backAnimation = !shouldToBack;
		animation = RenderUtils.fast(animation, backAnimation ? 0.0f : 1.0f, backAnimation ? 15f : 20f);

		if (animation <= 0.1f) {
			target = null;
			return;
		}

		if (target == null || !(target instanceof PlayerEntity)) {
			return;
		}

		long now = System.currentTimeMillis();
		deltaTime = now - time;
		time = now;

		float f3 = (float)context.getScaledWindowWidth() / 2 - PANEL_WIDTH / 2;
		float f4 = (float)context.getScaledWindowHeight() / 2 - PANEL_HEIGHT / 2 + 100;
		float f5 = animation;

		Color themeColor = Utils.getMainColor(255, 0);

		Color backgroundColor = new Color(
			Math.max(0, themeColor.getRed() - 50),
			Math.max(0, themeColor.getGreen() - 50),
			Math.max(0, themeColor.getBlue() - 50),
			(int)(200 * f5)
		);
		context.fill((int)f3, (int)f4, (int)(f3 + PANEL_WIDTH), (int)(f4 + PANEL_HEIGHT), backgroundColor.getRGB());

		Color outlineColor = new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), (int)(255 * f5));

		context.fill((int)f3, (int)f4, (int)(f3 + PANEL_WIDTH), (int)(f4 + 1), outlineColor.getRGB());

		context.fill((int)f3, (int)(f4 + PANEL_HEIGHT - 1), (int)(f3 + PANEL_WIDTH), (int)(f4 + PANEL_HEIGHT), outlineColor.getRGB());

		context.fill((int)f3, (int)f4, (int)(f3 + 1), (int)(f4 + PANEL_HEIGHT), outlineColor.getRGB());

		context.fill((int)(f3 + PANEL_WIDTH - 1), (int)f4, (int)(f3 + PANEL_WIDTH), (int)(f4 + PANEL_HEIGHT), outlineColor.getRGB());

		if (glow.getValue()) {
			for (int i = 1; i <= 2; i++) {
				Color glowColor = new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), (int)(15 * f5 / i));

				context.fill((int)(f3 - i), (int)(f4 - i), (int)(f3 + PANEL_WIDTH + i), (int)(f4 - i + 1), glowColor.getRGB());

				context.fill((int)(f3 - i), (int)(f4 + PANEL_HEIGHT + i - 1), (int)(f3 + PANEL_WIDTH + i), (int)(f4 + PANEL_HEIGHT + i), glowColor.getRGB());

				context.fill((int)(f3 - i), (int)(f4 - i), (int)(f3 - i + 1), (int)(f4 + PANEL_HEIGHT + i), glowColor.getRGB());

				context.fill((int)(f3 + PANEL_WIDTH + i - 1), (int)(f4 - i), (int)(f3 + PANEL_WIDTH + i), (int)(f4 + PANEL_HEIGHT + i), glowColor.getRGB());
			}
		}

		PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(target.getUuid());
		float health = 0.0f;
		if (entry != null) {
			playerTexture = entry.getSkinTextures().texture();
			name = target.getName().getString();
			health = (float)Math.ceil(target.getHealth() + target.getAbsorptionAmount());
			healthval = MathHelper.clamp((target.getHealth() + target.getAbsorptionAmount()) / 24.0f, 0.0f, 1.0f);

			items = Arrays.asList(
				target.getEquippedStack(net.minecraft.entity.EquipmentSlot.HEAD),
				target.getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST),
				target.getEquippedStack(net.minecraft.entity.EquipmentSlot.LEGS),
				target.getEquippedStack(net.minecraft.entity.EquipmentSlot.FEET)
			);
		}

		dlindustries.vigillant.system.module.modules.client.NameProtect nameProtect =
				system.INSTANCE.getModuleManager().getModule(
						dlindustries.vigillant.system.module.modules.client.NameProtect.class);
		if (nameProtect != null) {
			name = nameProtect.replaceName(name);
		}

		if (playerTexture != null && entry != null) {

			PlayerSkinDrawer.draw(context, entry.getSkinTextures(), (int)(f3 + 5), (int)(f4 + 5), 30);

			Color headOutlineColor = new Color(14, 14, 14, (int)(255 * f5));
			int headX = (int)(f3 + 5);
			int headY = (int)(f4 + 5);
			int headSize = 30;

			context.fill(headX, headY, headX + headSize, headY + 1, headOutlineColor.getRGB());

			context.fill(headX, headY + headSize - 1, headX + headSize, headY + headSize, headOutlineColor.getRGB());

			context.fill(headX, headY, headX + 1, headY + headSize, headOutlineColor.getRGB());

			context.fill(headX + headSize - 1, headY, headX + headSize, headY + headSize, headOutlineColor.getRGB());
		}

		Color textColor = new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), (int)(255 * f5));
		TextRenderer.drawString(name, context, (int)(f3 + 40), (int)(f4 + 2.5f), textColor.getRGB());

		healthval = RenderUtils.fast(healthval, healthval, deltaTime * 0.005f);
		prevHealthval = RenderUtils.fast(prevHealthval, health, deltaTime * 0.01f);

		float healthBarX = f3 + 40;
		float healthBarY = f4 + 29;
		float healthBarWidth = PANEL_WIDTH - 65;
		float healthBarHeight = 4;

		Color healthBarBg = new Color(
			Math.max(0, themeColor.getRed() - 100),
			Math.max(0, themeColor.getGreen() - 100),
			Math.max(0, themeColor.getBlue() - 100),
			(int)(255 * f5)
		);
		context.fill((int)healthBarX, (int)healthBarY, (int)(healthBarX + healthBarWidth), (int)(healthBarY + healthBarHeight), healthBarBg.getRGB());

		float fillWidth = healthBarWidth * healthval;
		if (fillWidth > 0) {

			Color healthColor = new Color(themeColor.getRed(), themeColor.getGreen(), themeColor.getBlue(), (int)(255 * f5));
			context.fill((int)healthBarX, (int)healthBarY, (int)(healthBarX + fillWidth), (int)(healthBarY + healthBarHeight), healthColor.getRGB());
		}

		String healthText = String.valueOf(MathUtils.roundToDecimal(prevHealthval, 1));
		int healthTextWidth = TextRenderer.getWidth(healthText);
		float healthTextX = f3 + PANEL_WIDTH - healthTextWidth - 2.5f;
		TextRenderer.drawString(healthText, context, (int)healthTextX, (int)(f4 + 23), textColor.getRGB());

	}

	private PlayerEntity getTarget(PlayerEntity nullTarget) {
		checkTargetTimeout();

		PlayerEntity target = nullTarget;

		if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
			if (mc.crosshairTarget instanceof EntityHitResult entityHit) {
				if (entityHit.getEntity() instanceof PlayerEntity newTarget && newTarget != mc.player) {
					if (this.target == null || !this.target.equals(newTarget)) {
						this.target = newTarget;
						this.targetSetTime = System.currentTimeMillis();
						this.shouldToBack = true;
					} else {
						this.targetSetTime = System.currentTimeMillis();
					}
					target = this.target;
				}
			}
		} else if (this.target != null) {
			target = this.target;
		} else if (mc.currentScreen instanceof net.minecraft.client.gui.screen.ChatScreen) {
			this.shouldToBack = true;
		} else {
			this.shouldToBack = false;
		}

		return target;
	}

	private void checkTargetTimeout() {
		if (this.target != null) {
			long currentTime = System.currentTimeMillis();
			if (currentTime - this.targetSetTime >= TIMEOUT) {
				this.target = null;
			}
		}
	}

	@Override
	public void onPacketSend(PacketSendEvent event) {
		if (event.packet instanceof PlayerInteractEntityC2SPacket packet) {
			packet.handle(new PlayerInteractEntityC2SPacket.Handler() {
				@Override
				public void interact(Hand hand) {}

				@Override
				public void interactAt(Hand hand, Vec3d pos) {}

				@Override
				public void attack() {
					if (mc.crosshairTarget instanceof EntityHitResult entityHit) {
						if (entityHit.getEntity() instanceof PlayerEntity player && player != mc.player) {
							target = player;
							targetSetTime = System.currentTimeMillis();
							shouldToBack = true;
						}
					}
				}
			});
		}
	}
}
