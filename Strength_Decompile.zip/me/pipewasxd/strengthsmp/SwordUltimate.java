package me.pipewasxd.strengthsmp;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Stream;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.attribute.AttributeModifier.Operation;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType.SlotType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

public class SwordUltimate implements Listener {
   private final StrengthSMP plugin;
   private final WeaponManager weaponManager;
   private final StrengthManager strengthManager;
   private final Map<UUID, Integer> hitCombo = new HashMap();
   private final Map<UUID, Long> lastHitTime = new HashMap();
   private final Map<UUID, Boolean> autoCritActive = new HashMap();
   private final Map<UUID, Boolean> ultimateActive = new HashMap();
   private final Map<UUID, Long> ultimateCooldown = new HashMap();
   private final Map<UUID, ItemStack> savedOffhandItems = new HashMap();
   private final Map<UUID, BukkitRunnable> cooldownTasks = new HashMap();
   private final Map<UUID, BukkitRunnable> ultimateTasks = new HashMap();
   private final NamespacedKey ultimateKey;

   public SwordUltimate(StrengthSMP plugin, WeaponManager weaponManager, StrengthManager strengthManager) {
      this.plugin = plugin;
      this.weaponManager = weaponManager;
      this.strengthManager = strengthManager;
      this.ultimateKey = new NamespacedKey(plugin, "ultimate_sword");
   }

   @EventHandler
   public void onEntityDamage(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         ItemStack var9 = attacker.getInventory().getItemInMainHand();
         if (this.isSword(var9.getType())) {
            if (this.weaponManager.getPlayerWeapon(attacker) == WeaponType.SWORD) {
               if (this.strengthManager.isAtMaxStrength(attacker)) {
                  UUID uuid = attacker.getUniqueId();
                  long currentTime = System.currentTimeMillis();
                  Long lastHit = (Long)this.lastHitTime.get(uuid);
                  if (lastHit == null || currentTime - lastHit >= 500L) {
                     if (lastHit != null && currentTime - lastHit > 1500L) {
                        this.resetCombo(attacker);
                     }

                     this.lastHitTime.put(uuid, currentTime);
                     int combo = (Integer)this.hitCombo.getOrDefault(uuid, 0) + 1;
                     this.hitCombo.put(uuid, combo);
                     if (combo == 3 && !(Boolean)this.autoCritActive.getOrDefault(uuid, false)) {
                        this.autoCritActive.put(uuid, true);
                        attacker.playSound(attacker.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0F, 1.5F);
                     }

                     if (combo == 5 && !(Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
                        this.activateUltimate(attacker);
                     }

                     if ((Boolean)this.autoCritActive.getOrDefault(uuid, false) && !event.isCritical()) {
                        event.setDamage(event.getDamage() * (double)1.5F);
                        attacker.playSound(attacker.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 0.5F, 1.0F);
                        attacker.getWorld().spawnParticle(Particle.CRIT, event.getEntity().getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, 0.3, 0.3, 0.3, 0.05);
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      UUID uuid = player.getUniqueId();
      if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
         BukkitRunnable task = (BukkitRunnable)this.ultimateTasks.remove(uuid);
         if (task != null) {
            task.cancel();
         }

         ItemStack offhand = player.getInventory().getItemInOffHand();
         if (this.isUltimateSword(offhand)) {
            player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
         }

         this.ultimateActive.remove(uuid);
         this.savedOffhandItems.remove(uuid);
         this.applyAttackSpeedBoost(player, false);
      }

   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      UUID uuid = player.getUniqueId();
      ItemStack offhand = player.getInventory().getItemInOffHand();
      if (this.isUltimateSword(offhand)) {
         player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
      }

      this.ultimateActive.remove(uuid);
      this.savedOffhandItems.remove(uuid);
      this.applyAttackSpeedBoost(player, false);
   }

   @EventHandler
   public void onSwapHands(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if ((Boolean)this.ultimateActive.getOrDefault(player.getUniqueId(), false)) {
         event.setCancelled(true);
      }

   }

   @EventHandler
   public void onItemDrop(PlayerDropItemEvent event) {
      ItemStack item = event.getItemDrop().getItemStack();
      if (this.isUltimateSword(item)) {
         event.setCancelled(true);
      }

   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent event) {
      HumanEntity var3 = event.getWhoClicked();
      if (var3 instanceof Player player) {
         if ((Boolean)this.ultimateActive.getOrDefault(player.getUniqueId(), false)) {
            ItemStack clicked = event.getCurrentItem();
            if (this.isUltimateSword(clicked)) {
               event.setCancelled(true);
            }

            if (event.getSlotType() == SlotType.CONTAINER) {
               ItemStack offhand = player.getInventory().getItemInOffHand();
               if (this.isUltimateSword(offhand)) {
                  event.setCancelled(true);
               }
            }

         }
      }
   }

   @EventHandler
   public void onInventoryDrag(InventoryDragEvent event) {
      HumanEntity var3 = event.getWhoClicked();
      if (var3 instanceof Player player) {
         if ((Boolean)this.ultimateActive.getOrDefault(player.getUniqueId(), false)) {
            ItemStack offhand = player.getInventory().getItemInOffHand();
            if (this.isUltimateSword(offhand)) {
               event.setCancelled(true);
            }

         }
      }
   }

   @EventHandler
   public void onPlayerDeath(PlayerDeathEvent event) {
      Player player = event.getEntity();
      UUID uuid = player.getUniqueId();
      if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
         BukkitRunnable task = (BukkitRunnable)this.ultimateTasks.remove(uuid);
         if (task != null) {
            task.cancel();
         }
      }

      ItemStack offhand = player.getInventory().getItemInOffHand();
      if (this.isUltimateSword(offhand)) {
         event.getDrops().removeIf(this::isUltimateSword);
         player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
      }

      this.ultimateActive.remove(uuid);
      this.savedOffhandItems.remove(uuid);
   }

   @EventHandler
   public void onItemHeldChange(PlayerItemHeldEvent event) {
      Player player = event.getPlayer();
      if ((Boolean)this.ultimateActive.getOrDefault(player.getUniqueId(), false)) {
         ItemStack newItem = player.getInventory().getItem(event.getNewSlot());
         if (newItem != null) {
            this.applyAttackSpeedBoost(player, this.isSword(newItem.getType()));
         }

      }
   }

   @EventHandler
   public void onPlayerSwapInventory(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if ((Boolean)this.ultimateActive.getOrDefault(player.getUniqueId(), false)) {
         event.setCancelled(true);
      }

   }

   private boolean isUltimateSword(ItemStack item) {
      if (item != null && item.hasItemMeta()) {
         Byte marker = (Byte)item.getItemMeta().getPersistentDataContainer().get(this.ultimateKey, PersistentDataType.BYTE);
         return marker != null && marker == 1;
      } else {
         return false;
      }
   }

   private void activateUltimate(final Player player) {
      UUID uuid = player.getUniqueId();
      if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
         player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#FF0000:#8B0000>ᴀʟʀᴇᴀᴅʏ ᴀᴄᴛɪᴠᴇ</gradient></bold>"));
      } else if (this.isOnCooldown(player)) {
         player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#FF0000:#8B0000>ᴏɴ ᴄᴏᴏʟᴅᴏᴡɴ</gradient></bold>"));
      } else {
         ItemStack offhand = player.getInventory().getItemInOffHand();
         this.savedOffhandItems.put(uuid, offhand.clone());
         ItemStack mainSword = player.getInventory().getItemInMainHand().clone();
         ItemMeta meta = mainSword.getItemMeta();
         if (meta != null) {
            meta.addEnchant(Enchantment.VANISHING_CURSE, 1, true);
            meta.getPersistentDataContainer().set(this.ultimateKey, PersistentDataType.BYTE, (byte)1);
            mainSword.setItemMeta(meta);
         }

         player.getInventory().setItemInOffHand(mainSword);
         this.ultimateActive.put(uuid, true);
         if (this.isSword(player.getInventory().getItemInMainHand().getType())) {
            this.applyAttackSpeedBoost(player, true);
         }

         player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#8B0000:#B22222>ᴜʟᴛɪᴍᴀᴛᴇ ᴀᴄᴛɪᴠᴀᴛᴇᴅ</gradient></bold>"));
         player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1.0F, 0.8F);
         if (this.ultimateTasks.containsKey(uuid)) {
            ((BukkitRunnable)this.ultimateTasks.get(uuid)).cancel();
         }

         BukkitRunnable ultimateTask = new BukkitRunnable() {
            public void run() {
               SwordUltimate.this.deactivateUltimate(player);
            }
         };
         ultimateTask.runTaskLater(this.plugin, 300L);
         this.ultimateTasks.put(uuid, ultimateTask);
      }
   }

   private void deactivateUltimate(final Player player) {
      final UUID uuid = player.getUniqueId();
      if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
         BukkitRunnable runningTask = (BukkitRunnable)this.ultimateTasks.remove(uuid);
         if (runningTask != null) {
            runningTask.cancel();
         }

         ItemStack originalOffhand = (ItemStack)this.savedOffhandItems.remove(uuid);
         player.getInventory().setItemInOffHand(originalOffhand != null ? originalOffhand : new ItemStack(Material.AIR));
         this.applyAttackSpeedBoost(player, false);
         this.ultimateActive.put(uuid, false);
         this.ultimateCooldown.put(uuid, System.currentTimeMillis() + 60000L);
         this.resetCombo(player);
         player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#A9A9A9:#D3D3D3>ᴏɴ ᴄᴏᴏʟᴅᴏᴡɴ</gradient></bold>"));
         player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5F, 1.0F);
         if (this.cooldownTasks.containsKey(uuid)) {
            ((BukkitRunnable)this.cooldownTasks.get(uuid)).cancel();
         }

         BukkitRunnable cooldownTask = new BukkitRunnable() {
            public void run() {
               if (!(Boolean)SwordUltimate.this.ultimateActive.getOrDefault(uuid, false)) {
                  player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#006400:#008000>ᴜʟᴛɪᴍᴀᴛᴇ ʀᴇᴀᴅʏ</gradient></bold>"));
                  player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
               }

               SwordUltimate.this.cooldownTasks.remove(uuid);
            }
         };
         cooldownTask.runTaskLater(this.plugin, 1200L);
         this.cooldownTasks.put(uuid, cooldownTask);
      }
   }

   private void resetCombo(Player player) {
      UUID uuid = player.getUniqueId();
      this.hitCombo.put(uuid, 0);
      this.autoCritActive.put(uuid, false);
   }

   private void applyAttackSpeedBoost(Player player, boolean apply) {
      AttributeInstance attackSpeed = player.getAttribute(Attribute.GENERIC_ATTACK_SPEED);
      if (attackSpeed != null) {
         NamespacedKey key = new NamespacedKey(this.plugin, "sword_ultimate_speed");
         Stream var10000 = attackSpeed.getModifiers().stream().filter((mod) -> mod.getKey().equals(key));
         Objects.requireNonNull(attackSpeed);
         var10000.forEach(attackSpeed::removeModifier);
         if (apply) {
            AttributeModifier modifier = new AttributeModifier(key, (double)4.0F, Operation.ADD_NUMBER);
            attackSpeed.addModifier(modifier);
         }

      }
   }

   public boolean isOnCooldown(Player player) {
      Long cooldownEnd = (Long)this.ultimateCooldown.get(player.getUniqueId());
      return cooldownEnd != null && System.currentTimeMillis() < cooldownEnd;
   }

   private boolean isSword(Material material) {
      boolean var10000;
      switch (material) {
         case WOODEN_SWORD:
         case STONE_SWORD:
         case IRON_SWORD:
         case GOLDEN_SWORD:
         case DIAMOND_SWORD:
         case NETHERITE_SWORD:
            var10000 = true;
            break;
         default:
            var10000 = false;
      }

      return var10000;
   }
}
