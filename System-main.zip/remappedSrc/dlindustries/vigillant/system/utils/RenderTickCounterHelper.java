package dlindustries.vigillant.system.utils;

import net.minecraft.client.render.RenderTickCounter;

import java.lang.reflect.Field;

public final class RenderTickCounterHelper {
	private static Field tickDeltaField;
	private static Field lastFrameDurationField;

	static {
		try {
			for (String fieldName : new String[]{"tickDelta", "tickTime", "delta", "partialTick", "field_1728", "field_1729"}) {
				try {
					Field field = RenderTickCounter.class.getDeclaredField(fieldName);
					field.setAccessible(true);
					tickDeltaField = field;
					break;
				} catch (NoSuchFieldException ignored) {
				}
			}

			if (tickDeltaField == null) {
				for (String methodName : new String[]{"getTickDelta", "tickDelta", "getDelta", "getPartialTick"}) {
					try {
						java.lang.reflect.Method method = RenderTickCounter.class.getMethod(methodName);
						if (method.getReturnType() == float.class || method.getReturnType() == Float.class) {
							tickDeltaField = null;
							break;
						}
					} catch (NoSuchMethodException ignored) {
					}
				}
			}

			for (String fieldName : new String[]{"lastFrameDuration", "frameTime", "frameDuration"}) {
				try {
					Field field = RenderTickCounter.class.getDeclaredField(fieldName);
					field.setAccessible(true);
					lastFrameDurationField = field;
					break;
				} catch (NoSuchFieldException ignored) {
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static float getTickDelta(RenderTickCounter counter) {
		if (tickDeltaField != null) {
			try {
				float delta = tickDeltaField.getFloat(counter);
				if (delta != 0.0f) {
					return delta;
				}
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}

		try {
			for (String methodName : new String[]{"getTickDelta", "tickDelta", "getDelta", "getPartialTick"}) {
				try {
					java.lang.reflect.Method method = RenderTickCounter.class.getMethod(methodName);
					if (method.getReturnType() == float.class || method.getReturnType() == Float.class) {
						Object result = method.invoke(counter);
						if (result instanceof Float) {
							return (Float) result;
						} else if (result instanceof Number) {
							return ((Number) result).floatValue();
						}
					}
				} catch (NoSuchMethodException | java.lang.reflect.InvocationTargetException ignored) {
				}
			}
		} catch (Exception e) {
		}

		return 1.0f;
	}

	public static float getLastFrameDuration(RenderTickCounter counter) {
		if (lastFrameDurationField != null) {
			try {
				return lastFrameDurationField.getFloat(counter);
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		return 1.0f / 60.0f;
	}
}
