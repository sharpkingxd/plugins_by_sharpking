package dlindustries.vigillant.system.mixin;

import dlindustries.vigillant.system.module.modules.optimizer.CameraOptimizer;
import dlindustries.vigillant.system.system;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

	@Inject(method = "shouldRenderBlockOutline", at = @At("HEAD"), cancellable = true)
	private void onShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> cir) {
		CameraOptimizer optimizer = system.INSTANCE.getModuleManager().getModule(CameraOptimizer.class);
		if (optimizer != null && optimizer.isEnabled() && optimizer.isToggleKeyPressed()) {
			cir.setReturnValue(false);
		}
	}
}