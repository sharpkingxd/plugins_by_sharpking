package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.enchantment.EnchantItemEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.NamespacedKey;

import java.util.*;

public class EmeraldEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Long> sparkEndTimes = new HashMap<>();
    private final Random random;
    private static final long SPARK_DURATION = 30 * 1000; // 30 seconds in milliseconds
    private final NamespacedKey LOOTING_KEY;
    
    public EmeraldEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.random = new Random();
        this.LOOTING_KEY = new NamespacedKey(plugin, "emerald_looting");
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    @Override
    public void activatePassive(Player player) {
        // No initialization needed
        // (No hero effect applied passively)
    }
    
    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        sparkEndTimes.remove(playerId);
        PotionEffect effect = player.getPotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE);
        }
    }
    
    @Override
    public void useSpark(Player player) {
        if (!hasEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Emerald effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        sparkEndTimes.put(playerId, System.currentTimeMillis() + SPARK_DURATION);
        safeRemoveAndAddHero(player);
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_YES, 1.0f, 1.0f);
        player.sendMessage(Component.text("💚 Hero of the Village activated for 2 minutes!")
                .color(NamedTextColor.GREEN));
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                safeRemoveAndAddHero(player);
                player.sendMessage(Component.text("💚 Hero of the Village has worn off!")
                        .color(NamedTextColor.GREEN));
            }
        }, 2400L);
    }
    
    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        // Check if target is a trusted player
        if (event.getEntity() instanceof Player target) {
            PlayerData playerData = plugin.getDataManager().getPlayerData(attacker.getUniqueId());
            if (playerData.isTrustedPlayer(target.getUniqueId())) {
                // Skip effects for trusted players
                return;
            }
        }
        
        // Add Looting V effect to all attacks
        if (event.getEntity() instanceof LivingEntity) {
            event.getEntity().getPersistentDataContainer().set(
                LOOTING_KEY,
                org.bukkit.persistence.PersistentDataType.INTEGER,
                5
            );
        }
    }
    
    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // No special defense handling needed
    }
    
    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        if (!hasEffect(player)) return;
        
        // 50% chance to not consume item
        if (random.nextBoolean()) {
            // Clone the item to preserve its data
            ItemStack consumedItem = event.getItem().clone();
            consumedItem.setAmount(1);
            
            // Add the item back to inventory with a delay
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                player.getInventory().addItem(consumedItem);
                player.sendMessage(Component.text("💚 Item preserved by Emerald Effect!")
                        .color(NamedTextColor.GREEN));
            }, 1L);
        }
    }
    
    @EventHandler
    public void onEnchantItem(EnchantItemEvent event) {
        Player player = event.getEnchanter();
        if (!hasEffect(player)) return;
        
        // Force enchanting table to always be level 30
        event.setExpLevelCost(30);
        
        // Boost enchantment levels
        event.getEnchantsToAdd().replaceAll((enchant, level) -> 
            Math.min(level + 2, enchant.getMaxLevel()));
        
        player.sendMessage(Component.text("💚 Enchanting boosted by Emerald Effect!")
                .color(NamedTextColor.GREEN));
    }
    
    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null || !hasEffect(killer)) return;
        
        // Check for Looting from our effect
        Integer lootingLevel = event.getEntity().getPersistentDataContainer().get(
            LOOTING_KEY,
            org.bukkit.persistence.PersistentDataType.INTEGER
        );
        
        if (lootingLevel != null) {
            // Apply Looting V effect to drops
            List<ItemStack> drops = event.getDrops();
            int extraDrops = random.nextInt(lootingLevel + 1);
            
            if (!drops.isEmpty() && extraDrops > 0) {
                ItemStack dropToMultiply = drops.get(0).clone();
                dropToMultiply.setAmount(extraDrops);
                drops.add(dropToMultiply);
            }
        }
        
        // Triple XP
        int originalXP = event.getDroppedExp();
        event.setDroppedExp(originalXP * 3);
        
        // Visual feedback for bonus XP
        if (originalXP > 0) {
            killer.sendMessage(Component.text("💚 Triple XP from kill!")
                    .color(NamedTextColor.GREEN));
        }
    }
    
    private boolean isSparkActive(UUID playerId) {
        Long endTime = sparkEndTimes.get(playerId);
        return endTime != null && System.currentTimeMillis() < endTime;
    }
    
    private boolean hasEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.EMERALD && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.EMERALD && data.isSecondaryEnabled());
    }
    
    private void safeRemoveAndAddHero(Player player) {
        PotionEffect effect = player.getPotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE);
        if (effect == null || effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE);
            player.addPotionEffect(new PotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE, 2400, 254, false, true));
        }
    }
}

