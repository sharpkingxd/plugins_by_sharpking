package me.pipewasxd.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;

public record RerollBookRecipe(StrengthSMP plugin, ConfigManager configManager) {
   public void registerRecipe() {
      NamespacedKey key = new NamespacedKey(this.plugin, "reroll_book");
      Bukkit.removeRecipe(key);
      ShapedRecipe recipe = new ShapedRecipe(key, RerollBook.createRerollBook(this.plugin));
      recipe.shape(new String[]{"ABC", "DEF", "GHI"});
      Material topLeft = this.configManager.getRerollRecipeTopLeft();
      Material top = this.configManager.getRerollRecipeTop();
      Material topRight = this.configManager.getRerollRecipeTopRight();
      Material left = this.configManager.getRerollRecipeLeft();
      Material center = this.configManager.getRerollRecipeCenter();
      Material right = this.configManager.getRerollRecipeRight();
      Material bottomLeft = this.configManager.getRerollRecipeBottomLeft();
      Material bottom = this.configManager.getRerollRecipeBottom();
      Material bottomRight = this.configManager.getRerollRecipeBottomRight();
      if (topLeft != Material.AIR) {
         recipe.setIngredient('A', new RecipeChoice.MaterialChoice(topLeft));
      }

      if (top != Material.AIR) {
         recipe.setIngredient('B', new RecipeChoice.MaterialChoice(top));
      }

      if (topRight != Material.AIR) {
         recipe.setIngredient('C', new RecipeChoice.MaterialChoice(topRight));
      }

      if (left != Material.AIR) {
         recipe.setIngredient('D', new RecipeChoice.MaterialChoice(left));
      }

      if (center != Material.AIR) {
         recipe.setIngredient('E', new RecipeChoice.MaterialChoice(center));
      }

      if (right != Material.AIR) {
         recipe.setIngredient('F', new RecipeChoice.MaterialChoice(right));
      }

      if (bottomLeft != Material.AIR) {
         recipe.setIngredient('G', new RecipeChoice.MaterialChoice(bottomLeft));
      }

      if (bottom != Material.AIR) {
         recipe.setIngredient('H', new RecipeChoice.MaterialChoice(bottom));
      }

      if (bottomRight != Material.AIR) {
         recipe.setIngredient('I', new RecipeChoice.MaterialChoice(bottomRight));
      }

      try {
         Bukkit.addRecipe(recipe);
         this.plugin.getLogger().info("Registered Reroll Book recipe successfully!");
      } catch (Exception e) {
         this.plugin.getLogger().severe("Failed to register Reroll Book recipe: " + e.getMessage());
         e.printStackTrace();
      }

      NamespacedKey key2 = new NamespacedKey(this.plugin, "reroll_book_custom");
      Bukkit.removeRecipe(key2);
      ShapedRecipe recipe2 = new ShapedRecipe(key2, RerollBook.createRerollBook(this.plugin));
      recipe2.shape(new String[]{"DHD", "ESE", "DTD"});
      recipe2.setIngredient('D', new RecipeChoice.MaterialChoice(Material.DIAMOND_BLOCK));
      recipe2.setIngredient('H', new RecipeChoice.MaterialChoice(Material.NETHERITE_HOE));
      recipe2.setIngredient('E', new RecipeChoice.MaterialChoice(Material.ECHO_SHARD));
      recipe2.setIngredient('S', new RecipeChoice.MaterialChoice(Material.WITHER_SKELETON_SKULL));
      recipe2.setIngredient('T', new RecipeChoice.MaterialChoice(Material.TRIDENT));

      try {
         Bukkit.addRecipe(recipe2);
         this.plugin.getLogger().info("Registered Reroll Book custom recipe successfully!");
      } catch (IllegalStateException var15) {
         this.plugin.getLogger().warning("Reroll Book recipe already exists!");
      }

   }
}
