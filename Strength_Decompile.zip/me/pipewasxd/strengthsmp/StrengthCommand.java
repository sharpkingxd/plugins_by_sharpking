package me.pipewasxd.strengthsmp;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public record StrengthCommand(StrengthManager strengthManager, WeaponManager weaponManager, StrengthSMP plugin) implements CommandExecutor, TabCompleter {
   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      if (args.length == 0) {
         if (sender instanceof Player) {
            Player player = (Player)sender;
            int newWeapon = this.strengthManager.getStrength(player);
            WeaponType weapon = this.weaponManager.getPlayerWeapon(player);
            String var17 = String.valueOf(ChatColor.DARK_RED);
            player.sendMessage(var17 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ʜᴀᴠᴇ " + String.valueOf(ChatColor.WHITE) + String.valueOf(ChatColor.BOLD) + newWeapon + String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + " sᴛʀᴇɴɢᴛʜ");
            var17 = String.valueOf(ChatColor.DARK_RED);
            player.sendMessage(var17 + String.valueOf(ChatColor.BOLD) + "ᴡᴇᴀᴘᴏɴ: " + String.valueOf(ChatColor.WHITE) + weapon.getDisplayName());
            return true;
         } else {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "Only players can check their strength!");
            return true;
         }
      } else if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
         if (!sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "You don't have permission to reload the config!");
            return true;
         } else {
            this.plugin.reloadConfig();
            sender.sendMessage(String.valueOf(ChatColor.GREEN) + "Strength SMP Configuration reloaded successfully!");
            return true;
         }
      } else if (args.length == 3 && args[0].equalsIgnoreCase("set")) {
         if (!sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "You don't have permission to set strength!");
            return true;
         } else {
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) {
               sender.sendMessage(String.valueOf(ChatColor.RED) + "Player not found!");
               return true;
            } else {
               int amount;
               try {
                  amount = Integer.parseInt(args[2]);
               } catch (NumberFormatException var8) {
                  sender.sendMessage(String.valueOf(ChatColor.RED) + "Invalid number!");
                  return true;
               }

               this.strengthManager.setStrength(target, amount);
               String var16 = String.valueOf(ChatColor.GREEN);
               sender.sendMessage(var16 + "Set " + target.getName() + "'s strength to " + amount);
               return true;
            }
         }
      } else if (args.length == 2 && args[0].equalsIgnoreCase("reroll")) {
         if (!sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "You don't have permission to reroll weapons!");
            return true;
         } else {
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) {
               sender.sendMessage(String.valueOf(ChatColor.RED) + "Player not found!");
               return true;
            } else {
               WeaponType newWeapon = WeaponType.random();
               this.weaponManager.setPlayerWeapon(target, newWeapon);
               String var15 = String.valueOf(ChatColor.GREEN);
               sender.sendMessage(var15 + "Rerolled " + target.getName() + "'s weapon to " + newWeapon.name());
               return true;
            }
         }
      } else if (args.length == 4 && args[0].equalsIgnoreCase("weapontype") && args[1].equalsIgnoreCase("set")) {
         if (!sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "You don't have permission to set weapons!");
            return true;
         } else {
            WeaponType weapon = WeaponType.fromString(args[2]);
            if (weapon == null) {
               sender.sendMessage(String.valueOf(ChatColor.RED) + "Invalid weapon type! Valid types: sword, bow, shield, trident, axe");
               return true;
            } else {
               Player target = Bukkit.getPlayer(args[3]);
               if (target == null) {
                  sender.sendMessage(String.valueOf(ChatColor.RED) + "Player not found!");
                  return true;
               } else {
                  this.weaponManager.setPlayerWeapon(target, weapon);
                  String var10001 = String.valueOf(ChatColor.GREEN);
                  sender.sendMessage(var10001 + "Set " + target.getName() + "'s weapon to " + weapon.name());
                  return true;
               }
            }
         }
      } else {
         sender.sendMessage(String.valueOf(ChatColor.RED) + "Usage:");
         sender.sendMessage(String.valueOf(ChatColor.RED) + "/strength - Check your strength");
         if (sender.hasPermission("strengthsmp.admin")) {
            sender.sendMessage(String.valueOf(ChatColor.RED) + "/strength set <player> <amount> - Set player's strength");
            sender.sendMessage(String.valueOf(ChatColor.RED) + "/strength reroll <player> - Reroll player's weapon");
            sender.sendMessage(String.valueOf(ChatColor.RED) + "/strength weapontype set <weapon> <player> - Set player's weapon");
            sender.sendMessage(String.valueOf(ChatColor.RED) + "/strength reload - Reload config");
         }

         return true;
      }
   }

   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
      List<String> completions = new ArrayList();
      if (args.length == 1) {
         if (sender.hasPermission("strengthsmp.admin")) {
            completions.add("set");
            completions.add("reroll");
            completions.add("weapontype");
            completions.add("reload");
         }

         return (List)completions.stream().filter((s) -> s.toLowerCase().startsWith(args[0].toLowerCase())).collect(Collectors.toList());
      } else if (args.length != 2) {
         if (args.length == 3) {
            if (args[0].equalsIgnoreCase("set")) {
               if (sender.hasPermission("strengthsmp.admin")) {
                  completions.add("1");
                  completions.add("3");
                  completions.add("5");
                  completions.add("10");
               }
            } else if (args[0].equalsIgnoreCase("weapontype") && args[1].equalsIgnoreCase("set") && sender.hasPermission("strengthsmp.admin")) {
               completions.add("sword");
               completions.add("axe");
               completions.add("shield");
               completions.add("trident");
               completions.add("bow");
               completions.add("crossbow");
            }

            return (List)completions.stream().filter((s) -> s.toLowerCase().startsWith(args[2].toLowerCase())).collect(Collectors.toList());
         } else {
            return args.length == 4 && args[0].equalsIgnoreCase("weapontype") && args[1].equalsIgnoreCase("set") && sender.hasPermission("strengthsmp.admin") ? (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> name.toLowerCase().startsWith(args[3].toLowerCase())).collect(Collectors.toList()) : completions;
         }
      } else {
         if (!args[0].equalsIgnoreCase("set") && !args[0].equalsIgnoreCase("reroll")) {
            if (args[0].equalsIgnoreCase("weapontype") && sender.hasPermission("strengthsmp.admin")) {
               completions.add("set");
            }
         } else if (sender.hasPermission("strengthsmp.admin")) {
            return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> name.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
         }

         return (List)completions.stream().filter((s) -> s.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
      }
   }
}
