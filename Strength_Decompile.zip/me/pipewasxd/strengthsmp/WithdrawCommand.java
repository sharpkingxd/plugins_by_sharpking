package me.pipewasxd.strengthsmp;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public record WithdrawCommand(StrengthManager strengthManager, ConfigManager configManager) implements CommandExecutor, TabCompleter {
   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      if (sender instanceof Player player) {
         if (args.length == 0) {
            player.sendMessage(String.valueOf(ChatColor.RED) + "Usage: /withdraw <amount>");
            return true;
         } else {
            int amount;
            try {
               amount = Integer.parseInt(args[0]);
            } catch (NumberFormatException var12) {
               player.sendMessage(String.valueOf(ChatColor.RED) + "Invalid number!");
               return true;
            }

            if (amount <= 0) {
               player.sendMessage(String.valueOf(ChatColor.RED) + "Amount must be greater than 0!");
               return true;
            } else {
               int currentStrength = this.strengthManager.getStrength(player);
               int minStrength = this.configManager.getMinStrength();
               if (currentStrength <= minStrength) {
                  String var13 = String.valueOf(ChatColor.DARK_RED);
                  player.sendMessage(var13 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ᴍᴜsᴛ ʜᴀᴠᴇ ᴀᴛ ʟᴇᴀsᴛ" + String.valueOf(ChatColor.WHITE) + String.valueOf(ChatColor.BOLD) + minStrength + String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + "sᴛʀᴇɴɢᴛʜ ᴛᴏ ᴡɪᴛʜᴅʀᴀᴡ!");
                  return true;
               } else {
                  int maxWithdrawable = currentStrength - minStrength;
                  if (amount > maxWithdrawable) {
                     return true;
                  } else {
                     this.strengthManager.addStrength(player, -amount);

                     for(int i = 0; i < amount; ++i) {
                        ItemStack strengthItem = StrengthItemRecipe.createStrengthItem();
                        if (player.getInventory().firstEmpty() == -1) {
                           player.getWorld().dropItemNaturally(player.getLocation(), strengthItem);
                        } else {
                           player.getInventory().addItem(new ItemStack[]{strengthItem});
                        }
                     }

                     String var10001 = String.valueOf(ChatColor.DARK_RED);
                     player.sendMessage(var10001 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ᴡɪᴛʜᴅʀᴇᴡ " + String.valueOf(ChatColor.WHITE) + String.valueOf(ChatColor.BOLD) + amount + " " + String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + "sᴛʀᴇɴɢᴛʜ");
                     return true;
                  }
               }
            }
         }
      } else {
         sender.sendMessage(String.valueOf(ChatColor.RED) + "Only players can use this command!");
         return true;
      }
   }

   public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, String[] args) {
      List<String> completions = new ArrayList();
      if (args.length == 1 && sender instanceof Player player) {
         int currentStrength = this.strengthManager.getStrength(player);
         int minStrength = this.configManager.getMinStrength();
         int maxWithdrawable = currentStrength - minStrength;
         if (maxWithdrawable > 0) {
            completions.add("1");
            if (maxWithdrawable >= 5) {
               completions.add("5");
            }

            if (maxWithdrawable >= 10) {
               completions.add("10");
            }

            completions.add(String.valueOf(maxWithdrawable));
         }
      }

      return completions;
   }
}
