# Majestic Mace Plugin

**Version:** 1.0.0  
**Author:** SharpKingYT  
**API Version:** 1.21  
**Compatible with:** Paper, Spigot, Purpur (Minecraft 1.21.1)

## Overview

Majestic Mace is a comprehensive Minecraft plugin that completely blocks the vanilla mace crafting recipe and provides server operators with a powerful GUI-based custom recipe management system. Configure your own mace recipes through an intuitive interface with full protection and sound effects.

## Features

### Core Functionality
- ✅ **Complete Vanilla Recipe Blocking** - Removes all default mace crafting recipes
- ✅ **Custom Recipe System** - Create your own mace recipes through GUI
- ✅ **OP-Only Configuration** - Only server operators can modify recipes
- ✅ **Real-time Recipe Updates** - Changes apply immediately without restart

### Interactive GUI System
- 🎨 **54-Slot Chest Interface** - Professional layout with protected areas
- 🔒 **Advanced Protection** - Prevents unauthorized modifications
- 🎵 **Sound Effects** - Immersive audio feedback for all interactions
- ✨ **Particle Effects** - Visual confirmation for successful operations

### Command System
```
/majesticmace recipe  - Open recipe configuration GUI (OP only)
/majesticmace reload  - Reload plugin configuration (OP only)
/majesticmace toggle  - Enable/disable recipe system (OP only)
/majesticmace reset   - Reset recipe to default settings (OP only)
/majesticmace info    - Show plugin information
/majesticmace help    - Display help menu

Aliases: /mmace, /mm
```

### Security Features
- 🛡️ **Permission-Based Access** - Multiple permission levels
- ⏱️ **Cooldown System** - Prevents GUI spam
- 📝 **Comprehensive Logging** - Track all recipe modifications
- 🔄 **Automatic Backups** - Config backup before changes

## Installation

1. **Download** the MajesticMace.jar file
2. **Place** it in your server's `plugins/` directory
3. **Start** your server to generate configuration files
4. **Configure** permissions and settings as needed
5. **Restart** or use `/majesticmace reload` to apply changes

## Permissions

```yaml
majesticmace.admin     # Full access to all features (default: op)
majesticmace.use       # Basic plugin usage (default: true)
majesticmace.recipe    # Access to recipe configuration (default: op)
```

## Configuration

The plugin generates a comprehensive `config.yml` file with the following sections:

### Recipe Settings
```yaml
recipe:
  enabled: true                    # Enable/disable custom recipes
  auto-save-interval: 300         # Auto-save interval in seconds
  backup-before-changes: true     # Backup config before modifications
```

### GUI Customization
```yaml
gui:
  title: "§6§lMajestic Mace Recipe Configuration"
  size: 54
  # Customize item names, lore, and appearance
```

### Sound Effects
```yaml
sounds:
  enabled: true
  volume: 1.0
  effects:
    gui-open: { sound: "UI_BUTTON_CLICK", pitch: 1.0 }
    save-recipe: { sound: "ENTITY_PLAYER_LEVELUP", pitch: 1.2 }
    # ... and more
```

## Usage Guide

### For Server Operators

1. **Open Recipe GUI**: Use `/majesticmace recipe` to open the configuration interface
2. **Configure Ingredients**: Place items in slots 36-44 to define your recipe
3. **Save Recipe**: Click the green wool button to save your configuration
4. **Reset if Needed**: Use the yellow wool button to reset to defaults

### GUI Layout

```
┌─────────────────────────────────────────────────────┐
│ [Barrier] [Display Area] [Barrier] [Result: Mace]  │ Rows 1-3
│ [═══════════ Separator Row ═══════════════════════] │ Row 4
│ [    Ingredient Slots (OP Editable Only)         ] │ Row 5
│ [Save] [Barrier] [Barrier] [Close] [Barrier] [Reset]│ Row 6
└─────────────────────────────────────────────────────┘
```

### Default Recipe

The plugin comes with a default recipe using:
- 1x Heavy Core (center)
- 4x Breeze Rod (surrounding positions)

## Commands Reference

| Command | Permission | Description |
|---------|------------|-------------|
| `/mm recipe` | `majesticmace.recipe` | Open recipe configuration GUI |
| `/mm reload` | `majesticmace.admin` | Reload plugin configuration |
| `/mm toggle` | `majesticmace.admin` | Toggle recipe system on/off |
| `/mm reset` | `majesticmace.admin` | Reset recipe to default |
| `/mm info` | `majesticmace.use` | Show plugin information |
| `/mm help` | `majesticmace.use` | Display help menu |

## Building from Source

1. **Clone** the repository
2. **Ensure** you have Maven and Java 17+ installed
3. **Run** `mvn clean package` in the project directory
4. **Find** the compiled JAR in the `target/` directory

## Compatibility

- ✅ **Minecraft Version:** 1.21.1
- ✅ **Server Software:** Paper, Spigot, Purpur
- ✅ **Java Version:** 17+
- ✅ **Dependencies:** None required

## Support & Issues

For support, bug reports, or feature requests:
- Create an issue on the GitHub repository
- Contact SharpKingYT directly
- Check the plugin logs for detailed error information

## License

This plugin is released under the MIT License. See LICENSE file for details.

---

**Made with ❤️ by SharpKingYT**