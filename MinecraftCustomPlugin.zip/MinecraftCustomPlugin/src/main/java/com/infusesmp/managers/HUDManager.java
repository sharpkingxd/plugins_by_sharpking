package com.infusesmp.managers;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class HUDManager {
    
    private final InfuseSMPPlugin plugin;
    
    public HUDManager(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        startHUDUpdateTask();
    }
    
    private void startHUDUpdateTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    updateHUD(player);
                }
            }
        }.runTaskTimer(plugin, 0L, 20L); // Update every second
    }
    
    public void updateHUD(Player player) {
        // Disabled: HUD is now handled by InfuseHUD boss bar
    }
    
    public void clearHUD(Player player) {
        // Disabled: HUD is now handled by InfuseHUD boss bar
    }
    
    private Component createPotionComponent(PotionType potionType, boolean enabled, boolean isPrimary) {
        if (potionType == null) {
            String slot = isPrimary ? "Primary" : "Secondary";
            return Component.text("[Empty " + slot + "]")
                    .color(NamedTextColor.DARK_GRAY);
        }
        
        NamedTextColor color = enabled ? 
                (isPrimary ? NamedTextColor.RED : NamedTextColor.BLUE) : 
                NamedTextColor.GRAY;
        
        String status = enabled ? "●" : "○";
        
        return Component.text(status + " " + potionType.getIcon() + " " + potionType.getDisplayName())
                .color(color);
    }
}
