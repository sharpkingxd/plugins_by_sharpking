package com.infusesmp.managers;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.InfusePotion;
import com.infusesmp.potion.PotionType;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionData;

import java.util.HashMap;
import java.util.Map;

public class PotionManager {
    
    private final InfuseSMPPlugin plugin;
    private Map<PotionType, InfusePotion> potions;
    private Map<PotionType, ItemStack[][]> recipes;
    
    public PotionManager(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        initializePotions();
        initializeRecipes();
    }
    
    private void initializePotions() {
        potions = new HashMap<>();
        for (PotionType type : PotionType.values()) {
            potions.put(type, new InfusePotion(type, plugin));
        }
    }
    
    private void initializeRecipes() {
        // Initialize recipes
        recipes = new HashMap<>();
        
        // Regen Infuse Potion Recipe
        recipes.put(PotionType.REGEN, new ItemStack[][]{
            {new ItemStack(Material.END_CRYSTAL), new ItemStack(Material.HONEY_BLOCK), new ItemStack(Material.END_CRYSTAL)},
            {new ItemStack(Material.PEARLESCENT_FROGLIGHT), new ItemStack(Material.AXOLOTL_BUCKET), new ItemStack(Material.PEARLESCENT_FROGLIGHT)},
            {new ItemStack(Material.END_CRYSTAL), new ItemStack(Material.MUSIC_DISC_CREATOR_MUSIC_BOX), new ItemStack(Material.END_CRYSTAL)}
        });
        
        // Feather Infuse Potion Recipe
        recipes.put(PotionType.FEATHER, new ItemStack[][]{
            {new ItemStack(Material.BREEZE_ROD), new ItemStack(Material.PHANTOM_MEMBRANE), new ItemStack(Material.BREEZE_ROD)},
            {new ItemStack(Material.FEATHER), new ItemStack(Material.HEAVY_CORE), new ItemStack(Material.FEATHER)},
            {new ItemStack(Material.BREEZE_ROD), new ItemStack(Material.PHANTOM_MEMBRANE), new ItemStack(Material.BREEZE_ROD)}
        });
        
        // Thunder Infuse Potion Recipe
        recipes.put(PotionType.THUNDER, new ItemStack[][]{
            {new ItemStack(Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.LODESTONE), new ItemStack(Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE)},
            {new ItemStack(Material.TRIDENT), new ItemStack(Material.CREEPER_HEAD), new ItemStack(Material.TRIDENT)},
            {new ItemStack(Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.LODESTONE), new ItemStack(Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE)}
        });
        
        // Strength Infuse Potion Recipe
        recipes.put(PotionType.STRENGTH, new ItemStack[][]{
            {createStrengthIIPotion(), new ItemStack(Material.RIB_ARMOR_TRIM_SMITHING_TEMPLATE), createStrengthIIPotion()},
            {new ItemStack(Material.NETHERITE_SWORD), new ItemStack(Material.WITHER_ROSE), new ItemStack(Material.NETHERITE_AXE)},
            {createStrengthIIPotion(), new ItemStack(Material.RIB_ARMOR_TRIM_SMITHING_TEMPLATE), createStrengthIIPotion()}
        });
        
        // Heart Infuse Potion Recipe
        recipes.put(PotionType.HEART, new ItemStack[][]{
            {createHealingPotion(), new ItemStack(Material.TOTEM_OF_UNDYING), createHealingPotion()},
            {new ItemStack(Material.ENCHANTED_GOLDEN_APPLE), new ItemStack(Material.BEETROOT), new ItemStack(Material.ENCHANTED_GOLDEN_APPLE)},
            {createHealingPotion(), new ItemStack(Material.TOTEM_OF_UNDYING), createHealingPotion()}
        });
        
        // Frost Infuse Potion Recipe
        recipes.put(PotionType.FROST, new ItemStack[][]{
            {new ItemStack(Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.PEARLESCENT_FROGLIGHT), new ItemStack(Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE)},
            {new ItemStack(Material.RABBIT_FOOT), new ItemStack(Material.MUSIC_DISC_CREATOR), new ItemStack(Material.RABBIT_FOOT)},
            {new ItemStack(Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.PEARLESCENT_FROGLIGHT), new ItemStack(Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE)}
        });
        
        // Emerald Infuse Potion Recipe
        recipes.put(PotionType.EMERALD, new ItemStack[][]{
            {new ItemStack(Material.WILD_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.SNIFFER_EGG), new ItemStack(Material.WILD_ARMOR_TRIM_SMITHING_TEMPLATE)},
            {new ItemStack(Material.OMINOUS_BOTTLE), new ItemStack(Material.EMERALD_BLOCK), new ItemStack(Material.OMINOUS_BOTTLE)},
            {new ItemStack(Material.ENDER_CHEST), new ItemStack(Material.ENCHANTING_TABLE), new ItemStack(Material.ENDER_CHEST)}
        });
        
        // Ocean Infuse Potion Recipe
        recipes.put(PotionType.OCEAN, new ItemStack[][]{
            {new ItemStack(Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.HEART_OF_THE_SEA), new ItemStack(Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE)},
            {new ItemStack(Material.TRIDENT), new ItemStack(Material.CONDUIT), new ItemStack(Material.TRIDENT)},
            {new ItemStack(Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.HEART_OF_THE_SEA), new ItemStack(Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE)}
        });
        
        // Fire Infuse Potion Recipe
        recipes.put(PotionType.FIRE, new ItemStack[][]{
            {new ItemStack(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE), new ItemStack(Material.RESPAWN_ANCHOR), new ItemStack(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE)},
            {new ItemStack(Material.NETHERITE_INGOT), new ItemStack(Material.MUSIC_DISC_PIGSTEP), new ItemStack(Material.NETHERITE_INGOT)},
            {new ItemStack(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE), new ItemStack(Material.RESPAWN_ANCHOR), new ItemStack(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE)}
        });
        
        // Speed Infuse Potion Recipe
        recipes.put(PotionType.SPEED, new ItemStack[][]{
            {new ItemStack(Material.RABBIT_FOOT), new ItemStack(Material.SADDLE), new ItemStack(Material.RABBIT_FOOT)},
            {new ItemStack(Material.DUNE_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.DIAMOND_HORSE_ARMOR), new ItemStack(Material.EYE_ARMOR_TRIM_SMITHING_TEMPLATE)},
            {new ItemStack(Material.RABBIT_FOOT), new ItemStack(Material.NETHERITE_BOOTS), new ItemStack(Material.RABBIT_FOOT)}
        });
        
        // Haste Infuse Potion Recipe
        recipes.put(PotionType.HASTE, new ItemStack[][]{
            {new ItemStack(Material.DIAMOND_BLOCK), new ItemStack(Material.BEACON), new ItemStack(Material.DIAMOND_BLOCK)},
            {new ItemStack(Material.GOLD_BLOCK), new ItemStack(Material.DEEPSLATE_EMERALD_ORE), new ItemStack(Material.GOLD_BLOCK)},
            {new ItemStack(Material.DIAMOND_BLOCK), new ItemStack(Material.NETHERITE_PICKAXE), new ItemStack(Material.DIAMOND_BLOCK)}
        });
        
        // Invis Infuse Potion Recipe
        recipes.put(PotionType.INVIS, new ItemStack[][]{
            {new ItemStack(Material.ENDER_EYE), new ItemStack(Material.MUSIC_DISC_5), new ItemStack(Material.ENDER_EYE)},
            {new ItemStack(Material.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE), new ItemStack(Material.OMINOUS_TRIAL_KEY), new ItemStack(Material.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE)},
            {new ItemStack(Material.ENDER_EYE), new ItemStack(Material.RECOVERY_COMPASS), new ItemStack(Material.ENDER_EYE)}
        });
    }
    
    public InfusePotion getPotion(PotionType type) {
        return potions.get(type);
    }
    
    public ItemStack createPotionItem(PotionType type) {
        InfusePotion potion = potions.get(type);
        return potion != null ? potion.createItem() : null;
    }
    
    public ItemStack[][] getRecipe(PotionType type) {
        return recipes.get(type);
    }
    
    public Map<PotionType, ItemStack[][]> getAllRecipes() {
        return new HashMap<>(recipes);
    }
    
    public boolean matchesRecipe(PotionType type, ItemStack[] contents) {
        ItemStack[][] recipe = getRecipe(type);
        if (recipe == null || contents.length != 9) {
            return false;
        }
        
        // Convert 2D recipe to 1D array for comparison
        ItemStack[] flatRecipe = new ItemStack[9];
        int index = 0;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                flatRecipe[index++] = recipe[row][col];
            }
        }
        
        // Compare each slot
        for (int i = 0; i < 9; i++) {
            ItemStack recipeItem = flatRecipe[i];
            ItemStack contentItem = contents[i];
            
            if (!itemsMatch(recipeItem, contentItem)) {
                return false;
            }
        }
        
        return true;
    }
    
    private boolean itemsMatch(ItemStack recipe, ItemStack content) {
        if (recipe == null || recipe.getType() == Material.AIR) {
            return content == null || content.getType() == Material.AIR;
        }
        
        if (content == null || content.getType() == Material.AIR) {
            return false;
        }
        
        return recipe.getType() == content.getType();
    }
    
    private ItemStack createHealingPotion() {
        ItemStack potion = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) potion.getItemMeta();
        meta.setBasePotionData(new PotionData(org.bukkit.potion.PotionType.HEALING, false, false));
        potion.setItemMeta(meta);
        return potion;
    }
    
    private ItemStack createStrengthIIPotion() {
        ItemStack potion = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) potion.getItemMeta();
        meta.setBasePotionData(new PotionData(org.bukkit.potion.PotionType.STRENGTH, false, true));
        potion.setItemMeta(meta);
        return potion;
    }
}
