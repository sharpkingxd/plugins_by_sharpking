package com.chatlagfix.mixin;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.network.message.MessageHandler;
import net.minecraft.network.message.MessageType;
import net.minecraft.network.message.SignedMessage;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Mixin(MessageHandler.class)
public abstract class MessageHandlerMixin {

    @Unique
    private static final ExecutorService backgroundService = Executors.newFixedThreadPool(1);

    @Unique
    private static final ThreadLocal<Boolean> isAsyncHandling = ThreadLocal.withInitial(() -> false);

    @Inject(method = "onChatMessage", at = @At("HEAD"), cancellable = true)
    private void handlePlayerChatAsync(SignedMessage message, GameProfile sender, MessageType.Parameters params, CallbackInfo ci) {
        if (isAsyncHandling.get()) return;

        ci.cancel();

        backgroundService.submit(() -> {
            isAsyncHandling.set(true);
            try {
                ((MessageHandler) (Object) this).onChatMessage(message, sender, params);
            } finally {
                isAsyncHandling.set(false);
            }
        });
    }

    @Inject(method = "onGameMessage", at = @At("HEAD"), cancellable = true)
    private void handleSystemChatAsync(Text message, boolean overlay, CallbackInfo ci) {
        if (isAsyncHandling.get()) return;

        ci.cancel();

        backgroundService.submit(() -> {
            isAsyncHandling.set(true);
            try {
                ((MessageHandler) (Object) this).onGameMessage(message, overlay);
            } finally {
                isAsyncHandling.set(false);
            }
        });
    }
}