package com.sharpkingyt.majesticmace.listeners;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.CraftingInventory;

import com.sharpkingyt.majesticmace.MajesticMace;
import com.sharpkingyt.majesticmace.utils.SmallCapsConverter;

public class RecipeListener implements Listener {
    
    private final MajesticMace plugin;
    
    public RecipeListener(MajesticMace plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        CraftingInventory inventory = event.getInventory();
        ItemStack result = inventory.getResult();
        
        // Block vanilla mace crafting if result is mace and recipe system is enabled
        if (result != null && result.getType() == Material.MACE) {
            if (!plugin.getRecipeManager().isRecipeEnabled()) {
                // If custom recipe system is disabled, block all mace crafting
                inventory.setResult(null);
                
                if (event.getView().getPlayer() instanceof Player) {
                    Player player = (Player) event.getView().getPlayer();
                    player.sendMessage("§c§l" + SmallCapsConverter.convert("Mace crafting is currently disabled!"));
                    plugin.getSoundManager().playSound(player, "access-denied");
                }
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCraftItem(CraftItemEvent event) {
        ItemStack result = event.getCurrentItem();
        
        // Additional check during actual crafting
        if (result != null && result.getType() == Material.MACE) {
            if (!plugin.getRecipeManager().isRecipeEnabled()) {
                event.setCancelled(true);
                
                if (event.getWhoClicked() instanceof Player) {
                    Player player = (Player) event.getWhoClicked();
                    player.sendMessage("§c§l" + SmallCapsConverter.convert("Mace crafting is currently disabled!"));
                    plugin.getSoundManager().playSound(player, "access-denied");
                }
            } else {
                // Log successful mace crafting
                if (plugin.getConfig().getBoolean("logging.recipe-modifications", true)) {
                    plugin.getLogger().info("Player " + event.getWhoClicked().getName() + " crafted a mace using custom recipe");
                }
            }
        }
    }
}