package me.pipewasxd.strengthsmp;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public record AbilityCommand(TridentUltimate tridentUltimate, AxeUltimate axeUltimate, ShieldUltimate shieldUltimate, BowUltimate bowUltimate, CrossbowUltimate crossbowUltimate, WeaponManager weaponManager) implements CommandExecutor {
   public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         WeaponType weapon = this.weaponManager.getPlayerWeapon(player);
         switch (weapon) {
            case TRIDENT:
               return this.tridentUltimate.onAbilityCommand(sender, command, label, args);
            case AXE:
               return this.axeUltimate.onAbilityCommand(sender, command, label, args);
            case SHIELD:
               return this.shieldUltimate.onAbilityCommand(sender, command, label, args);
            default:
               player.sendMessage("Your weapon type doesn't have an ability command!");
               return true;
         }
      } else {
         sender.sendMessage("Only players can use this command.");
         return true;
      }
   }
}
