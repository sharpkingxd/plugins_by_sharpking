package com.sharpkingyt.majesticmace;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.Listener;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.ShapedRecipe;

import com.sharpkingyt.majesticmace.commands.MajesticMaceCommand;
import com.sharpkingyt.majesticmace.listeners.RecipeListener;
import com.sharpkingyt.majesticmace.listeners.GUIListener;
import com.sharpkingyt.majesticmace.managers.RecipeManager;
import com.sharpkingyt.majesticmace.managers.GUIManager;
import com.sharpkingyt.majesticmace.managers.SoundManager;

import java.util.Iterator;
import java.util.logging.Logger;

public class MajesticMace extends JavaPlugin implements Listener {
    
    private static MajesticMace instance;
    private RecipeManager recipeManager;
    private GUIManager guiManager;
    private SoundManager soundManager;
    private GUIListener guiListener;
    private Logger logger;
    
    @Override
    public void onEnable() {
        instance = this;
        logger = getLogger();
        
        // Save default config
        saveDefaultConfig();
        
        // Initialize managers
        soundManager = new SoundManager(this);
        recipeManager = new RecipeManager(this);
        guiManager = new GUIManager(this);
        
        // Register commands
        getCommand("majesticmace").setExecutor(new MajesticMaceCommand(this));
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new RecipeListener(this), this);
        guiListener = new GUIListener(this);
        getServer().getPluginManager().registerEvents(guiListener, this);
        
        // Block vanilla mace recipe
        blockVanillaMaceRecipe();
        
        // Load custom recipe
        recipeManager.loadCustomRecipe();
        
        logger.info("MajesticMace v1.0.0 by SharpKingYT has been enabled!");
    }
    
    @Override
    public void onDisable() {
        // Save config before shutdown
        saveConfig();
        
        // Remove custom recipes
        recipeManager.removeCustomRecipe();
        
        logger.info("MajesticMace has been disabled!");
    }
    
    private void blockVanillaMaceRecipe() {
        // Remove all existing mace recipes
        Iterator<Recipe> recipeIterator = Bukkit.recipeIterator();
        while (recipeIterator.hasNext()) {
            Recipe recipe = recipeIterator.next();
            if (recipe.getResult().getType() == Material.MACE) {
                recipeIterator.remove();
                logger.info("Blocked vanilla mace recipe");
            }
        }
    }
    
    public void reloadPluginConfig() {
        reloadConfig();
        soundManager.reloadSounds();
        recipeManager.loadCustomRecipe();
        logger.info("Configuration reloaded successfully!");
    }
    
    // Getters
    public static MajesticMace getInstance() {
        return instance;
    }
    
    public RecipeManager getRecipeManager() {
        return recipeManager;
    }
    
    public GUIManager getGUIManager() {
        return guiManager;
    }
    
    public SoundManager getSoundManager() {
        return soundManager;
    }
    
    public GUIListener getGUIListener() {
        return guiListener;
    }
}