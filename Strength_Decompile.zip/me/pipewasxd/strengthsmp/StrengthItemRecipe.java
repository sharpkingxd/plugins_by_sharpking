package me.pipewasxd.strengthsmp;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.attribute.AttributeModifier.Operation;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public record StrengthItemRecipe(StrengthSMP plugin, ConfigManager configManager) {
   public static ItemStack createStrengthItem() {
      ItemStack item = new ItemStack(Material.NAUTILUS_SHELL);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(String.valueOf(ChatColor.DARK_RED) + "sᴛʀᴇɴɢᴛʜ");
         List<String> lore = new ArrayList();
         String var10001 = String.valueOf(ChatColor.WHITE);
         lore.add(var10001 + "ʀɪɢʜᴛ-ᴄʟɪᴄᴋ ᴛᴏ ɢᴀɪɴ " + String.valueOf(ChatColor.GREEN) + "+1 " + String.valueOf(ChatColor.WHITE) + "sᴛʀᴇɴɢᴛʜ");
         meta.setLore(lore);
         NamespacedKey key = new NamespacedKey("strengthsmp", "strength_item_modifier");
         AttributeModifier modifier = new AttributeModifier(key, (double)1.0F, Operation.ADD_NUMBER, EquipmentSlotGroup.HAND);
         meta.addAttributeModifier(Attribute.GENERIC_ATTACK_DAMAGE, modifier);
         meta.setCustomModelData(12345);
         NamespacedKey itemKey = new NamespacedKey("strengthsmp", "strength_item");
         meta.getPersistentDataContainer().set(itemKey, PersistentDataType.BYTE, (byte)1);
         item.setItemMeta(meta);
      }

      return item;
   }

   public static boolean isStrengthItem(ItemStack item) {
      if (item != null && item.hasItemMeta()) {
         ItemMeta meta = item.getItemMeta();
         NamespacedKey itemKey = new NamespacedKey("strengthsmp", "strength_item");
         return meta.getPersistentDataContainer().has(itemKey, PersistentDataType.BYTE);
      } else {
         return false;
      }
   }

   public void registerRecipe() {
      NamespacedKey key = new NamespacedKey(this.plugin, "strength_item");
      Bukkit.removeRecipe(key);
      ShapedRecipe recipe = new ShapedRecipe(key, createStrengthItem());
      Material topLeft = this.configManager.getRecipeTopLeft();
      Material top = this.configManager.getRecipeTop();
      Material topRight = this.configManager.getRecipeTopRight();
      Material left = this.configManager.getRecipeLeft();
      Material center = this.configManager.getRecipeCenter();
      Material right = this.configManager.getRecipeRight();
      Material bottomLeft = this.configManager.getRecipeBottomLeft();
      Material bottom = this.configManager.getRecipeBottom();
      Material bottomRight = this.configManager.getRecipeBottomRight();
      recipe.shape(new String[]{"ABC", "DEF", "GHI"});
      if (topLeft != Material.AIR) {
         recipe.setIngredient('A', topLeft);
      }

      if (top != Material.AIR) {
         recipe.setIngredient('B', top);
      }

      if (topRight != Material.AIR) {
         recipe.setIngredient('C', topRight);
      }

      if (left != Material.AIR) {
         recipe.setIngredient('D', left);
      }

      if (center != Material.AIR) {
         recipe.setIngredient('E', center);
      }

      if (right != Material.AIR) {
         recipe.setIngredient('F', right);
      }

      if (bottomLeft != Material.AIR) {
         recipe.setIngredient('G', bottomLeft);
      }

      if (bottom != Material.AIR) {
         recipe.setIngredient('H', bottom);
      }

      if (bottomRight != Material.AIR) {
         recipe.setIngredient('I', bottomRight);
      }

      try {
         Bukkit.addRecipe(recipe);
         this.plugin.getLogger().info("Registered strength item recipe successfully!");
      } catch (IllegalStateException var13) {
         this.plugin.getLogger().warning("Recipe already exists!");
      }

   }
}
