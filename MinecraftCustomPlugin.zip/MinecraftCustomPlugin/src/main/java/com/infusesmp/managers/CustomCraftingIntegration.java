package com.infusesmp.managers;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;

public class CustomCraftingIntegration {

    private final InfuseSMPPlugin plugin;
    private Object customCrafting;
    private boolean enabled = false;

    public CustomCraftingIntegration(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        setupCustomCrafting();
    }

    private void setupCustomCrafting() {
        Plugin ccPlugin = Bukkit.getPluginManager().getPlugin("CustomCrafting");
        if (ccPlugin != null) {
            customCrafting = ccPlugin;
            enabled = true;
            registerRecipes();
            plugin.getLogger().info("CustomCrafting integration enabled!");
        }
    }

    private void registerRecipes() {
        if (!enabled) return;

        // Register each potion recipe
        for (PotionType type : PotionType.values()) {
            try {
                registerPotionRecipe(type);
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to register recipe for " + type.name() + ": " + e.getMessage());
            }
        }
    }

    private void registerPotionRecipe(PotionType type) {
        ItemStack[][] recipe = plugin.getPotionManager().getRecipe(type);
        if (recipe == null) return;

        try {
            // Get the CustomCrafting API classes using reflection
            Class<?> recipeBuilderClass = Class.forName("com.wolfyscript.customcrafting.recipes.types.CraftingRecipe$Builder");
            Class<?> customCraftingClass = Class.forName("com.wolfyscript.customcrafting.CustomCrafting");
            
            // Create recipe builder
            Method shapedRecipeMethod = recipeBuilderClass.getMethod("shapedRecipe", String.class, ItemStack.class);
            Object builder = shapedRecipeMethod.invoke(null, "infusesmp_" + type.name().toLowerCase(), 
                                                     plugin.getPotionManager().createPotionItem(type));

            // Convert our 3x3 recipe format to CustomCrafting format
            String[] shape = new String[3];
            for (int row = 0; row < 3; row++) {
                StringBuilder shapeRow = new StringBuilder();
                for (int col = 0; col < 3; col++) {
                    ItemStack item = recipe[row][col];
                    char symbol = getSymbolForItem(item);
                    shapeRow.append(symbol);
                    
                    if (item != null) {
                        Method setIngredientMethod = recipeBuilderClass.getMethod("setIngredient", char.class, ItemStack.class);
                        setIngredientMethod.invoke(builder, symbol, item);
                    }
                }
                shape[row] = shapeRow.toString();
            }

            // Set the shape
            Method shapeMethod = recipeBuilderClass.getMethod("shape", String[].class);
            shapeMethod.invoke(builder, (Object) shape);

            // Build and register the recipe
            Method buildMethod = recipeBuilderClass.getMethod("build");
            Object customRecipe = buildMethod.invoke(builder);

            // Add the recipe to CustomCrafting
            Method getRegistriesMethod = customCraftingClass.getMethod("getRegistries");
            Object registries = getRegistriesMethod.invoke(customCrafting);
            Method getRecipesMethod = registries.getClass().getMethod("getRecipes");
            Object recipeRegistry = getRecipesMethod.invoke(registries);
            Method addMethod = recipeRegistry.getClass().getMethod("add", customRecipe.getClass());
            addMethod.invoke(recipeRegistry, customRecipe);

        } catch (Exception e) {
            plugin.getLogger().warning("Failed to register recipe for " + type.name() + ": " + e.getMessage());
        }
    }

    private char getSymbolForItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            return ' ';
        }
        // Use first letter of material name, or fallback symbols if taken
        String name = item.getType().name();
        char symbol = name.charAt(0);
        if (symbol == ' ') {
            symbol = 'X';
        }
        return symbol;
    }

    public boolean isEnabled() {
        return enabled;
    }
} 