package dlindustries.vigillant.system.mixin;

public interface BufferRendererAccessor {

}
