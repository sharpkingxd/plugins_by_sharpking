package com.sharpkingyt.majesticmace.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.event.Event;

import com.sharpkingyt.majesticmace.MajesticMace;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GUIListener implements Listener {
    
    private final MajesticMace plugin;
    private final int[] CRAFTING_SLOTS = {10, 11, 12, 19, 20, 21, 28, 29, 30};
    private final Map<UUID, String> openGUIs = new HashMap<>();
    
    public GUIListener(MajesticMace plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        Player player = (Player) event.getWhoClicked();
        Inventory topInventory = event.getView().getTopInventory();
        Inventory clickedInventory = event.getClickedInventory();
        
        if (!isOurGUI(topInventory)) return;
        
        // Handle view recipe GUI (all slots protected except close button)
        if (isViewRecipeGUI(topInventory)) {
            if (clickedInventory == topInventory) {
                event.setCancelled(true);
                if (event.getSlot() == 49 && event.getCurrentItem() != null && 
                    (event.getClick() == ClickType.LEFT || event.getClick() == ClickType.RIGHT)) {
                    player.closeInventory();
                }
            }
            return;
        }
        
        // Check inventory type FIRST
        if (clickedInventory == topInventory) {
            // Clicking in GUI inventory
            handleGUIClick(event, player, topInventory);
        } else if (clickedInventory != null && clickedInventory != topInventory) {
            // Clicking in player inventory - allow all actions
            return;
        }
    }
    
    private void handleGUIClick(InventoryClickEvent event, Player player, Inventory inventory) {
        int slot = event.getSlot();
        
        // Handle button clicks
        if (slot == 48) {
            event.setCancelled(true);
            if (event.getCurrentItem() != null && 
                (event.getClick() == ClickType.LEFT || event.getClick() == ClickType.RIGHT)) {
                if (player.isOp()) {
                    player.sendMessage("§7[ᴅᴇʙᴜɢ] ʙᴜᴛᴛᴏɴ ᴄʟɪᴄᴋᴇᴅ: ꜱʟᴏᴛ 48");
                    saveRecipe(player, inventory);
                } else {
                    player.sendMessage("§c§lᴀᴄᴄᴇꜱꜱ ᴅᴇɴɪᴇᴅ! ʏᴏᴜ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ᴘᴇʀᴍɪꜱꜱɪᴏɴ ᴛᴏ ꜱᴀᴠᴇ ʀᴇᴄɪᴘᴇꜱ.");
                    plugin.getSoundManager().playSound(player, "access-denied");
                }
            }
        } else if (slot == 50) {
            event.setCancelled(true);
            if (event.getCurrentItem() != null && 
                (event.getClick() == ClickType.LEFT || event.getClick() == ClickType.RIGHT)) {
                player.sendMessage("§7[ᴅᴇʙᴜɢ] ʙᴜᴛᴛᴏɴ ᴄʟɪᴄᴋᴇᴅ: ꜱʟᴏᴛ 50");
                player.closeInventory();
                plugin.getSoundManager().playSound(player, "gui-close");
            }
        } else if (isCraftingSlot(slot) && player.isOp()) {
            // Allow all actions for OP players in crafting slots
            InventoryAction action = event.getAction();
            if (action == InventoryAction.PLACE_ALL || action == InventoryAction.PLACE_ONE || 
                action == InventoryAction.PLACE_SOME || action == InventoryAction.PICKUP_ALL || 
                action == InventoryAction.PICKUP_ONE || action == InventoryAction.PICKUP_HALF || 
                action == InventoryAction.PICKUP_SOME || action == InventoryAction.SWAP_WITH_CURSOR || 
                action == InventoryAction.HOTBAR_SWAP || action == InventoryAction.HOTBAR_MOVE_AND_READD ||
                action == InventoryAction.MOVE_TO_OTHER_INVENTORY || action == InventoryAction.COLLECT_TO_CURSOR) {
                return; // Allow the action
            }
        } else {
            // All other GUI slots are protected
            event.setCancelled(true);
            if (isCraftingSlot(slot) && !player.isOp()) {
                player.sendMessage("§c§lᴀᴄᴄᴇꜱꜱ ᴅᴇɴɪᴇᴅ! ᴏɴʟʏ ᴏᴘꜱ ᴄᴀɴ ᴍᴏᴅɪꜰʏ ʀᴇᴄɪᴘᴇ ɪɴɢʀᴇᴅɪᴇɴᴛꜱ.");
                plugin.getSoundManager().playSound(player, "access-denied");
            }
        }
    }
    
    @EventHandler(priority = EventPriority.NORMAL)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        
        Inventory topInventory = event.getView().getTopInventory();
        if (!isOurGUI(topInventory)) return;
        
        Player player = (Player) event.getWhoClicked();
        
        // Block all dragging in view GUI
        if (isViewRecipeGUI(topInventory)) {
            event.setCancelled(true);
            return;
        }
        
        // Check dragged slots
        boolean hasGUISlots = false;
        boolean hasProtectedSlots = false;
        boolean allPlayerInventory = true;
        
        for (int rawSlot : event.getRawSlots()) {
            if (rawSlot < 54) {
                // GUI inventory slot
                hasGUISlots = true;
                allPlayerInventory = false;
                if (!isCraftingSlot(rawSlot)) {
                    hasProtectedSlots = true;
                }
            }
        }
        
        if (allPlayerInventory) {
            // Dragging only within player inventory - allow
            return;
        } else if (hasProtectedSlots) {
            // Dragging to protected GUI slots - cancel
            event.setCancelled(true);
        } else if (hasGUISlots && !player.isOp()) {
            // Dragging to crafting slots but not OP - cancel
            event.setCancelled(true);
            player.sendMessage("§c§lᴀᴄᴄᴇꜱꜱ ᴅᴇɴɪᴇᴅ! ᴏɴʟʏ ᴏᴘꜱ ᴄᴀɴ ᴍᴏᴅɪꜰʏ ʀᴇᴄɪᴘᴇ ɪɴɢʀᴇᴅɪᴇɴᴛꜱ.");
            plugin.getSoundManager().playSound(player, "access-denied");
        }
        // If dragging only to crafting slots and player is OP, allow
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;
        
        Player player = (Player) event.getPlayer();
        Inventory inventory = event.getInventory();
        
        if (isOurGUI(inventory)) {
            openGUIs.remove(player.getUniqueId());
            plugin.getSoundManager().playSound(player, "gui-close");
            
            if (plugin.getConfig().getBoolean("logging.gui-interactions", false)) {
                plugin.getLogger().info("Player " + player.getName() + " closed recipe GUI");
            }
        }
    }
    
    private void saveRecipe(Player player, Inventory inventory) {
        ItemStack[] contents = inventory.getContents();
        
        // Check if at least one item exists in crafting slots
        boolean hasIngredients = false;
        for (int slot : CRAFTING_SLOTS) {
            if (contents[slot] != null && contents[slot].getType() != Material.AIR) {
                hasIngredients = true;
                break;
            }
        }
        
        if (!hasIngredients) {
            player.sendMessage("§c§lᴇʀʀᴏʀ! ᴘʟᴀᴄᴇ ᴀᴛ ʟᴇᴀꜱᴛ ᴏɴᴇ ɪᴛᴇᴍ");
            player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0f, 0.9f);
            return;
        }
        
        // Save recipe using new slot mapping
        plugin.getRecipeManager().saveRecipeFromGUI(contents, CRAFTING_SLOTS);
        
        player.sendMessage("§a§lꜱᴜᴄᴄᴇꜱꜱ! §7ʀᴇᴄɪᴘᴇ ꜱᴀᴠᴇᴅ ꜱᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ");
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
        
        if (plugin.getConfig().getBoolean("logging.recipe-modifications", true)) {
            plugin.getLogger().info("Player " + player.getName() + " saved a new mace recipe configuration");
        }
        
        // Close GUI after successful save
        player.closeInventory();
    }
    
    private boolean isCraftingSlot(int slot) {
        for (int craftingSlot : CRAFTING_SLOTS) {
            if (slot == craftingSlot) {
                return true;
            }
        }
        return false;
    }
    
    private boolean isOurGUI(Inventory inventory) {
        if (inventory.getSize() != 54 || inventory.getViewers().isEmpty()) return false;
        String title = inventory.getViewers().get(0).getOpenInventory().getTitle();
        return title.contains("ᴍᴀᴊᴇꜱᴛɪᴄ ᴍᴀᴄᴇ");
    }
    
    public void trackGUI(Player player, String guiType) {
        openGUIs.put(player.getUniqueId(), guiType);
    }
    
    private boolean isViewRecipeGUI(Inventory inventory) {
        if (inventory.getViewers().isEmpty()) return false;
        String title = inventory.getViewers().get(0).getOpenInventory().getTitle();
        return title.contains("ᴠɪᴇᴡ ʀᴇᴄɪᴘᴇ");
    }
}