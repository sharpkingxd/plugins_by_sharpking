package com.infusesmp.listeners;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.gui.InfuseCraftingGUI;
import com.infusesmp.gui.BrewingCrafterGUI;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.block.Block;
import org.bukkit.block.BrewingStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class BrewingListener implements Listener {
    
    private final InfuseSMPPlugin plugin;
    private static final String INFUSE_CRAFTER_NAME = "Infuse Potion Crafter";
    
    public BrewingListener(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.BREWING_STAND) return;
        
        Player player = event.getPlayer();
        
        // Check if brewing stand is named "Infuse Potion Crafter"
        if (block.getState() instanceof BrewingStand brewingStand) {
            Component customName = brewingStand.customName();
            
            // If it has no custom name, let it work as a normal brewing stand
            if (customName == null) {
                return;
            }
            
            // Convert Component to plain text for comparison
            String customNameStr = PlainTextComponentSerializer.plainText().serialize(customName);
            
            if (INFUSE_CRAFTER_NAME.equals(customNameStr)) {
                event.setCancelled(true);
                
                // Check if brewing is already active
                if (plugin.getBrewingManager().isBrewingActive(block.getLocation())) {
                    player.sendMessage(Component.text("This brewing stand is currently in use!")
                            .color(NamedTextColor.RED));
                    return;
                }
                
                // Open custom crafting GUI
                new BrewingCrafterGUI(plugin, player, block.getLocation()).open();
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getInventory().getType() != InventoryType.BREWING) return;
        
        // Check if this is our custom crafter
        if (event.getInventory().getLocation() != null) {
            Block block = event.getInventory().getLocation().getBlock();
            if (block.getState() instanceof BrewingStand brewingStand) {
                Component customName = brewingStand.customName();
                if (customName != null) {
                    String customNameStr = PlainTextComponentSerializer.plainText().serialize(customName);
                    if (INFUSE_CRAFTER_NAME.equals(customNameStr)) {
                        event.setCancelled(true);
                        
                        // Open custom crafting GUI
                        new BrewingCrafterGUI(plugin, player, block.getLocation()).open();
                    }
                }
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockPlace(BlockPlaceEvent event) {
        ItemStack item = event.getItemInHand();
        if (item.getType() != Material.BREWING_STAND) return;
        
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) {
            String displayName = PlainTextComponentSerializer.plainText().serialize(meta.displayName());
            if (INFUSE_CRAFTER_NAME.equals(displayName)) {
                Block block = event.getBlock();
                if (block.getState() instanceof BrewingStand brewingStand) {
                    brewingStand.customName(Component.text(INFUSE_CRAFTER_NAME)
                            .color(NamedTextColor.DARK_PURPLE));
                    brewingStand.update();
                    
                    event.getPlayer().sendMessage(Component.text("✨ Infuse Potion Crafter placed!")
                            .color(NamedTextColor.LIGHT_PURPLE));
                }
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH)
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() != Material.BREWING_STAND) return;
        
        if (block.getState() instanceof BrewingStand brewingStand) {
            Component customName = brewingStand.customName();
            if (customName != null) {
                String customNameStr = PlainTextComponentSerializer.plainText().serialize(customName);
                
                if (INFUSE_CRAFTER_NAME.equals(customNameStr)) {
                    // Cancel if brewing is active (even for OPs)
                    if (plugin.getBrewingManager().isBrewingActive(block.getLocation())) {
                        event.setCancelled(true);
                        event.getPlayer().sendMessage(Component.text("Cannot break an active Infuse Potion Crafter!")
                                .color(NamedTextColor.RED));
                        return;
                    }
                    // Drop as Infuse Potion Crafter
                    event.setDropItems(false);
                    ItemStack crafterItem = new ItemStack(Material.BREWING_STAND);
                    ItemMeta meta = crafterItem.getItemMeta();
                    meta.displayName(Component.text(INFUSE_CRAFTER_NAME)
                            .color(NamedTextColor.DARK_PURPLE));
                    crafterItem.setItemMeta(meta);
                    block.getWorld().dropItemNaturally(block.getLocation(), crafterItem);
                    event.getPlayer().sendMessage(Component.text("✨ Infuse Potion Crafter broken!")
                            .color(NamedTextColor.LIGHT_PURPLE));
                }
            }
        }
    }
}
