package me.pipewasxd.strengthsmp;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class TridentUltimate implements Listener {
   private final StrengthSMP plugin;
   private final WeaponManager weaponManager;
   private final StrengthManager strengthManager;
   private final Map<UUID, Long> lightningCooldown = new HashMap();
   private final Map<UUID, Boolean> ultimateActive = new HashMap();
   private final Map<UUID, Long> ultimateCooldown = new HashMap();
   private final Map<UUID, BukkitRunnable> cooldownTasks = new HashMap();
   private final Map<UUID, BukkitRunnable> waveTasks = new HashMap();

   public TridentUltimate(StrengthSMP plugin, WeaponManager weaponManager, StrengthManager strengthManager) {
      this.plugin = plugin;
      this.weaponManager = weaponManager;
      this.strengthManager = strengthManager;
   }

   public boolean onAbilityCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (player.getInventory().getItemInMainHand().getType() != Material.TRIDENT) {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#808080:#A9A9A9>ʏᴏᴜ ᴍᴜsᴛ ʜᴏʟᴅ ᴀ ᴛʀɪᴅᴇɴᴛ ᴛᴏ ᴜsᴇ ᴛʜɪs!</gradient></bold>"));
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6F, 1.2F);
            return true;
         } else if (this.weaponManager.getPlayerWeapon(player) != WeaponType.TRIDENT) {
            return true;
         } else if (!this.strengthManager.isAtMaxStrength(player)) {
            return true;
         } else {
            UUID uuid = player.getUniqueId();
            if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
               return true;
            } else if (this.isOnCooldown(player)) {
               long remaining = ((Long)this.ultimateCooldown.get(uuid) - System.currentTimeMillis()) / 1000L;
               return true;
            } else {
               this.activateUltimate(player);
               return true;
            }
         }
      } else {
         sender.sendMessage("Only players can use this command.");
         return true;
      }
   }

   @EventHandler
   public void onTridentHit(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Player attacker) {
         if (event.getEntity() instanceof LivingEntity) {
            if (attacker.getInventory().getItemInMainHand().getType() == Material.TRIDENT) {
               if (this.weaponManager.getPlayerWeapon(attacker) == WeaponType.TRIDENT) {
                  if (this.strengthManager.isAtMaxStrength(attacker)) {
                     UUID attackerUUID = attacker.getUniqueId();
                     Long lastStrike = (Long)this.lightningCooldown.get(attackerUUID);
                     if (lastStrike == null || System.currentTimeMillis() - lastStrike >= 2000L) {
                        Location hitLocation = event.getEntity().getLocation();
                        hitLocation.getWorld().strikeLightningEffect(hitLocation);
                        this.lightningCooldown.put(attackerUUID, System.currentTimeMillis());
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onSwapHands(PlayerSwapHandItemsEvent event) {
      Player player = event.getPlayer();
      if (player.isSneaking()) {
         if (player.getInventory().getItemInMainHand().getType() == Material.TRIDENT) {
            if (this.weaponManager.getPlayerWeapon(player) == WeaponType.TRIDENT) {
               if (this.strengthManager.isAtMaxStrength(player)) {
                  UUID uuid = player.getUniqueId();
                  event.setCancelled(true);
                  if (!(Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
                     if (!this.isOnCooldown(player)) {
                        this.activateUltimate(player);
                     }
                  }
               }
            }
         }
      }
   }

   public void activateUltimate(final Player player) {
      UUID uuid = player.getUniqueId();
      this.ultimateActive.put(uuid, true);
      player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#8B0000:#B22222>ᴜʟᴛɪᴍᴀᴛᴇ ᴀᴄᴛɪᴠᴀᴛᴇᴅ</gradient></bold>"));
      player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1.0F, 0.8F);
      final Location startLoc = player.getLocation().add((double)0.0F, (double)0.5F, (double)0.0F);
      final Vector direction = startLoc.getDirection().setY(0).normalize();
      final double waveWidth = (double)2.0F;
      final int waveHeight = 3;
      final int maxMoves = 20;
      BukkitRunnable waveTask = new BukkitRunnable() {
         int moves = 0;
         final Location currentLoc = startLoc.clone();
         final Set<Block> previousBlocks = new HashSet();
         final Set<Block> currentBlocks = new HashSet();

         public void run() {
            TridentUltimate.this.clearWaterBlocks(this.previousBlocks, player.getWorld());
            this.previousBlocks.clear();
            this.previousBlocks.addAll(this.currentBlocks);
            this.currentBlocks.clear();
            if (this.moves >= maxMoves) {
               TridentUltimate.this.clearWaterBlocks(this.previousBlocks, player.getWorld());
               TridentUltimate.this.deactivateUltimate(player);
               this.cancel();
            } else {
               this.currentLoc.add(direction);
               Vector perpendicular = new Vector(-direction.getZ(), (double)0.0F, direction.getX());

               for(double w = -waveWidth; w <= waveWidth; w += 0.8) {
                  for(int h = 0; h < waveHeight; ++h) {
                     Block block = this.currentLoc.clone().add(perpendicular.clone().multiply(w)).add((double)0.0F, (double)h, (double)0.0F).getBlock();
                     if (block.getType().isAir() || !block.getType().isSolid()) {
                        block.setType(Material.WATER, false);
                        this.currentBlocks.add(block);
                     }
                  }
               }

               for(LivingEntity target : player.getWorld().getNearbyLivingEntities(this.currentLoc, waveWidth + (double)1.5F, (double)waveHeight, waveWidth + (double)1.5F)) {
                  if (!target.equals(player)) {
                     Vector knockback = direction.clone().multiply((double)1.5F);
                     knockback.setY(0.4);
                     target.setVelocity(knockback);
                     player.getWorld().spawnParticle(Particle.SPLASH, target.getLocation(), 10, 0.4, (double)1.0F, 0.4, 0.1);
                     player.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 1.0F, 1.2F);
                  }
               }

               player.setVelocity(direction.clone().multiply(0.8).setY(0.1));
               player.getWorld().playSound(this.currentLoc, Sound.BLOCK_WATER_AMBIENT, 0.8F, 1.2F);
               ++this.moves;
            }
         }
      };
      waveTask.runTaskTimer(this.plugin, 0L, 2L);
      this.waveTasks.put(uuid, waveTask);
   }

   private void clearWaterBlocks(Set<Block> blocks, World world) {
      for(Block block : blocks) {
         if (block.getType() == Material.WATER) {
            block.setType(Material.AIR);
            world.spawnParticle(Particle.SPLASH, block.getLocation().add((double)0.5F, (double)0.5F, (double)0.5F), 5, 0.3, 0.3, 0.3, 0.01);
         }
      }

   }

   private void deactivateUltimate(final Player player) {
      final UUID uuid = player.getUniqueId();
      if ((Boolean)this.ultimateActive.getOrDefault(uuid, false)) {
         BukkitRunnable task = (BukkitRunnable)this.waveTasks.remove(uuid);
         if (task != null) {
            task.cancel();
         }

         this.ultimateActive.put(uuid, false);
         this.ultimateCooldown.put(uuid, System.currentTimeMillis() + 60000L);
         player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#A9A9A9:#D3D3D3>ᴏɴ ᴄᴏᴏʟᴅᴏᴡɴ</gradient></bold>"));
         player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5F, 1.0F);
         BukkitRunnable cooldownTask = new BukkitRunnable() {
            public void run() {
               player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#006400:#008000>ᴜʟᴛɪᴍᴀᴛᴇ ʀᴇᴀᴅʏ</gradient></bold>"));
               player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
               TridentUltimate.this.cooldownTasks.remove(uuid);
            }
         };
         cooldownTask.runTaskLater(this.plugin, 1200L);
         this.cooldownTasks.put(uuid, cooldownTask);
      }
   }

   public boolean isOnCooldown(Player player) {
      Long cooldownEnd = (Long)this.ultimateCooldown.get(player.getUniqueId());
      return cooldownEnd != null && System.currentTimeMillis() < cooldownEnd;
   }
}
