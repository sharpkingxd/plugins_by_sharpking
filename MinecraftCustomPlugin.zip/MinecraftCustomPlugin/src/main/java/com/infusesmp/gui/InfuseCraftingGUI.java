package com.infusesmp.gui;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.utils.ItemUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.potion.PotionEffectType;
import com.infusesmp.potion.PotionType;

import java.util.*;

public class InfuseCraftingGUI implements Listener {
    
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Inventory> activeGUIs;
    private final Map<PotionType, InfuseRecipe> recipes;
    
    public InfuseCraftingGUI(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.activeGUIs = new HashMap<>();
        this.recipes = new HashMap<>();
        
        initializeRecipes();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    private void initializeRecipes() {
        // Initialize all potion recipes with 3x3 crafting patterns
        recipes.put(PotionType.REGEN, new InfuseRecipe(PotionType.REGEN, new Material[]{
            Material.END_CRYSTAL, Material.HONEY_BLOCK, Material.END_CRYSTAL,
            Material.PEARLESCENT_FROGLIGHT, Material.AXOLOTL_BUCKET, Material.PEARLESCENT_FROGLIGHT,
            Material.END_CRYSTAL, Material.MUSIC_DISC_CREATOR_MUSIC_BOX, Material.END_CRYSTAL
        }));
        
        recipes.put(PotionType.FEATHER, new InfuseRecipe(PotionType.FEATHER, new Material[]{
            Material.BREEZE_ROD, Material.PHANTOM_MEMBRANE, Material.BREEZE_ROD,
            Material.FEATHER, Material.HEAVY_CORE, Material.FEATHER,
            Material.BREEZE_ROD, Material.PHANTOM_MEMBRANE, Material.BREEZE_ROD
        }));
        
        recipes.put(PotionType.THUNDER, new InfuseRecipe(PotionType.THUNDER, new Material[]{
            Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE, Material.LODESTONE, Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE,
            Material.TRIDENT, Material.CREEPER_HEAD, Material.TRIDENT,
            Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE, Material.LODESTONE, Material.BOLT_ARMOR_TRIM_SMITHING_TEMPLATE
        }));
        
        recipes.put(PotionType.STRENGTH, new InfuseRecipe(PotionType.STRENGTH, new Material[]{
            Material.POTION, Material.RIB_ARMOR_TRIM_SMITHING_TEMPLATE, Material.POTION,
            Material.NETHERITE_SWORD, Material.WITHER_ROSE, Material.NETHERITE_AXE,
            Material.POTION, Material.RIB_ARMOR_TRIM_SMITHING_TEMPLATE, Material.POTION
        }));
        
        recipes.put(PotionType.HEART, new InfuseRecipe(PotionType.HEART, new Material[]{
            Material.POTION, Material.TOTEM_OF_UNDYING, Material.POTION,
            Material.ENCHANTED_GOLDEN_APPLE, Material.BEETROOT, Material.ENCHANTED_GOLDEN_APPLE,
            Material.POTION, Material.TOTEM_OF_UNDYING, Material.POTION
        }));
        
        recipes.put(PotionType.FROST, new InfuseRecipe(PotionType.FROST, new Material[]{
            Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE, Material.PEARLESCENT_FROGLIGHT, Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE,
            Material.RABBIT_FOOT, Material.MUSIC_DISC_CREATOR, Material.RABBIT_FOOT,
            Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE, Material.PEARLESCENT_FROGLIGHT, Material.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE
        }));
        
        recipes.put(PotionType.EMERALD, new InfuseRecipe(PotionType.EMERALD, new Material[]{
            Material.WILD_ARMOR_TRIM_SMITHING_TEMPLATE, Material.SNIFFER_EGG, Material.WILD_ARMOR_TRIM_SMITHING_TEMPLATE,
            Material.OMINOUS_BOTTLE, Material.EMERALD_BLOCK, Material.OMINOUS_BOTTLE,
            Material.ENDER_CHEST, Material.ENCHANTING_TABLE, Material.ENDER_CHEST
        }));
        
        recipes.put(PotionType.OCEAN, new InfuseRecipe(PotionType.OCEAN, new Material[]{
            Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE, Material.HEART_OF_THE_SEA, Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE,
            Material.TRIDENT, Material.CONDUIT, Material.TRIDENT,
            Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE, Material.HEART_OF_THE_SEA, Material.TIDE_ARMOR_TRIM_SMITHING_TEMPLATE
        }));
        
        recipes.put(PotionType.FIRE, new InfuseRecipe(PotionType.FIRE, new Material[]{
            Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, Material.RESPAWN_ANCHOR, Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE,
            Material.NETHERITE_INGOT, Material.MUSIC_DISC_PIGSTEP, Material.NETHERITE_INGOT,
            Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, Material.RESPAWN_ANCHOR, Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE
        }));
        
        recipes.put(PotionType.SPEED, new InfuseRecipe(PotionType.SPEED, new Material[]{
            Material.RABBIT_FOOT, Material.SADDLE, Material.RABBIT_FOOT,
            Material.DUNE_ARMOR_TRIM_SMITHING_TEMPLATE, Material.DIAMOND_HORSE_ARMOR, Material.EYE_ARMOR_TRIM_SMITHING_TEMPLATE,
            Material.RABBIT_FOOT, Material.NETHERITE_BOOTS, Material.RABBIT_FOOT
        }));
        
        recipes.put(PotionType.HASTE, new InfuseRecipe(PotionType.HASTE, new Material[]{
            Material.DIAMOND_BLOCK, Material.BEACON, Material.DIAMOND_BLOCK,
            Material.GOLD_BLOCK, Material.DEEPSLATE_EMERALD_ORE, Material.GOLD_BLOCK,
            Material.DIAMOND_BLOCK, Material.NETHERITE_PICKAXE, Material.DIAMOND_BLOCK
        }));
        
        recipes.put(PotionType.INVIS, new InfuseRecipe(PotionType.INVIS, new Material[]{
            Material.ENDER_EYE, Material.MUSIC_DISC_5, Material.ENDER_EYE,
            Material.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE, Material.OMINOUS_TRIAL_KEY, Material.SILENCE_ARMOR_TRIM_SMITHING_TEMPLATE,
            Material.ENDER_EYE, Material.RECOVERY_COMPASS, Material.ENDER_EYE
        }));
    }
    
    public void openCraftingGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 54, Component.text("Infuse Potion Crafter").color(NamedTextColor.DARK_PURPLE));
        
        // Set up the 3x3 crafting grid (slots 10-12, 19-21, 28-30)
        // Result slot at 24
        
        // Add decorative items
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.displayName(Component.text(" "));
        filler.setItemMeta(fillerMeta);
        
        // Fill non-crafting slots
        for (int i = 0; i < 54; i++) {
            if (!isCraftingSlot(i) && i != 24) {
                gui.setItem(i, filler);
            }
        }
        
        activeGUIs.put(player.getUniqueId(), gui);
        player.openInventory(gui);
    }
    
    private boolean isCraftingSlot(int slot) {
        return (slot >= 10 && slot <= 12) || (slot >= 19 && slot <= 21) || (slot >= 28 && slot <= 30);
    }
    
    private int[] getCraftingSlots() {
        return new int[]{10, 11, 12, 19, 20, 21, 28, 29, 30};
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        
        Inventory clicked = event.getClickedInventory();
        if (clicked == null || !activeGUIs.containsValue(clicked)) return;
        
        int slot = event.getSlot();
        
        // Allow interaction with crafting slots and result slot
        if (isCraftingSlot(slot)) {
            // Allow normal interaction
            updateResult(player, clicked);
            return;
        }
        
        if (slot == 24) {
            // Result slot - allow taking result
            event.setCancelled(true);
            takeResult(player, clicked);
            return;
        }
        
        // Cancel all other clicks
        event.setCancelled(true);
    }
    
    private void updateResult(Player player, Inventory gui) {
        // Get items from crafting grid
        int[] slots = getCraftingSlots();
        Material[] pattern = new Material[9];
        ItemStack[] items = new ItemStack[9];
        for (int i = 0; i < 9; i++) {
            ItemStack item = gui.getItem(slots[i]);
            items[i] = item;
            pattern[i] = (item != null && item.getType() != Material.AIR) ? item.getType() : null;
        }
        // Check if pattern matches any recipe
        PotionType result = checkRecipe(pattern, items);
        if (result != null) {
            int crafted = plugin.getPotionCounterManager().getCount(result);
            if (crafted >= 3) {
                gui.setItem(24, null); // Block crafting if limit reached
            } else {
                ItemStack resultPotion = createInfusePotion(result);
                gui.setItem(24, resultPotion);
            }
        } else {
            gui.setItem(24, null);
        }
    }
    
    private PotionType checkRecipe(Material[] pattern, ItemStack[] items) {
        for (Map.Entry<PotionType, InfuseRecipe> entry : recipes.entrySet()) {
            PotionType type = entry.getKey();
            Material[] recipePattern = entry.getValue().getPattern();
            boolean match = true;
            for (int i = 0; i < 9; i++) {
                if (recipePattern[i] == Material.POTION) {
                    ItemStack item = items[i];
                    if (item == null || item.getType() != Material.POTION) {
                        match = false;
                        break;
                    }
                    PotionMeta meta = (PotionMeta) item.getItemMeta();
                    if (type == PotionType.STRENGTH) {
                        if (!meta.hasCustomEffect(PotionEffectType.STRENGTH) && 
                            (meta.getBasePotionData().getType() != org.bukkit.potion.PotionType.STRENGTH || 
                             !meta.getBasePotionData().isUpgraded() || 
                             meta.getBasePotionData().isExtended())) {
                            match = false;
                            break;
                        }
                    } else if (type == PotionType.HEART) {
                        if (!meta.hasCustomEffect(PotionEffectType.INSTANT_HEALTH) && 
                            meta.getBasePotionData().getType() != org.bukkit.potion.PotionType.HEALING) {
                            match = false;
                            break;
                        }
                        if (meta.getBasePotionData().isUpgraded() || meta.getBasePotionData().isExtended()) {
                            match = false;
                            break;
                        }
                    }
                } else if (pattern[i] != recipePattern[i]) {
                    match = false;
                    break;
                }
            }
            if (match) return type;
        }
        return null;
    }
    
    private void takeResult(Player player, Inventory gui) {
        ItemStack result = gui.getItem(24);
        if (result == null || result.getType() == Material.AIR) return;
        PotionType type = null;
        // Find which potion is being crafted
        for (PotionType t : PotionType.values()) {
            if (plugin.getPotionManager().createPotionItem(t).isSimilar(result)) {
                type = t;
                break;
            }
        }
        if (type == null) return;
        int crafted = plugin.getPotionCounterManager().getCount(type);
        if (crafted >= 3) {
            player.sendMessage("§cYou cannot craft this potion anymore. The server limit (3) has been reached.");
            gui.setItem(24, null);
            return;
        }
        // Give result to player
        player.getInventory().addItem(result);
        // Consume ingredients
        int[] slots = getCraftingSlots();
        for (int slot : slots) {
            ItemStack item = gui.getItem(slot);
            if (item != null && item.getAmount() > 1) {
                item.setAmount(item.getAmount() - 1);
            } else {
                gui.setItem(slot, null);
            }
        }
        // Clear result
        gui.setItem(24, null);
        // Increment counter and save
        plugin.getPotionCounterManager().increment(type);
        int remaining = 3 - plugin.getPotionCounterManager().getCount(type);
        
        // Broadcast message with remaining crafts
        String broadcastMsg = String.format(
            "§6[InfuseSMP] §e%s has crafted %s! §7(§e%d§7/§e3§7 crafts used, §e%d§7 remaining)",
            player.getName(),
            type.getDisplayName(),
            plugin.getPotionCounterManager().getCount(type),
            remaining
        );
        Bukkit.broadcastMessage(broadcastMsg);
        
        // Send player a direct message with remaining crafts
        player.sendMessage(Component.text("You crafted " + type.getDisplayName() + "! You can craft it " + 
            (remaining > 0 ? (remaining + " more times.") : "no more times."))
            .color(NamedTextColor.YELLOW));
    }
    
    private ItemStack createInfusePotion(PotionType type) {
        return plugin.getPotionManager().createPotionItem(type);
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            activeGUIs.remove(player.getUniqueId());
        }
    }
    
    private static class InfuseRecipe {
        private final PotionType result;
        private final Material[] pattern;
        
        public InfuseRecipe(PotionType result, Material[] pattern) {
            this.result = result;
            this.pattern = pattern;
        }
        
        public PotionType getResult() {
            return result;
        }
        
        public Material[] getPattern() {
            return pattern;
        }
    }
}