package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.*;

public class SpeedEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Integer> speedLevel = new HashMap<>();
    private final Map<UUID, Long> lastHitTime = new HashMap<>();
    private final Map<UUID, Long> lastDashTime = new HashMap<>();
    private final Map<UUID, Integer> dashCharges = new HashMap<>();
    private final Map<UUID, BukkitTask> dashResetTasks = new HashMap<>(); // Track reset tasks
    private final Map<UUID, Long> dashCooldownEnd = new HashMap<>(); // Track dash cooldown end time
    private static final long SPEED_RESET_DELAY = 1000; // 1 second in milliseconds
    private static final long DASH_COOLDOWN = 2000; // 2 seconds between jumps
    private static final long DASH_RECHARGE_TIME = 2000; // 2 seconds between charges
    private static final long DASH_RESET_TIME = 10000; // 10 seconds to reset counter
    private static final int MAX_DASH_CHARGES = 3;
    private static final double DASH_DISTANCE = 5.0;
    private static final double BOW_CHARGE_MULTIPLIER = 1.5;
    private static final long DASH_COOLDOWN_TIME = 20000; // 20 seconds cooldown after all dashes

    public SpeedEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        startSpeedResetTask();
    }

    @Override
    public void activatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        speedLevel.put(playerId, 0);
        long now = System.currentTimeMillis();
        if (dashCooldownEnd.containsKey(playerId) && now < dashCooldownEnd.get(playerId)) {
            dashCharges.put(playerId, 0);
        } else {
            dashCharges.put(playerId, MAX_DASH_CHARGES);
        }
        if (dashResetTasks.containsKey(playerId)) {
            dashResetTasks.get(playerId).cancel();
            dashResetTasks.remove(playerId);
        }
        safeRemoveAndAddSpeed(player);
        broadcastDashCharges(player);
    }

    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        speedLevel.remove(playerId);
        lastHitTime.remove(playerId);
        lastDashTime.remove(playerId);
        dashCharges.remove(playerId);
        dashCooldownEnd.remove(playerId);
        PotionEffect effect = player.getPotionEffect(PotionEffectType.SPEED);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.SPEED);
        }
    }

    @Override
    public void useSpark(Player player) {
        UUID playerId = player.getUniqueId();
        long now = System.currentTimeMillis();
        // Check if dash cooldown is active
        if (dashCooldownEnd.containsKey(playerId) && now < dashCooldownEnd.get(playerId)) {
            long timeLeft = (dashCooldownEnd.get(playerId) - now) / 1000;
            player.sendMessage(Component.text("❌ Dash is on cooldown! (" + timeLeft + "s)").color(NamedTextColor.RED));
            return;
        }
        // Check if player has any dash charges
        int charges = dashCharges.getOrDefault(playerId, 0);
        player.sendMessage(Component.text("[DEBUG] Dash charges before dash: " + charges).color(NamedTextColor.YELLOW));
        if (charges <= 0) {
            player.sendMessage(Component.text("❌ No dash charges remaining!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        // Get dash direction and perform dash
        Vector direction;
        Location targetLoc = player.getTargetBlock(null, 5).getLocation();
        
        if (targetLoc.getBlock().getType().isSolid()) {
            // If looking at a block, dash to it
            direction = targetLoc.toVector().subtract(player.getLocation().toVector()).normalize();
        } else {
            // Otherwise dash in looking direction
            direction = player.getLocation().getDirection();
        }
        
        // Apply dash velocity
        direction.multiply(DASH_DISTANCE);
        direction.setY(0.5); // Add slight upward momentum
        player.setVelocity(direction);
        
        // Consume a charge
        charges--;
        dashCharges.put(playerId, charges);
        lastDashTime.put(playerId, System.currentTimeMillis());
        player.sendMessage(Component.text("[DEBUG] Dash charges after dash: " + charges).color(NamedTextColor.YELLOW));
        
        // Enhanced visual and sound effects
        player.playSound(player.getLocation(), Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 1.0f, 1.0f);
        
        // Create enhanced multi-layered particle effects
        createDashParticleEffect(player);
        
        // Broadcast updated dash charges
        broadcastDashCharges(player);
        
        // Only apply cooldown when all charges are used up
        if (charges == 0) {
            player.sendMessage(Component.text("[DEBUG] All dash charges used. Cooldown started!").color(NamedTextColor.RED));
            dashCooldownEnd.put(playerId, now + DASH_COOLDOWN_TIME);
            // Schedule reset of dash charges after cooldown
            if (dashResetTasks.containsKey(playerId)) {
                dashResetTasks.get(playerId).cancel();
            }
            BukkitTask resetTask = new BukkitRunnable() {
                @Override
                public void run() {
                    if (player.isOnline() && hasEffect(player)) {
                        dashCharges.put(playerId, MAX_DASH_CHARGES);
                        player.sendMessage(Component.text("🔄 Dash charges reset to maximum!")
                                .color(NamedTextColor.GREEN));
                        broadcastDashCharges(player);
                    }
                    dashResetTasks.remove(playerId);
                }
            }.runTaskLater(plugin, DASH_COOLDOWN_TIME / 50); // 20s cooldown
            dashResetTasks.put(playerId, resetTask);
        }
    }

    // Helper method to broadcast dash charges to player
    private void broadcastDashCharges(Player player) {
        int charges = dashCharges.getOrDefault(player.getUniqueId(), 0);
        String chargeDisplay = "";
        for (int i = 0; i < MAX_DASH_CHARGES; i++) {
            if (i < charges) {
                chargeDisplay += "⚡"; // Filled charge
            } else {
                chargeDisplay += "⭘"; // Empty charge
            }
        }
        
        // Send as action bar message (appears above hotbar)
        player.sendActionBar(Component.text("Speed Dash: " + chargeDisplay + " (" + charges + "/" + MAX_DASH_CHARGES + ")")
                .color(NamedTextColor.AQUA));
        
        // Also send as chat message for visibility
        player.sendMessage(Component.text("Speed Dash Charges: " + chargeDisplay + " (" + charges + "/" + MAX_DASH_CHARGES + ")")
                .color(NamedTextColor.AQUA));
    }

    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        
        // Update last hit time
        lastHitTime.put(attackerId, System.currentTimeMillis());
        
        // Increase speed level (up to Speed V)
        int currentLevel = speedLevel.getOrDefault(attackerId, 0);
        if (currentLevel < 4) {
            currentLevel++;
            speedLevel.put(attackerId, currentLevel);
            
            // Apply new speed level
            safeRemoveAndAddSpeed(attacker);
            
            // Visual feedback
            attacker.sendMessage(Component.text("⚡ Speed increased to level " + (currentLevel + 1))
                    .color(NamedTextColor.AQUA));
        }
        
        // Halve enemy invincibility frames
        if (event.getEntity() instanceof Player) {
            ((Player) event.getEntity()).setNoDamageTicks(10); // Half of default 20 ticks
        }
    }

    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // No special defense handling needed
    }

    @EventHandler
    public void onBowShoot(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!hasEffect(player)) return;
        
        // Increase arrow velocity by 50%
        event.getProjectile().setVelocity(event.getProjectile().getVelocity().multiply(BOW_CHARGE_MULTIPLIER));
        
        // Visual feedback
        player.getWorld().spawnParticle(Particle.CLOUD,
            player.getLocation().add(0, 1, 0),
            10, 0.2, 0.2, 0.2, 0.1);
    }

    private void startSpeedResetTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                long currentTime = System.currentTimeMillis();
                
                // Check all players with speed effect
                for (Map.Entry<UUID, Long> entry : new HashMap<>(lastHitTime).entrySet()) {
                    UUID playerId = entry.getKey();
                    long lastHit = entry.getValue();
                    
                    // Reset speed if no activity for 1 second
                    if (currentTime - lastHit >= SPEED_RESET_DELAY) {
                        Player player = plugin.getServer().getPlayer(playerId);
                        if (player != null && player.isOnline() && hasEffect(player)) {
                            // Reset to Speed I
                            speedLevel.put(playerId, 0);
                            safeRemoveAndAddSpeed(player);
                            
                            // Remove last hit time
                            lastHitTime.remove(playerId);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 5L); // Check every 5 ticks
    }

    private boolean hasEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.SPEED && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.SPEED && data.isSecondaryEnabled());
    }
    
    // Add this new method for enhanced dash particle effects
    private void createDashParticleEffect(Player player) {
        Location startLoc = player.getLocation().clone();
        
        // Create multiple layers of particles for a more dramatic effect
        for (int layer = 0; layer < 3; layer++) {
            double layerHeight = layer * 0.3;
            
            // Create circular burst at start position
            for (int i = 0; i < 36; i++) {
                double angle = 2 * Math.PI * i / 36;
                double radius = 0.7 + (layer * 0.2);
                double x = startLoc.getX() + radius * Math.cos(angle);
                double z = startLoc.getZ() + radius * Math.sin(angle);
                Location particleLoc = new Location(startLoc.getWorld(), x, startLoc.getY() + layerHeight, z);
                
                // Main cloud particles
                startLoc.getWorld().spawnParticle(Particle.CLOUD, particleLoc, 1, 0.05, 0.05, 0.05, 0.01);
                
                // Add some soul flame particles for effect
                if (i % 4 == 0) {
                    startLoc.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, particleLoc, 1, 0.05, 0.05, 0.05, 0.01);
                }
                
                // Add occasional crit particles for a sparkle effect
                if (i % 9 == 0 && layer == 1) {
                    startLoc.getWorld().spawnParticle(Particle.CRIT, particleLoc, 2, 0.1, 0.1, 0.1, 0.05);
                }
            }
        }
    }

    private void safeRemoveAndAddSpeed(Player player) {
        PotionEffect effect = player.getPotionEffect(PotionEffectType.SPEED);
        if (effect == null || effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.SPEED);
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0));
        }
    }
}