package com.infusesmp.listeners;

import com.infusesmp.potion.InfusePotion;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;

public class PotionProtectionListener implements Listener {
    @EventHandler
    public void onEntityPickupItem(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player) return;
        if (InfusePotion.isInfusePotion(event.getItem().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onItemDespawn(ItemDespawnEvent event) {
        if (InfusePotion.isInfusePotion(event.getEntity().getItemStack())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onItemBurn(EntityDamageEvent event) {
        if (event.getEntity() instanceof Item item) {
            if (InfusePotion.isInfusePotion(item.getItemStack()) &&
                (event.getCause() == EntityDamageEvent.DamageCause.FIRE ||
                 event.getCause() == EntityDamageEvent.DamageCause.FIRE_TICK ||
                 event.getCause() == EntityDamageEvent.DamageCause.LAVA ||
                 event.getCause() == EntityDamageEvent.DamageCause.CONTACT)) {
                event.setCancelled(true);
            }
        }
    }
} 