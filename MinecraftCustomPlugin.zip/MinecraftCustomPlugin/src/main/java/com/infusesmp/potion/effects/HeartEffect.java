package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.Sound;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.scheduler.BukkitRunnable;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.*;

public class HeartEffect implements PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Integer> hitCounter = new HashMap<>();
    private final Map<UUID, BukkitRunnable> bonusHealthTasks = new HashMap<>();
    private final Map<UUID, Double> originalMaxHealth = new HashMap<>();
    private static final int HITS_FOR_HEALTH_CHECK = 10;
    private static final double BONUS_HEALTH = 10.0; // 5 hearts
    private static final double SPARK_BONUS_HEALTH = 20.0; // 10 hearts
    private static final long BONUS_HEALTH_DURATION = 30 * 1000; // 30 seconds in milliseconds
    // Add a map to track players with active heart effect
    private final Set<UUID> playersWithHeartEffect = new HashSet<>();
    // Add a map to track players with active spark effect
    private final Set<UUID> playersWithSparkEffect = new HashSet<>();

    public HeartEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @Override
    public void activatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        hitCounter.put(playerId, 0);

        // Check if player already has heart effect active
        if (playersWithHeartEffect.contains(playerId)) {
            // Player already has heart effect, don't add more hearts
            return;
        }

        // Store original max health
        AttributeInstance maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealth != null) {
            // Reset to base health first to prevent stacking when rejoining
            // This ensures we always start from the player's base health
            if (originalMaxHealth.containsKey(playerId)) {
                maxHealth.setBaseValue(originalMaxHealth.get(playerId));
            }
            
            // Store the current max health
            originalMaxHealth.put(playerId, maxHealth.getBaseValue());
            
            // Add bonus health
            maxHealth.setBaseValue(maxHealth.getBaseValue() + BONUS_HEALTH);
            player.setHealth(Math.min(player.getHealth() + BONUS_HEALTH, maxHealth.getValue()));
            
            // Mark player as having heart effect
            playersWithHeartEffect.add(playerId);
            
            // Schedule health reduction
            BukkitRunnable task = new BukkitRunnable() {
                @Override
                public void run() {
                    if (!player.isOnline()) {
                        cancel();
                        return;
                    }
                    
                    // Only restore original max health if spark effect is not active
                    if (!playersWithSparkEffect.contains(playerId)) {
                        // Restore original max health
                        maxHealth.setBaseValue(originalMaxHealth.get(playerId));
                        player.setHealth(Math.min(player.getHealth(), maxHealth.getValue()));
                        
                        // Cleanup
                        originalMaxHealth.remove(playerId);
                    } else {
                        // If spark effect is active, just remove the passive bonus
                        maxHealth.setBaseValue(maxHealth.getBaseValue() - BONUS_HEALTH);
                        player.setHealth(Math.min(player.getHealth(), maxHealth.getValue()));
                    }
                    
                    bonusHealthTasks.remove(playerId);
                    playersWithHeartEffect.remove(playerId);
                }
            };
            
            // Cancel existing task if present
            BukkitRunnable existingTask = bonusHealthTasks.get(playerId);
            if (existingTask != null) {
                existingTask.cancel();
            }
            
            task.runTaskLater(plugin, 600L); // 30 seconds
            bonusHealthTasks.put(playerId, task);
        }
    }

    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        hitCounter.remove(playerId);
        
        // Cancel bonus health task
        BukkitRunnable task = bonusHealthTasks.remove(playerId);
        if (task != null) {
            task.cancel();
        }
        
        // Restore original max health immediately
        Double original = originalMaxHealth.remove(playerId);
        if (original != null) {
            AttributeInstance maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
            if (maxHealth != null) {
                // Immediately set back to original value regardless of spark status
                maxHealth.setBaseValue(original);
                player.setHealth(Math.min(player.getHealth(), maxHealth.getValue()));
            }
        }
        
        // Remove player from active effect sets
        playersWithHeartEffect.remove(playerId);
        playersWithSparkEffect.remove(playerId);
    }

    @Override
    public void useSpark(Player player) {
        if (!hasHeartEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Heart effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        AttributeInstance maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealth == null) return;

        // Store original max health if not already stored
        if (!originalMaxHealth.containsKey(playerId)) {
            originalMaxHealth.put(playerId, maxHealth.getBaseValue());
        }

        // Calculate the correct health to add
        double currentMaxHealth = maxHealth.getBaseValue();
        double targetMaxHealth = originalMaxHealth.get(playerId) + BONUS_HEALTH + SPARK_BONUS_HEALTH;
        
        // If player already has spark effect, don't add more hearts
        if (playersWithSparkEffect.contains(playerId)) {
            // Just refresh the duration
            BukkitRunnable existingTask = bonusHealthTasks.get(playerId);
            if (existingTask != null) {
                existingTask.cancel();
            }
        } else {
            // Add spark bonus health (only the difference needed)
            maxHealth.setBaseValue(targetMaxHealth);
            // Mark player as having spark effect
            playersWithSparkEffect.add(playerId);
        }
        
        // Full heal
        player.setHealth(maxHealth.getValue());
        
        // Visual and sound effects
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.sendMessage(Component.text("❤️‍🔥 Received 10 bonus hearts!")
                .color(NamedTextColor.RED));

        // Schedule health reduction
        BukkitRunnable task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }

                // Remove spark bonus health
                maxHealth.setBaseValue(maxHealth.getBaseValue() - SPARK_BONUS_HEALTH);
                player.setHealth(Math.min(player.getHealth(), maxHealth.getValue()));
                
                player.sendMessage(Component.text("❤️‍🔥 Bonus hearts have worn off!")
                        .color(NamedTextColor.RED));
                
                // Remove from spark effect set
                playersWithSparkEffect.remove(playerId);
                
                // If passive effect is no longer active, clean up completely
                if (!playersWithHeartEffect.contains(playerId)) {
                    originalMaxHealth.remove(playerId);
                }
                
                bonusHealthTasks.remove(playerId);
            }
        };

        // Cancel existing task if present
        BukkitRunnable existingTask = bonusHealthTasks.get(playerId);
        if (existingTask != null) {
            existingTask.cancel();
        }

        task.runTaskLater(plugin, 600L); // 30 seconds
        bonusHealthTasks.put(playerId, task);
    }

    // Fix the onPotionDrain method - it had a logical error
    @EventHandler
    public void onPotionDrain(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        UUID playerId = player.getUniqueId();
        
        // Check if we're tracking this player but they no longer have the effect
        if ((playersWithHeartEffect.contains(playerId) || playersWithSparkEffect.contains(playerId)) 
                && !hasHeartEffect(player)) {
            // Force deactivate to ensure hearts are removed
            deactivatePassive(player);
        }
    }

    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        
        // Increment hit counter
        int hits = hitCounter.getOrDefault(attackerId, 0) + 1;
        
        if (hits >= HITS_FOR_HEALTH_CHECK && event.getEntity() instanceof Player target) {
            hits = 0;
            // Show target's health
            double health = target.getHealth();
            double maxHealth = target.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
            double absorption = target.getAbsorptionAmount();
            
            attacker.sendMessage(Component.text("❤️‍🔥 Target's Health: " + String.format("%.1f", health) + "/" + String.format("%.1f", maxHealth))
                    .color(NamedTextColor.RED));
            if (absorption > 0) {
                attacker.sendMessage(Component.text("⭐ Target's Absorption: " + String.format("%.1f", absorption))
                        .color(NamedTextColor.GOLD));
            }
        }
        hitCounter.put(attackerId, hits);
    }

    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // No special defense handling needed
    }

    @EventHandler
    public void onFoodConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        if (!hasHeartEffect(player)) return;

        Material foodType = event.getItem().getType();
        
        // Handle golden apple absorption
        if (foodType == Material.GOLDEN_APPLE) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    player.setAbsorptionAmount(player.getAbsorptionAmount() + 20.0); // +10 absorption hearts
                }
            }.runTaskLater(plugin, 1L);
        } else if (foodType.isEdible()) {
            // Add absorption for regular food
            new BukkitRunnable() {
                @Override
                public void run() {
                    player.setAbsorptionAmount(player.getAbsorptionAmount() + 2.0); // +1 absorption heart
                }
            }.runTaskLater(plugin, 1L);
        }
    }

    private boolean hasHeartEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.HEART && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.HEART && data.isSecondaryEnabled());
    }
}
