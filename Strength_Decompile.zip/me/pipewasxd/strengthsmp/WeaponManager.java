package me.pipewasxd.strengthsmp;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public record WeaponManager(StrengthSMP plugin) {
   public WeaponType getPlayerWeapon(Player player) {
      String weaponName = this.plugin.getConfig().getString("weapons." + String.valueOf(player.getUniqueId()));
      WeaponType weapon = WeaponType.fromString(weaponName);
      if (weapon == null) {
         weapon = WeaponType.random();
         this.setPlayerWeapon(player, weapon);
         String var10001 = String.valueOf(ChatColor.DARK_RED);
         player.sendMessage(var10001 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ʜᴀᴠᴇ ʙᴇᴇɴ ᴀssɪɢɴᴇᴅ ᴛʜᴇ " + String.valueOf(ChatColor.WHITE) + String.valueOf(ChatColor.BOLD) + weapon.getDisplayName() + String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + " ᴡᴇᴀᴘᴏɴ!");
      }

      return weapon;
   }

   public void setPlayerWeapon(Player player, WeaponType weapon) {
      this.plugin.getConfig().set("weapons." + String.valueOf(player.getUniqueId()), weapon.name());
      this.plugin.saveConfig();
   }
}
