package com.infusesmp.hud;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class InfuseHUD {
    
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Long> lastHUDUpdate;
    private final Map<UUID, BossBar> bossBars = new HashMap<>();
    
    // Unicode characters for potion icons (using custom texture pack)
    private static final String THUNDER_ICON = "⚡";
    private static final String STRENGTH_ICON = "⚔";
    private static final String REGEN_ICON = "❤";
    private static final String FEATHER_ICON = "☁";
    private static final String HEART_ICON = "♥";
    private static final String FROST_ICON = "❄";
    private static final String EMERALD_ICON = "⬥";
    private static final String OCEAN_ICON = "≈";
    private static final String FIRE_ICON = "🔥";
    private static final String SPEED_ICON = "⚡";
    private static final String HASTE_ICON = "⛏";
    private static final String INVIS_ICON = "👻";
    
    public InfuseHUD(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.lastHUDUpdate = new HashMap<>();
    }
    
    public void updateHUD(Player player) {
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        UUID uuid = player.getUniqueId();
        if (!data.hasAnyPotion()) {
            // Remove boss bar if present
            BossBar bar = bossBars.remove(uuid);
            if (bar != null) bar.removeAll();
            return;
        }
        Component hudMessage = buildHUDMessage(player, data);
        // Create or update boss bar
        BossBar bar = bossBars.computeIfAbsent(uuid, id -> {
            BossBar newBar = Bukkit.createBossBar("", BarColor.BLUE, BarStyle.SEGMENTED_10);
            newBar.addPlayer(player);
            return newBar;
        });
        String legacyTitle = LegacyComponentSerializer.legacySection().serialize(hudMessage);
        bar.setTitle(legacyTitle);
        bar.setColor(BarColor.BLUE);
        bar.setStyle(BarStyle.SEGMENTED_10);
        bar.setProgress(1.0); // Always full for HUD
        if (!bar.getPlayers().contains(player)) bar.addPlayer(player);
        lastHUDUpdate.put(uuid, System.currentTimeMillis());
    }
    
    private Component buildHUDMessage(Player player, PlayerData data) {
        // Primary potion (left side)
        Component primaryComponent;
        PotionType primaryPotion = data.getPrimaryPotion();
        if (primaryPotion != null) {
            primaryComponent = buildPotionDisplay(player, primaryPotion, true, data.isPrimaryEnabled());
        } else {
            primaryComponent = Component.text("◯")
                    .color(NamedTextColor.DARK_GRAY)
                    .decoration(TextDecoration.ITALIC, false);
        }
        
        // Separator
        Component separator = Component.text(" ⚔ ")
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false);
        
        // Secondary potion (right side)
        Component secondaryComponent;
        PotionType secondaryPotion = data.getSecondaryPotion();
        if (secondaryPotion != null) {
            secondaryComponent = buildPotionDisplay(player, secondaryPotion, false, data.isSecondaryEnabled());
        } else {
            secondaryComponent = Component.text("◯")
                    .color(NamedTextColor.DARK_GRAY)
                    .decoration(TextDecoration.ITALIC, false);
        }
        
        // Build final message
        return Component.empty()
                .append(primaryComponent)
                .append(separator)
                .append(secondaryComponent);
    }
    
    private Component buildPotionDisplay(Player player, PotionType potionType, boolean isPrimary, boolean isEnabled) {
        String icon = getPotionIcon(potionType);
        String shortName = getPotionShortName(potionType);
        TextColor color = getPotionColor(potionType);
        boolean isActive = plugin.getDataManager().getPlayerData(player.getUniqueId()).getActiveSlot() == potionType;
        Component base = Component.text(icon + " " + shortName)
                .color(isEnabled ? color : NamedTextColor.DARK_GRAY)
                .decoration(TextDecoration.ITALIC, false);
        if (isActive) {
            base = base.decorate(TextDecoration.BOLD).color(NamedTextColor.GOLD);
        }
        Component activeDot = isActive
                ? Component.text(" ●").color(NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false)
                : Component.empty();
        long cooldown = plugin.getCooldownManager().getRemainingCooldown(player.getUniqueId(), potionType);
        Component cooldownComponent = cooldown > 0 
                ? Component.text(" " + (cooldown / 1000) + "s")
                        .color(NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false)
                : Component.empty();
        Component disabledComponent = !isEnabled
                ? Component.text(" ✕")
                        .color(NamedTextColor.RED)
                        .decoration(TextDecoration.ITALIC, false)
                : Component.empty();
        return Component.empty()
                .append(base)
                .append(activeDot)
                .append(cooldownComponent)
                .append(disabledComponent);
    }
    
    private String getPotionIcon(PotionType type) {
        return switch (type) {
            case THUNDER -> THUNDER_ICON;
            case STRENGTH -> STRENGTH_ICON;
            case REGEN -> REGEN_ICON;
            case FEATHER -> FEATHER_ICON;
            case HEART -> HEART_ICON;
            case FROST -> FROST_ICON;
            case EMERALD -> EMERALD_ICON;
            case OCEAN -> OCEAN_ICON;
            case FIRE -> FIRE_ICON;
            case SPEED -> SPEED_ICON;
            case HASTE -> HASTE_ICON;
            case INVIS -> INVIS_ICON;
        };
    }
    
    private String getPotionShortName(PotionType type) {
        return switch (type) {
            case THUNDER -> "Thunder";
            case STRENGTH -> "Strength";
            case REGEN -> "Regen";
            case FEATHER -> "Feather";
            case HEART -> "Heart";
            case FROST -> "Frost";
            case EMERALD -> "Emerald";
            case OCEAN -> "Ocean";
            case FIRE -> "Fire";
            case SPEED -> "Speed";
            case HASTE -> "Haste";
            case INVIS -> "Invis";
        };
    }
    
    private TextColor getPotionColor(PotionType type) {
        return switch (type) {
            case THUNDER -> TextColor.color(255, 255, 0);  // Yellow
            case STRENGTH -> TextColor.color(255, 0, 0);   // Red
            case REGEN -> TextColor.color(255, 192, 203);  // Pink
            case FEATHER -> TextColor.color(173, 216, 230); // Light Blue
            case HEART -> TextColor.color(255, 105, 180);  // Hot Pink
            case FROST -> TextColor.color(135, 206, 235);  // Sky Blue
            case EMERALD -> TextColor.color(0, 255, 0);    // Green
            case OCEAN -> TextColor.color(0, 191, 255);    // Deep Sky Blue
            case FIRE -> TextColor.color(255, 69, 0);      // Orange Red
            case SPEED -> TextColor.color(255, 215, 0);    // Gold
            case HASTE -> TextColor.color(218, 165, 32);   // Golden Rod
            case INVIS -> TextColor.color(128, 128, 128);  // Gray
        };
    }
    
    public void startHUDUpdater() {
        new BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                for (Map.Entry<UUID, Long> entry : lastHUDUpdate.entrySet()) {
                    Player player = plugin.getServer().getPlayer(entry.getKey());
                    if (player != null && player.isOnline()) {
                        updateHUD(player);
                    } else {
                        // Remove boss bar if player is offline
                        BossBar bar = bossBars.remove(entry.getKey());
                        if (bar != null) bar.removeAll();
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 20L); // Run every second
    }
}