package com.infusesmp.managers;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CooldownManager {
    
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Map<PotionType, Long>> cooldowns;
    private final Map<PotionType, Long> cooldownDurations;
    private File cooldownFile;
    private FileConfiguration cooldownConfig;
    
    public CooldownManager(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.cooldowns = new HashMap<>();
        this.cooldownDurations = new HashMap<>();
        
        initializeCooldownDurations();
        loadCooldowns();
    }
    
    private void initializeCooldownDurations() {
        // Cooldown durations in milliseconds
        cooldownDurations.put(PotionType.REGEN, 60000L); // 60s
        cooldownDurations.put(PotionType.FEATHER, 45000L); // 45s
        cooldownDurations.put(PotionType.THUNDER, 90000L); // 90s
        cooldownDurations.put(PotionType.STRENGTH, 60000L); // 60s
        cooldownDurations.put(PotionType.HEART, 120000L); // 120s
        cooldownDurations.put(PotionType.FROST, 90000L); // 90s
        cooldownDurations.put(PotionType.EMERALD, 60000L); // 60s
        cooldownDurations.put(PotionType.OCEAN, 90000L); // 90s
        cooldownDurations.put(PotionType.FIRE, 90000L); // 90s
        cooldownDurations.put(PotionType.SPEED, 20000L); // 20s
        cooldownDurations.put(PotionType.HASTE, 60000L); // 60s
        cooldownDurations.put(PotionType.INVIS, 90000L); // 90s
    }
    
    private void loadCooldowns() {
        cooldownFile = new File(plugin.getDataFolder(), "cooldowns.yml");
        if (!cooldownFile.exists()) {
            try {
                // Create plugin folder if it doesn't exist
                if (!plugin.getDataFolder().exists()) {
                    plugin.getDataFolder().mkdirs();
                }
                // Create empty cooldowns file
                cooldownFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().warning("Could not create cooldowns.yml: " + e.getMessage());
                return;
            }
        }
        
        cooldownConfig = YamlConfiguration.loadConfiguration(cooldownFile);
        
        // Load cooldowns from file
        for (String playerIdStr : cooldownConfig.getKeys(false)) {
            try {
                UUID playerId = UUID.fromString(playerIdStr);
                Map<PotionType, Long> playerCooldowns = new HashMap<>();
                
                ConfigurationSection cooldownSection = cooldownConfig.getConfigurationSection(playerIdStr);
                if (cooldownSection != null) {
                    for (String potionTypeStr : cooldownSection.getKeys(false)) {
                        try {
                            PotionType potionType = PotionType.valueOf(potionTypeStr);
                            long endTime = cooldownSection.getLong(potionTypeStr);
                            
                            // Only load if cooldown hasn't expired
                            if (System.currentTimeMillis() < endTime) {
                                playerCooldowns.put(potionType, endTime);
                            }
                        } catch (IllegalArgumentException ignored) {
                            // Invalid potion type, skip
                        }
                    }
                }
                
                if (!playerCooldowns.isEmpty()) {
                    cooldowns.put(playerId, playerCooldowns);
                }
            } catch (IllegalArgumentException ignored) {
                // Invalid UUID, skip
            }
        }
    }
    
    private void saveCooldowns() {
        if (cooldownConfig == null || cooldownFile == null) return;
        
        // Clear current config
        for (String key : cooldownConfig.getKeys(false)) {
            cooldownConfig.set(key, null);
        }
        
        // Save current cooldowns
        for (Map.Entry<UUID, Map<PotionType, Long>> entry : cooldowns.entrySet()) {
            String playerIdStr = entry.getKey().toString();
            Map<PotionType, Long> playerCooldowns = entry.getValue();
            
            for (Map.Entry<PotionType, Long> cooldownEntry : playerCooldowns.entrySet()) {
                String path = playerIdStr + "." + cooldownEntry.getKey().name();
                cooldownConfig.set(path, cooldownEntry.getValue());
            }
        }
        
        try {
            cooldownConfig.save(cooldownFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save cooldowns.yml: " + e.getMessage());
        }
    }
    
    public void setCooldown(UUID playerId, PotionType potionType) {
        long duration = cooldownDurations.getOrDefault(potionType, 60000L);
        long endTime = System.currentTimeMillis() + duration;
        
        cooldowns.computeIfAbsent(playerId, k -> new HashMap<>()).put(potionType, endTime);
        saveCooldowns();
    }
    
    public void resetCooldown(UUID playerId, PotionType potionType) {
        Map<PotionType, Long> playerCooldowns = cooldowns.get(playerId);
        if (playerCooldowns != null) {
            playerCooldowns.remove(potionType);
            if (playerCooldowns.isEmpty()) {
                cooldowns.remove(playerId);
            }
            saveCooldowns();
        }
    }
    
    public boolean isOnCooldown(UUID playerId, PotionType potionType) {
        Map<PotionType, Long> playerCooldowns = cooldowns.get(playerId);
        if (playerCooldowns == null) {
            return false;
        }
        
        Long endTime = playerCooldowns.get(potionType);
        if (endTime == null) {
            return false;
        }
        
        if (System.currentTimeMillis() >= endTime) {
            playerCooldowns.remove(potionType);
            if (playerCooldowns.isEmpty()) {
                cooldowns.remove(playerId);
            }
            saveCooldowns();
            return false;
        }
        
        return true;
    }
    
    public long getRemainingCooldown(UUID playerId, PotionType potionType) {
        Map<PotionType, Long> playerCooldowns = cooldowns.get(playerId);
        if (playerCooldowns == null) {
            return 0;
        }
        
        Long endTime = playerCooldowns.get(potionType);
        if (endTime == null) {
            return 0;
        }
        
        long remaining = endTime - System.currentTimeMillis();
        if (remaining <= 0) {
            playerCooldowns.remove(potionType);
            if (playerCooldowns.isEmpty()) {
                cooldowns.remove(playerId);
            }
            saveCooldowns();
            return 0;
        }
        
        return remaining;
    }
    
    public void clearPlayerCooldowns(UUID playerId) {
        cooldowns.remove(playerId);
        saveCooldowns();
    }
}
