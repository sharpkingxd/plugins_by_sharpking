package me.pipewasxd.strengthsmp;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;

public class BowUltimate implements Listener {
   private final StrengthSMP plugin;
   private final WeaponManager weaponManager;
   private final StrengthManager strengthManager;
   private final Map<UUID, Integer> shotCount = new HashMap();
   private final Map<UUID, Integer> ultimateShotCount = new HashMap();
   private final Map<UUID, Long> ultimateCooldown = new HashMap();
   private final Map<UUID, BukkitRunnable> cooldownTasks = new HashMap();

   public BowUltimate(StrengthSMP plugin, WeaponManager weaponManager, StrengthManager strengthManager) {
      this.plugin = plugin;
      this.weaponManager = weaponManager;
      this.strengthManager = strengthManager;
   }

   public boolean onAbilityCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (player.getInventory().getItemInMainHand().getType() != Material.BOW) {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#808080:#A9A9A9>ʏᴏᴜ ᴍᴜsᴛ ʜᴏʟᴅ ᴀ ʙᴏᴡ ᴛᴏ ᴜsᴇ ᴛʜɪs!</gradient></bold>"));
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6F, 1.2F);
            return true;
         } else if (this.weaponManager.getPlayerWeapon(player) != WeaponType.BOW) {
            return true;
         } else if (!this.strengthManager.isAtMaxStrength(player)) {
            return true;
         } else {
            UUID uuid = player.getUniqueId();
            if (this.isOnCooldown(player)) {
               long remaining = ((Long)this.ultimateCooldown.get(uuid) - System.currentTimeMillis()) / 1000L;
               return true;
            } else {
               return true;
            }
         }
      } else {
         sender.sendMessage("Only players can use this command.");
         return true;
      }
   }

   @EventHandler
   public void onBowShoot(EntityShootBowEvent event) {
      LivingEntity var3 = event.getEntity();
      if (var3 instanceof Player shooter) {
         Entity var4 = event.getProjectile();
         if (var4 instanceof final Arrow arrow) {
            if (event.getBow() != null && event.getBow().getType() == Material.BOW) {
               if (this.weaponManager.getPlayerWeapon(shooter) == WeaponType.BOW) {
                  if (this.strengthManager.isAtMaxStrength(shooter)) {
                     UUID uuid = shooter.getUniqueId();
                     int passiveShots = (Integer)this.shotCount.getOrDefault(uuid, 0) + 1;
                     this.shotCount.put(uuid, passiveShots);
                     if (passiveShots % 3 == 0) {
                        arrow.setMetadata("bow_passive_2x", new FixedMetadataValue(this.plugin, true));
                        arrow.setGlowing(true);
                        shooter.playSound(shooter.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.5F);
                        (new BukkitRunnable() {
                           public void run() {
                              if (!arrow.isDead() && arrow.isValid()) {
                                 Particle.DustOptions redDust = new Particle.DustOptions(Color.fromRGB(255, 0, 0), 1.0F);
                                 arrow.getWorld().spawnParticle(Particle.DUST, arrow.getLocation(), 2, 0.05, 0.05, 0.05, redDust);
                                 arrow.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, arrow.getLocation(), 1, 0.05, 0.05, 0.05, 0.01);
                              } else {
                                 this.cancel();
                              }
                           }
                        }).runTaskTimer(this.plugin, 0L, 1L);
                     }

                     if (!this.isOnCooldown(shooter)) {
                        int ultimateShots = (Integer)this.ultimateShotCount.getOrDefault(uuid, 0) + 1;
                        this.ultimateShotCount.put(uuid, ultimateShots);
                        if (ultimateShots >= 10) {
                           arrow.setMetadata("bow_ultimate_laser", new FixedMetadataValue(this.plugin, true));
                           arrow.setGlowing(true);
                           arrow.setFireTicks(100);
                           this.ultimateShotCount.put(uuid, 0);
                           shooter.playSound(shooter.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0F, 1.2F);
                           shooter.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#8B0000:#B22222>ᴜʟᴛɪᴍᴀᴛᴇ ᴀᴄᴛɪᴠᴀᴛᴇᴅ</gradient></bold>"));
                           shooter.playSound(shooter.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1.0F, 0.8F);
                           (new BukkitRunnable() {
                              public void run() {
                                 if (!arrow.isDead() && arrow.isValid()) {
                                    Location arrowLoc = arrow.getLocation();
                                    Particle.DustOptions blueDust = new Particle.DustOptions(Color.fromRGB(0, 100, 255), 1.5F);
                                    arrow.getWorld().spawnParticle(Particle.DUST, arrowLoc, 5, 0.05, 0.05, 0.05, blueDust);
                                    arrow.getWorld().spawnParticle(Particle.SONIC_BOOM, arrowLoc, 1);
                                 } else {
                                    this.cancel();
                                 }
                              }
                           }).runTaskTimer(this.plugin, 0L, 1L);
                        }

                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onArrowHit(ProjectileHitEvent event) {
      Projectile var3 = event.getEntity();
      if (var3 instanceof Arrow arrow) {
         ProjectileSource var4 = arrow.getShooter();
         if (var4 instanceof Player shooter) {
            if (this.weaponManager.getPlayerWeapon(shooter) == WeaponType.BOW) {
               if (arrow.hasMetadata("bow_ultimate_laser")) {
                  Location hitLoc = arrow.getLocation();
                  Particle.DustOptions blueDust = new Particle.DustOptions(Color.fromRGB(0, 100, 255), 2.0F);
                  hitLoc.getWorld().spawnParticle(Particle.DUST, hitLoc, 30, 0.3, 0.3, 0.3, blueDust);
                  hitLoc.getWorld().spawnParticle(Particle.SONIC_BOOM, hitLoc, 3);
                  hitLoc.getWorld().playSound(hitLoc, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0F, 1.0F);
                  this.startCooldown(shooter);
               }

            }
         }
      }
   }

   @EventHandler
   public void onArrowDamage(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Arrow arrow) {
         ProjectileSource var4 = arrow.getShooter();
         if (var4 instanceof Player shooter) {
            Entity var5 = event.getEntity();
            if (var5 instanceof LivingEntity target) {
               if (this.weaponManager.getPlayerWeapon(shooter) == WeaponType.BOW) {
                  if (arrow.hasMetadata("bow_passive_2x")) {
                     event.setDamage(event.getDamage() * (double)2.0F);
                  }

                  if (arrow.hasMetadata("bow_ultimate_laser")) {
                     event.setDamage(event.getDamage() * (double)2.5F);
                  }

               }
            }
         }
      }
   }

   private void startCooldown(final Player player) {
      final UUID uuid = player.getUniqueId();
      this.ultimateCooldown.put(uuid, System.currentTimeMillis() + 60000L);
      player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#A9A9A9:#D3D3D3>ᴏɴ ᴄᴏᴏʟᴅᴏᴡɴ</gradient></bold>"));
      player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5F, 1.0F);
      BukkitRunnable cooldownTask = new BukkitRunnable() {
         public void run() {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#006400:#008000>ᴜʟᴛɪᴍᴀᴛᴇ ʀᴇᴀᴅʏ</gradient></bold>"));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
            BowUltimate.this.cooldownTasks.remove(uuid);
         }
      };
      cooldownTask.runTaskLater(this.plugin, 1200L);
      this.cooldownTasks.put(uuid, cooldownTask);
   }

   public boolean isOnCooldown(Player player) {
      Long cooldownEnd = (Long)this.ultimateCooldown.get(player.getUniqueId());
      return cooldownEnd != null && System.currentTimeMillis() < cooldownEnd;
   }
}
