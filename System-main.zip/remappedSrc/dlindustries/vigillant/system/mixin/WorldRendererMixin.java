package dlindustries.vigillant.system.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dlindustries.vigillant.system.event.EventManager;
import dlindustries.vigillant.system.event.events.GameRenderListener;
import dlindustries.vigillant.system.utils.RenderTickCounterHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderWorld(CallbackInfo ci,
                               @Local RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null || client.player == null) return;
        if (client.currentScreen != null) return;

        float tickDelta = RenderTickCounterHelper.getTickDelta(tickCounter);

        MatrixStack matrices = new MatrixStack();

        EventManager.fire(new GameRenderListener.GameRenderEvent(matrices, tickDelta));
    }
}
