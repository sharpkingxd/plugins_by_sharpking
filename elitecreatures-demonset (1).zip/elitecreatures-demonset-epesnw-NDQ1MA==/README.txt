Thank you for choosing EliteCreatures for your needs! We're thrilled to have you as a valued customer. This readme file contains some important information to help you get started with our product.

1. **Support and Troubleshooting:**

   If you encounter any issues or have questions about using our product, don't hesitate to reach out to us. Our dedicated support team is here to assist you.

   - Discord Community: Join our Discord community for real-time support, discussions, and updates. You can find us here: [Discord Server](https://discord.gg/JSWupn3YrB)

2. **Product Documentation:**

   To ensure a smooth experience with EliteCreatures, please refer to our comprehensive documentation. It provides detailed instructions on setup, configuration, and advanced usage.

   - Documentation: [Product Documentation](https://docs.charlidev.com/) or (https://docs.stormpixelstudio.com/)

We appreciate your trust in EliteCreatures. If you have any feedback or suggestions for improving our product, please feel free to share them with us.

Thank you once again for choosing EliteCreatures, and we hope you have a fantastic experience!

Best regards,
The EliteCreatures Team
Author('s): CharliDev, Storm Pixel Studio

# 1421GGL4858R29IOZK1IU4U04LUI