/*
 * This file is part of the Meteor Client distribution (https://github.com/meteordevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.AutoReconnect;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.DirectionalLayoutWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static meteordevelopment.meteorclient.MeteorClient.mc;

@Mixin(DisconnectedScreen.class)
public abstract class DisconnectedScreenMixin extends Screen {
    @Shadow
    @Final
    private DirectionalLayoutWidget grid;
    @Unique private ButtonWidget reconnectBtn;
    @Unique private double time = 0;

    protected DisconnectedScreenMixin(Text title) {
        super(title);
    }

    @Inject(method = "init", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/widget/DirectionalLayoutWidget;refreshPositions()V", shift = At.Shift.BEFORE))
    private void addButtons(CallbackInfo ci) {
        // Reconnect buttons hidden to prevent mod exposure
    }

    @Override
    public void tick() {
        try {
            if (Modules.get() == null) return;
            
            AutoReconnect autoReconnect = Modules.get().get(AutoReconnect.class);
            if (autoReconnect == null || !autoReconnect.isActive() || autoReconnect.lastServerConnection == null) return;

            if (time == 0) {
                time = autoReconnect.time.get() * 20;
            }

            if (time <= 0) {
                tryConnecting();
            } else {
                time--;
                if (reconnectBtn != null) reconnectBtn.setMessage(Text.literal(getText()));
            }
        } catch (Exception e) {
            // Silently handle any errors to prevent crashes
        }
    }

    @Unique
    private String getText() {
        try {
            String reconnectText = "Reconnect";
            if (Modules.get() != null && Modules.get().isActive(AutoReconnect.class)) {
                reconnectText += " " + String.format("(%.1f)", time / 20);
            }
            return reconnectText;
        } catch (Exception e) {
            return "Reconnect";
        }
    }

    @Unique
    private void tryConnecting() {
        try {
            var lastServer = Modules.get().get(AutoReconnect.class).lastServerConnection;
            ConnectScreen.connect(new TitleScreen(), mc, lastServer.left(), lastServer.right(), false, null);
        } catch (Exception e) {
            // Silently handle errors
        }
    }
}
