package dlindustries.vigillant.system.module.modules.render;

import java.awt.Color;

import org.joml.Matrix4f;

import dlindustries.vigillant.system.event.events.GameRenderListener;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.RenderUtils;
import dlindustries.vigillant.system.utils.Utils;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class SuperVision extends Module implements GameRenderListener {
    public enum Mode {
        TwoD, ThreeD
    }

    public final ModeSetting<Mode> mode = new ModeSetting<>(EncryptedString.of("Mode"), Mode.ThreeD, Mode.class);
    private final NumberSetting alpha = new NumberSetting(EncryptedString.of("Alpha"), 0, 255, 100, 1);
    private final NumberSetting width = new NumberSetting(EncryptedString.of("Line width"), 1, 10, 1, 1);
    private final BooleanSetting tracers = new BooleanSetting(EncryptedString.of("Tracers"), false)
            .setDescription(EncryptedString.of("Draws a line from your player to the other"));

    public SuperVision() {
        super(EncryptedString.of("Player ESP"),
                EncryptedString.of("Renders players through walls"),
                -1,
                Category.RENDER);
        addSettings(alpha, mode, width, tracers);
    }

    @Override
    public void onEnable() {
        eventManager.add(GameRenderListener.class, this);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        eventManager.remove(GameRenderListener.class, this);
        super.onDisable();
    }

    @Override
    public void onGameRender(GameRenderListener.GameRenderEvent event) {
        if (mc.world == null || mc.player == null || mc.gameRenderer == null) return;

        Camera camera = mc.gameRenderer.getCamera();
        if (camera == null) return;

        MatrixStack matrices = event.matrices;
        Vec3d cameraPos = new Vec3d(camera.getX(), camera.getY(), camera.getZ());

        matrices.push();

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player) continue;
            if (!player.isAlive()) continue;

            if (mode.isMode(Mode.ThreeD)) {
                Vec3d lerpedPos = player.getLerpedPos(event.delta);
                double xPos = lerpedPos.x;
                double yPos = lerpedPos.y;
                double zPos = lerpedPos.z;

                net.minecraft.util.math.Box playerBox = new net.minecraft.util.math.Box(
                        xPos - player.getWidth() / 2,
                        yPos,
                        zPos - player.getWidth() / 2,
                        xPos + player.getWidth() / 2,
                        yPos + player.getHeight(),
                        zPos + player.getWidth() / 2
                );

                Color boxColor = Utils.getMainColor(alpha.getValueInt(), 1).brighter();
                Color lineColor = boxColor;
                RenderUtils.renderBox(matrices, playerBox, boxColor, lineColor, true, true);

                if (tracers.getValue()) {
                    RenderUtils.renderLine(matrices, cameraPos, lerpedPos, Utils.getMainColor(255, 1));
                }
            } else if (mode.isMode(Mode.TwoD)) {
                renderOutline(player, getColor(alpha.getValueInt()), event.matrices, event.delta);

                if (tracers.getValue()) {
                    Vec3d lerpedPos = player.getLerpedPos(event.delta);
                    RenderUtils.renderLine(event.matrices, cameraPos, lerpedPos, Utils.getMainColor(255, 1));
                }
            }
        }

        matrices.pop();
    }

    private void renderOutline(PlayerEntity e, Color color, MatrixStack stack, float tickDelta) {
        float red = color.brighter().getRed() / 255f;
        float green = color.brighter().getGreen() / 255f;
        float blue = color.brighter().getBlue() / 255f;
        float alpha = color.brighter().getAlpha() / 255f;

        Camera c = mc.gameRenderer.getCamera();
        Vec3d camPos = new Vec3d(c.getX(), c.getY(), c.getZ());
        Vec3d start = e.getLerpedPos(tickDelta).subtract(camPos);
        float x = (float) start.x;
        float y = (float) start.y;
        float z = (float) start.z;

        double r = Math.toRadians(-c.getYaw() + 90);
        float sin = (float) (Math.sin(r) * (e.getWidth() / 1.7));
        float cos = (float) (Math.cos(r) * (e.getWidth() / 1.7));
        stack.push();

        Matrix4f matrix = stack.peek().getPositionMatrix();

        BufferBuilder buffer = Tessellator.getInstance().begin(com.mojang.blaze3d.vertex.VertexFormat.DrawMode.DEBUG_LINES,
                VertexFormats.POSITION_COLOR);

        buffer.vertex(matrix, x + sin, y, z + cos).color(red, green, blue, alpha);
        buffer.vertex(matrix, x - sin, y, z - cos).color(red, green, blue, alpha);
        buffer.vertex(matrix, x - sin, y, z - cos).color(red, green, blue, alpha);
        buffer.vertex(matrix, x - sin, y + e.getHeight(), z - cos).color(red, green, blue, alpha);
        buffer.vertex(matrix, x - sin, y + e.getHeight(), z - cos).color(red, green, blue, alpha);
        buffer.vertex(matrix, x + sin, y + e.getHeight(), z + cos).color(red, green, blue, alpha);
        buffer.vertex(matrix, x + sin, y + e.getHeight(), z + cos).color(red, green, blue, alpha);
        buffer.vertex(matrix, x + sin, y, z + cos).color(red, green, blue, alpha);
        buffer.vertex(matrix, x + sin, y, z + cos).color(red, green, blue, alpha);

        try {
            java.lang.reflect.Method shaderMethod = null;
            boolean isStatic = false;

            java.lang.reflect.Method[] allMethods = net.minecraft.client.render.GameRenderer.class.getDeclaredMethods();
            for (java.lang.reflect.Method m : allMethods) {
                if (java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
                    Class<?> returnType = m.getReturnType();
                    String returnTypeName = returnType.getName();
                    if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
                        returnTypeName.startsWith("net.minecraft.client.gl.")) {
                        m.setAccessible(true);
                        shaderMethod = m;
                        isStatic = true;
                        break;
                    }
                }
            }

            if (shaderMethod == null && mc.gameRenderer != null) {
                allMethods = mc.gameRenderer.getClass().getDeclaredMethods();
                for (java.lang.reflect.Method m : allMethods) {
                    if (!java.lang.reflect.Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 0) {
                        Class<?> returnType = m.getReturnType();
                        String returnTypeName = returnType.getName();
                        if (returnTypeName.contains("Shader") || returnTypeName.contains("Program") ||
                            returnTypeName.startsWith("net.minecraft.client.gl.")) {
                            m.setAccessible(true);
                            shaderMethod = m;
                            isStatic = false;
                            break;
                        }
                    }
                }
            }

            if (shaderMethod != null) {
                final java.lang.reflect.Method finalShaderMethod = shaderMethod;
                final boolean finalIsStatic = isStatic;
                final net.minecraft.client.render.GameRenderer finalGameRenderer = mc.gameRenderer;

                java.util.function.Supplier<?> shaderSupplier = () -> {
                    try {
                        return finalIsStatic ? finalShaderMethod.invoke(null) : finalShaderMethod.invoke(finalGameRenderer);
                    } catch (Exception ex) {
                        return null;
                    }
                };

                java.lang.reflect.Method setShaderMethod = com.mojang.blaze3d.systems.RenderSystem.class.getMethod("setShader", java.util.function.Supplier.class);
                setShaderMethod.invoke(null, shaderSupplier);
            }
        } catch (Exception ex) {
        }

        buffer.end();

        stack.pop();
    }

    private Color getColor(int alpha) {
        int red = ClickGUI.red.getValueInt();
        int green = ClickGUI.green.getValueInt();
        int blue = ClickGUI.blue.getValueInt();

        return new Color(red, green, blue, alpha);
    }
}
