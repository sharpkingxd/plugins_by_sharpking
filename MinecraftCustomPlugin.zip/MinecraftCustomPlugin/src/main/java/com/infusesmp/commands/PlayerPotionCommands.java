package com.infusesmp.commands;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class PlayerPotionCommands implements CommandExecutor {
    
    private final InfuseSMPPlugin plugin;
    
    public PlayerPotionCommands(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("This command can only be used by players!")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        String commandName = command.getName().toLowerCase();
        
        switch (commandName) {
            case "luse" -> handleUseCommand(player, data, true);
            case "ruse" -> handleUseCommand(player, data, false);
            case "lspark" -> handleSparkCommand(player, data, true);
            case "rspark" -> handleSparkCommand(player, data, false);
            case "ldisable" -> handleDisableCommand(player, data, true);
            case "rdisable" -> handleDisableCommand(player, data, false);
            case "lenable" -> handleEnableCommand(player, data, true);
            case "renable" -> handleEnableCommand(player, data, false);
            case "ldrain" -> handleDrainCommand(player, data, true);
            case "rdrain" -> handleDrainCommand(player, data, false);
            case "drain" -> handleGeneralDrainCommand(player, data);
        }
        
        return true;
    }
    
    private void handleUseCommand(Player player, PlayerData data, boolean isPrimary) {
        PotionType potion = isPrimary ? data.getPrimaryPotion() : data.getSecondaryPotion();
        
        if (potion == null) {
            String slot = isPrimary ? "primary" : "secondary";
            player.sendMessage(Component.text("No potion in " + slot + " slot!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        data.setActiveSlot(potion);
        plugin.getInfuseHUD().updateHUD(player);
        
        String slot = isPrimary ? "Primary" : "Secondary";
        player.sendMessage(Component.text("Switched to " + slot + " potion: " + potion.getDisplayName())
                .color(NamedTextColor.GREEN));
    }
    
    private void handleSparkCommand(Player player, PlayerData data, boolean isPrimary) {
        PotionType potion = isPrimary ? data.getPrimaryPotion() : data.getSecondaryPotion();
        
        if (potion == null) {
            String slot = isPrimary ? "primary" : "secondary";
            player.sendMessage(Component.text("No potion in " + slot + " slot!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        boolean isEnabled = isPrimary ? data.isPrimaryEnabled() : data.isSecondaryEnabled();
        if (!isEnabled) {
            String slot = isPrimary ? "primary" : "secondary";
            player.sendMessage(Component.text("Potion in " + slot + " slot is disabled!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        // Switch to this potion's spark ability
        data.setActiveSlot(potion);
        plugin.getInfuseHUD().updateHUD(player);
        
        String slot = isPrimary ? "Primary" : "Secondary";
        player.sendMessage(Component.text("Switched to " + slot + " potion spark ability: " + potion.getDisplayName())
                .color(NamedTextColor.GREEN));
    }
    
    private void handleDisableCommand(Player player, PlayerData data, boolean isPrimary) {
        PotionType potion = isPrimary ? data.getPrimaryPotion() : data.getSecondaryPotion();
        
        if (potion == null) {
            String slot = isPrimary ? "primary" : "secondary";
            player.sendMessage(Component.text("No potion in " + slot + " slot!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        if (isPrimary) {
            data.setPrimaryEnabled(false);
        } else {
            data.setSecondaryEnabled(false);
        }
        
        plugin.getEffectManager().disablePassiveEffects(player, potion);
        plugin.getInfuseHUD().updateHUD(player);
        plugin.getDataManager().savePlayerData(player.getUniqueId());
        
        String slot = isPrimary ? "Primary" : "Secondary";
        player.sendMessage(Component.text(slot + " potion effects disabled!")
                .color(NamedTextColor.YELLOW));
    }
    
    private void handleEnableCommand(Player player, PlayerData data, boolean isPrimary) {
        PotionType potion = isPrimary ? data.getPrimaryPotion() : data.getSecondaryPotion();
        
        if (potion == null) {
            String slot = isPrimary ? "primary" : "secondary";
            player.sendMessage(Component.text("No potion in " + slot + " slot!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        if (isPrimary) {
            data.setPrimaryEnabled(true);
        } else {
            data.setSecondaryEnabled(true);
        }
        
        plugin.getEffectManager().activatePassiveEffects(player, potion);
        plugin.getInfuseHUD().updateHUD(player);
        plugin.getDataManager().savePlayerData(player.getUniqueId());
        
        String slot = isPrimary ? "Primary" : "Secondary";
        player.sendMessage(Component.text(slot + " potion effects enabled!")
                .color(NamedTextColor.GREEN));
    }
    
    private void handleDrainCommand(Player player, PlayerData data, boolean isPrimary) {
        PotionType potion = isPrimary ? data.getPrimaryPotion() : data.getSecondaryPotion();
        
        if (potion == null) {
            String slot = isPrimary ? "primary" : "secondary";
            player.sendMessage(Component.text("No potion in " + slot + " slot!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        // Set enabled flag to false BEFORE disabling effects
        if (isPrimary) {
            data.setPrimaryEnabled(false);
        } else {
            data.setSecondaryEnabled(false);
        }
        plugin.getEffectManager().disablePassiveEffects(player, potion);
        // Remove passive invis if draining invis potion
        if (potion == com.infusesmp.potion.PotionType.INVIS) {
            com.infusesmp.potion.effects.InvisEffect.removePassiveInvis(player);
        }
        
        // Create potion item and give to player
        ItemStack potionItem = plugin.getPotionManager().createPotionItem(potion);
        if (potionItem != null) {
            player.getInventory().addItem(potionItem);
        }
        
        // Clear data
        data.clearSlot(isPrimary);
        
        // Update HUD and save
        plugin.getInfuseHUD().updateHUD(player);
        plugin.getDataManager().savePlayerData(player.getUniqueId());
        
        String slot = isPrimary ? "Primary" : "Secondary";
        player.sendMessage(Component.text(slot + " potion drained back to inventory!")
                .color(NamedTextColor.GREEN));
    }
    
    private void handleGeneralDrainCommand(Player player, PlayerData data) {
        boolean hasPrimary = data.getPrimaryPotion() != null;
        boolean hasSecondary = data.getSecondaryPotion() != null;
        
        if (!hasPrimary && !hasSecondary) {
            player.sendMessage(Component.text("No active potions to drain!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        if (hasPrimary && hasSecondary) {
            player.sendMessage(Component.text("⚠️ Please use /ldrain or /rdrain to specify which potion to drain.")
                    .color(NamedTextColor.YELLOW));
            return;
        }
        
        // Only one slot is filled, drain that one
        if (hasPrimary) {
            handleDrainCommand(player, data, true);
        } else {
            handleDrainCommand(player, data, false);
        }
    }
}
