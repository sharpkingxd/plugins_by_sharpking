package com.infusesmp.managers;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import com.infusesmp.potion.effects.*;
import com.infusesmp.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldedit.bukkit.BukkitAdapter;

import java.util.HashMap;
import java.util.Map;

public class EffectManager {
    
    private final InfuseSMPPlugin plugin;
    private final Map<PotionType, Object> effectHandlers;
    
    public EffectManager(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.effectHandlers = new HashMap<>();
        
        initializeEffectHandlers();
    }
    
    private void initializeEffectHandlers() {
        effectHandlers.put(PotionType.REGEN, new RegenEffect(plugin));
        effectHandlers.put(PotionType.FEATHER, new FeatherEffect(plugin));
        effectHandlers.put(PotionType.THUNDER, new ThunderEffect(plugin));
        effectHandlers.put(PotionType.STRENGTH, new StrengthEffect(plugin));
        effectHandlers.put(PotionType.HEART, new HeartEffect(plugin));
        effectHandlers.put(PotionType.FROST, new FrostEffect(plugin));
        effectHandlers.put(PotionType.EMERALD, new EmeraldEffect(plugin));
        effectHandlers.put(PotionType.OCEAN, new OceanEffect(plugin));
        effectHandlers.put(PotionType.FIRE, new FireEffect(plugin));
        effectHandlers.put(PotionType.SPEED, new SpeedEffect(plugin));
        effectHandlers.put(PotionType.HASTE, new HasteEffect(plugin));
        effectHandlers.put(PotionType.INVIS, new InvisEffect(plugin));
    }
    
    public void activatePotion(Player player, PotionType potionType, boolean isPrimary) {
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        
        // Get current potion in the slot
        PotionType currentPotion = isPrimary ? data.getPrimaryPotion() : data.getSecondaryPotion();
        
        // If switching to the same potion, just make it active
        if (currentPotion == potionType) {
            data.setActiveSlot(potionType);
            plugin.getInfuseHUD().updateHUD(player);
            
            String message = plugin.getConfig().getString("messages.potion_switched", 
                    "&a[InfuseSMP] &7Switched to {potion} potion!")
                    .replace("{potion}", potionType.getDisplayName());
            player.sendMessage(Component.text(message.replace("&", "§")));
            return;
        }
        
        // If there's a potion in the slot, convert it back to item
        if (currentPotion != null) {
            // Create potion item
            ItemStack potionItem = plugin.getPotionManager().createPotionItem(currentPotion);
            if (potionItem != null) {
                player.getInventory().addItem(potionItem);
            }
            
            // Disable effects
            disablePassiveEffects(player, currentPotion);
        }
        
        // Set new potion
        if (isPrimary) {
            data.setPrimaryPotion(potionType);
            data.setPrimaryEnabled(true);
        } else {
            data.setSecondaryPotion(potionType);
            data.setSecondaryEnabled(true);
        }
        
        // Make it the active slot
        data.setActiveSlot(potionType);
        
        // Activate passive effects
        activatePassiveEffects(player, potionType);
        
        // Update HUD
        plugin.getInfuseHUD().updateHUD(player);
        
        // Save data
        plugin.getDataManager().savePlayerData(player.getUniqueId());
        
        String message = plugin.getConfig().getString("messages.potion_activated", 
                "&a[InfuseSMP] &7{potion} potion activated!")
                .replace("{potion}", potionType.getDisplayName());
        player.sendMessage(Component.text(message.replace("&", "§")));
    }
    
    public void useSpark(Player player, PotionType potionType) {
        if (potionType == null) {
            player.sendMessage(Component.text("No potion selected!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        // WorldGuard region check for 'spawn' (block for ALL players, including OPs)
        RegionManager regionManager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(player.getWorld()));
        if (regionManager != null) {
            ApplicableRegionSet regionSet = regionManager.getApplicableRegions(BukkitAdapter.asBlockVector(player.getLocation()));
            for (ProtectedRegion region : regionSet) {
                if (region.getId().equalsIgnoreCase("spawn")) {
                    player.sendMessage(Component.text("Spark ability can't be used in protected area!").color(NamedTextColor.RED));
                    return;
                }
            }
        }
        
        // Get the effect handler first
        Object handler = effectHandlers.get(potionType);
        if (handler == null || !(handler instanceof com.infusesmp.potion.effects.PotionEffect effect)) {
            return;
        }
        
        // Check if player has the effect active
        PlayerData data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        boolean hasEffect = (data.getPrimaryPotion() == potionType && data.isPrimaryEnabled()) ||
                          (data.getSecondaryPotion() == potionType && data.isSecondaryEnabled());
        if (!hasEffect) {
            return;
        }
        
        // Only check cooldown for non-SPEED potions
        if (potionType != PotionType.SPEED && plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), potionType)) {
            long remaining = plugin.getCooldownManager().getRemainingCooldown(player.getUniqueId(), potionType);
            String message = plugin.getConfig().getString("messages.cooldown_message", 
                    "&c⚠️ Spark ability on cooldown! ({time}s remaining)")
                    .replace("{time}", String.valueOf(remaining / 1000));
            player.sendMessage(Component.text(message.replace("&", "§")));
            return;
        }
        
        try {
            // Execute spark effect
            effect.useSpark(player);
            // Only set cooldown after successful execution for non-SPEED potions
            if (potionType != PotionType.SPEED) {
                plugin.getCooldownManager().setCooldown(player.getUniqueId(), potionType);
            }
        } catch (Exception e) {
            plugin.getLogger().warning("Error executing spark effect for " + potionType + ": " + e.getMessage());
        }
    }
    
    public void activatePassiveEffects(Player player, PotionType potionType) {
        Object handler = effectHandlers.get(potionType);
        if (handler == null) return;
        
        // Don't override existing vanilla effects with finite duration
        switch (potionType) {
            case REGEN -> {
                if (!hasFiniteDurationEffect(player, PotionEffectType.REGENERATION))
                    ((RegenEffect) handler).activatePassive(player);
            }
            case FEATHER -> ((FeatherEffect) handler).activatePassive(player);
            case THUNDER -> ((ThunderEffect) handler).activatePassive(player);
            case STRENGTH -> {
                if (!hasFiniteDurationEffect(player, PotionEffectType.STRENGTH))
                    ((StrengthEffect) handler).activatePassive(player);
            }
            case HEART -> ((HeartEffect) handler).activatePassive(player);
            case FROST -> ((FrostEffect) handler).activatePassive(player);
            case EMERALD -> ((EmeraldEffect) handler).activatePassive(player);
            case OCEAN -> {
                if (!hasFiniteDurationEffect(player, PotionEffectType.WATER_BREATHING))
                    ((OceanEffect) handler).activatePassive(player);
            }
            case FIRE -> {
                if (!hasFiniteDurationEffect(player, PotionEffectType.FIRE_RESISTANCE))
                    ((FireEffect) handler).activatePassive(player);
            }
            case SPEED -> {
                if (!hasFiniteDurationEffect(player, PotionEffectType.SPEED))
                    ((SpeedEffect) handler).activatePassive(player);
            }
            case HASTE -> {
                if (!hasFiniteDurationEffect(player, PotionEffectType.HASTE))
                    ((HasteEffect) handler).activatePassive(player);
            }
            case INVIS -> {
                if (!hasFiniteDurationEffect(player, PotionEffectType.INVISIBILITY))
                    ((InvisEffect) handler).activatePassive(player);
            }
        }
    }
    
    public void disablePassiveEffects(Player player, PotionType potionType) {
        Object handler = effectHandlers.get(potionType);
        if (handler == null) return;
        
        switch (potionType) {
            case REGEN -> ((RegenEffect) handler).deactivatePassive(player);
            case FEATHER -> ((FeatherEffect) handler).deactivatePassive(player);
            case THUNDER -> ((ThunderEffect) handler).deactivatePassive(player);
            case STRENGTH -> ((StrengthEffect) handler).deactivatePassive(player);
            case HEART -> ((HeartEffect) handler).deactivatePassive(player);
            case FROST -> ((FrostEffect) handler).deactivatePassive(player);
            case EMERALD -> ((EmeraldEffect) handler).deactivatePassive(player);
            case OCEAN -> ((OceanEffect) handler).deactivatePassive(player);
            case FIRE -> ((FireEffect) handler).deactivatePassive(player);
            case SPEED -> ((SpeedEffect) handler).deactivatePassive(player);
            case HASTE -> ((HasteEffect) handler).deactivatePassive(player);
            case INVIS -> {
                ((InvisEffect) handler).deactivatePassive(player);
                com.infusesmp.potion.effects.InvisEffect.removePassiveInvis(player);
            }
        }
    }
    
    // Helper method to check if a player has a finite duration effect
    private boolean hasFiniteDurationEffect(Player player, PotionEffectType type) {
        PotionEffect effect = player.getPotionEffect(type);
        return effect != null && effect.getDuration() < 9999;
    }
    
    // Helper method to check if a player has an infinite duration effect
    private boolean hasInfiniteDurationEffect(Player player, PotionEffectType type) {
        PotionEffect effect = player.getPotionEffect(type);
        return effect != null && effect.getDuration() > 9999;
    }
    
    public Object getEffectHandler(PotionType type) {
        return effectHandlers.get(type);
    }
}
