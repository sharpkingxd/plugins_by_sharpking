package com.infusesmp.managers;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.brewing.BrewingProcess;
import com.infusesmp.potion.PotionType;
import com.infusesmp.utils.BeaconBeamUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class BrewingManager {

    private final InfuseSMPPlugin plugin;
    private final Map<Location, BrewingProcess> activeBrewingProcesses;
    private final Map<UUID, Location> playerBrewingLocations;
    private static Long nextAvailableRitualTime = null;
    private static final long RITUAL_COOLDOWN = 15 * 60 * 1000; // 15 minutes in milliseconds
    private BukkitRunnable ritualTask = null;
    private BossBar ritualBossBar = null;

    public BrewingManager(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.activeBrewingProcesses = new HashMap<>();
        this.playerBrewingLocations = new HashMap<>();
    }

    public boolean startBrewing(Player player, Location brewingStandLocation, PotionType potionType, ItemStack[] contents) {
        if (activeBrewingProcesses.containsKey(brewingStandLocation)) {
            player.sendMessage(Component.text("This brewing stand is already in use!")
                    .color(NamedTextColor.RED));
            return false;
        }

        if (playerBrewingLocations.containsKey(player.getUniqueId())) {
            player.sendMessage(Component.text("You can only brew one potion at a time!")
                    .color(NamedTextColor.RED));
            return false;
        }

        // Check if another ritual is in progress
        if (!activeBrewingProcesses.isEmpty()) {
            player.sendMessage(Component.text("Another ritual is already in progress!")
                    .color(NamedTextColor.RED));
            return false;
        }

        // Check if potion has reached crafting limit
        int crafted = plugin.getPotionCounterManager().getCount(potionType);
        if (crafted >= 3) {
            player.sendMessage(Component.text("You cannot craft this potion anymore. The server limit (3) has been reached.")
                    .color(NamedTextColor.RED));

            // Broadcast message that limit has been reached
            String broadcastMsg = String.format(
                    "§6[InfuseSMP] §e%s §7attempted to brew a §c%s §7potion but the server limit (3) has been reached!",
                    player.getName(),
                    potionType.getDisplayName()
            );
            Bukkit.broadcastMessage(broadcastMsg);
            return false;
        }

        // Check ritual cooldown
        if (nextAvailableRitualTime != null) {
            long currentTime = System.currentTimeMillis();
            if (currentTime < nextAvailableRitualTime) {
                long remainingTime = (nextAvailableRitualTime - currentTime) / 1000; // Convert to seconds
                String timeStr = String.format("%02d:%02d", remainingTime / 60, remainingTime % 60);
                player.sendMessage(Component.text("You must wait " + timeStr + " before starting another ritual!")
                        .color(NamedTextColor.RED));
                return false;
            }
        }

        // Create brewing process
        BrewingProcess process = new BrewingProcess(plugin, player, brewingStandLocation, potionType, contents);
        activeBrewingProcesses.put(brewingStandLocation, process);
        playerBrewingLocations.put(player.getUniqueId(), brewingStandLocation);

        // Start the ritual effects
        startRitualEffects(player, brewingStandLocation, potionType);

        // Set next available ritual time
        nextAvailableRitualTime = System.currentTimeMillis() + RITUAL_COOLDOWN;

        // Broadcast the ritual start
        String worldName = brewingStandLocation.getWorld().getName();
        int x = brewingStandLocation.getBlockX();
        int y = brewingStandLocation.getBlockY();
        int z = brewingStandLocation.getBlockZ();

        String broadcastMsg = String.format(
                "§6[InfuseSMP] §e%s §7is brewing a §c%s §7potion at §e[%s: %d, %d, %d]",
                player.getName(),
                potionType.getDisplayName(),
                worldName, x, y, z
        );

        Bukkit.broadcastMessage(broadcastMsg);

        // Start the process
        process.start();

        return true;
    }

    private void startRitualEffects(Player player, Location location, PotionType potionType) {
        World world = location.getWorld();
        // Remove old block-based beacon beam logic
        // Cancel any existing ritual task
        if (ritualTask != null && !ritualTask.isCancelled()) {
            ritualTask.cancel();
        }
        // Remove any existing BossBar
        if (ritualBossBar != null) {
            ritualBossBar.removeAll();
            ritualBossBar = null;
        }
        // Create BossBar for ritual timer
        ritualBossBar = Bukkit.createBossBar("§dPotion Ritual: 15:00 remaining", BarColor.PURPLE, BarStyle.SOLID);
        ritualBossBar.setProgress(1.0);
        for (Player online : Bukkit.getOnlinePlayers()) {
            ritualBossBar.addPlayer(online);
        }
        // Show initial beam
        BeaconBeamUtil.showParticleBeam(location, 100);

        // Schedule particle, sound, and BossBar updates for 15 minutes
        ritualTask = new BukkitRunnable() {
            int timeLeft = 15 * 60; // 15 minutes in seconds
            @Override
            public void run() {
                if (timeLeft <= 0) {
                    // Auto-complete the ritual when time is up
                    completeBrewing(location);
                    if (ritualBossBar != null) {
                        ritualBossBar.removeAll();
                        ritualBossBar = null;
                    }
                    // Remove the beam when ritual ends
                    BeaconBeamUtil.removeBeaconBeam(location);
                    cancel();
                    return;
                }

                // Update BossBar
                int minutes = timeLeft / 60;
                int seconds = timeLeft % 60;
                String timeStr = String.format("%02d:%02d", minutes, seconds);
                ritualBossBar.setTitle("§dPotion Ritual: " + timeStr + " remaining");
                ritualBossBar.setProgress(timeLeft / 900.0); // 900 seconds = 15 min

                // Add new players who join
                for (Player online : Bukkit.getOnlinePlayers()) {
                    if (!ritualBossBar.getPlayers().contains(online)) {
                        ritualBossBar.addPlayer(online);
                    }
                }

                // Create magical particle effects
                world.spawnParticle(Particle.FLAME,
                        location.clone().add(0.5, 1, 0.5),
                        20, 0.3, 0.5, 0.3, 0);
                world.spawnParticle(Particle.FLAME,
                        location.clone().add(0.5, 2, 0.5),
                        15, 0.5, 1, 0.5, 0.1);
                world.spawnParticle(Particle.FLAME,
                        location.clone().add(0.5, 1.5, 0.5),
                        10, 0.3, 0.3, 0.3, 0);

                // Play sound every 30 seconds
                if (timeLeft % 30 == 0) {
                    world.playSound(location, Sound.BLOCK_BREWING_STAND_BREW, 1.0f, 1.0f);
                }

                // Broadcast location every 5 minutes
                if (timeLeft % 300 == 0) {
                    String broadcastMsg = String.format(
                            "§6[InfuseSMP] §7A §c%s §7potion is brewing at §e[%s: %d, %d, %d]",
                            potionType.getDisplayName(),
                            world.getName(),
                            location.getBlockX(),
                            location.getBlockY(),
                            location.getBlockZ()
                    );
                    Bukkit.broadcastMessage(broadcastMsg);
                }

                timeLeft--;
            }
        };
        ritualTask.runTaskTimer(plugin, 0L, 20L); // Run every second
    }

    public void completeBrewing(Location location) {
        BrewingProcess process = activeBrewingProcesses.remove(location);
        if (process != null) {
            playerBrewingLocations.remove(process.getPlayer().getUniqueId());
            // Remove BossBar
            if (ritualBossBar != null) {
                ritualBossBar.removeAll();
                ritualBossBar = null;
            }

            // Remove the beam
            BeaconBeamUtil.removeBeaconBeam(location);

            // Drop the potion at the brewing stand location
            ItemStack potion = plugin.getPotionManager().createPotionItem(process.getPotionType());
            if (potion != null) {
                World world = location.getWorld();
                world.dropItemNaturally(location.clone().add(0.5, 0.5, 0.5), potion);

                // Increment the potion counter
                PotionType potionType = process.getPotionType();
                plugin.getPotionCounterManager().increment(potionType);

                // Get the updated count
                int count = plugin.getPotionCounterManager().getCount(potionType);
                int remaining = 3 - count;

                // Broadcast completion with counter information
                String message = String.format(
                        "§6[InfuseSMP] §7The §c%s §7potion ritual has been completed! §e(Can be crafted %d more times)",
                        potionType.getDisplayName(),
                        remaining
                );
                Bukkit.broadcastMessage(message);

                // Notify the player
                process.getPlayer().sendMessage(Component.text("Your potion has been completed and dropped at the ritual site!")
                        .color(NamedTextColor.GREEN));
            }

            // Cancel ritual task if it's still running
            if (ritualTask != null && !ritualTask.isCancelled()) {
                ritualTask.cancel();
                ritualTask = null;
            }
        }
    }

    public void cancelBrewing(Location location) {
        BrewingProcess process = activeBrewingProcesses.remove(location);
        if (process != null) {
            playerBrewingLocations.remove(process.getPlayer().getUniqueId());
            process.cancel();
            // Remove BossBar
            if (ritualBossBar != null) {
                ritualBossBar.removeAll();
                ritualBossBar = null;
            }

            // Return ingredients by dropping them
            for (ItemStack item : process.getContents()) {
                if (item != null) {
                    process.getLocation().getWorld().dropItemNaturally(
                            process.getLocation().clone().add(0.5, 0.5, 0.5),
                            item
                    );
                }
            }

            // Cancel ritual task if it's still running
            if (ritualTask != null && !ritualTask.isCancelled()) {
                ritualTask.cancel();
                ritualTask = null;
            }

            // Broadcast cancellation
            Bukkit.broadcastMessage("§6[InfuseSMP] §7A potion ritual has been cancelled!");
        }
    }

    public void cancelAllBrewingProcesses() {
        for (BrewingProcess process : activeBrewingProcesses.values()) {
            process.cancel();
        }
        // Remove BossBar
        if (ritualBossBar != null) {
            ritualBossBar.removeAll();
            ritualBossBar = null;
        }

        // Cancel ritual task if it's running
        if (ritualTask != null && !ritualTask.isCancelled()) {
            ritualTask.cancel();
            ritualTask = null;
        }

        activeBrewingProcesses.clear();
        playerBrewingLocations.clear();
    }

    public boolean isBrewingActive(Location location) {
        return activeBrewingProcesses.containsKey(location);
    }

    public boolean isPlayerBrewing(Player player) {
        return playerBrewingLocations.containsKey(player.getUniqueId());
    }

    public Location getPlayerBrewingLocation(Player player) {
        return playerBrewingLocations.get(player.getUniqueId());
    }

    public BrewingProcess getBrewingProcess(Location location) {
        return activeBrewingProcesses.get(location);
    }
}