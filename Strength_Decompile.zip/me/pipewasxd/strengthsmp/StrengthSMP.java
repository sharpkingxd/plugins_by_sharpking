package me.pipewasxd.strengthsmp;

import java.util.Objects;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class StrengthSMP extends JavaPlugin {
   private StrengthManager strengthManager;

   public void onEnable() {
      this.saveDefaultConfig();
      ConfigManager configManager = new ConfigManager(this);
      this.strengthManager = new StrengthManager(this, configManager);
      WeaponManager weaponManager = new WeaponManager(this);
      this.getServer().getPluginManager().registerEvents(new PlayerDeathListener(this.strengthManager, configManager), this);
      this.getServer().getPluginManager().registerEvents(new StrengthItem(this.strengthManager, configManager), this);
      SwordUltimate swordUltimate = new SwordUltimate(this, weaponManager, this.strengthManager);
      TridentUltimate tridentUltimate = new TridentUltimate(this, weaponManager, this.strengthManager);
      AxeUltimate axeUltimate = new AxeUltimate(this, weaponManager, this.strengthManager);
      BowUltimate bowUltimate = new BowUltimate(this, weaponManager, this.strengthManager);
      ShieldUltimate shieldUltimate = new ShieldUltimate(this, weaponManager, this.strengthManager);
      CrossbowUltimate crossbowUltimate = new CrossbowUltimate(this, weaponManager, this.strengthManager);
      this.getServer().getPluginManager().registerEvents(swordUltimate, this);
      this.getServer().getPluginManager().registerEvents(tridentUltimate, this);
      this.getServer().getPluginManager().registerEvents(axeUltimate, this);
      this.getServer().getPluginManager().registerEvents(bowUltimate, this);
      this.getServer().getPluginManager().registerEvents(shieldUltimate, this);
      this.getServer().getPluginManager().registerEvents(crossbowUltimate, this);
      RerollBook rerollBook = new RerollBook(this, weaponManager);
      this.getServer().getPluginManager().registerEvents(rerollBook, this);
      (new StrengthItemRecipe(this, configManager)).registerRecipe();
      (new RerollBookRecipe(this, configManager)).registerRecipe();
      StrengthCommand strengthCommand = new StrengthCommand(this.strengthManager, weaponManager, this);
      ((PluginCommand)Objects.requireNonNull(this.getCommand("strength"))).setExecutor(strengthCommand);
      ((PluginCommand)Objects.requireNonNull(this.getCommand("strength"))).setTabCompleter(strengthCommand);
      WithdrawCommand withdrawCommand = new WithdrawCommand(this.strengthManager, configManager);
      ((PluginCommand)Objects.requireNonNull(this.getCommand("withdraw"))).setExecutor(withdrawCommand);
      ((PluginCommand)Objects.requireNonNull(this.getCommand("withdraw"))).setTabCompleter(withdrawCommand);
      AbilityCommand abilityCommand = new AbilityCommand(tridentUltimate, axeUltimate, shieldUltimate, bowUltimate, crossbowUltimate, weaponManager);
      ((PluginCommand)Objects.requireNonNull(this.getCommand("ability"))).setExecutor(abilityCommand);
      ItemCommand itemCommand = new ItemCommand(this);
      ((PluginCommand)Objects.requireNonNull(this.getCommand("item"))).setExecutor(itemCommand);
      ((PluginCommand)Objects.requireNonNull(this.getCommand("item"))).setTabCompleter(itemCommand);
      this.getLogger().info("=============================================");
      this.getLogger().info("        STRENGTHSMP IS NOW ONLINE!        ");
      this.getLogger().info("=============================================");
   }

   public void onDisable() {
      this.getLogger().info("=============================================");
      this.getLogger().info("        STRENGTHSMP IS NOW OFFLINE!       ");
      this.getLogger().info("=============================================");
   }

   public StrengthManager getStrengthManager() {
      return this.strengthManager;
   }
}
