package com.infusesmp.data;

import com.infusesmp.potion.PotionType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class PlayerData {
    
    private final UUID playerId;
    private PotionType primaryPotion;
    private PotionType secondaryPotion;
    private boolean primaryEnabled;
    private boolean secondaryEnabled;
    private PotionType activeSlot; // Which slot is currently active for spark usage
    private Set<UUID> trustedPlayers; // Players who won't take spark damage
    
    public PlayerData(UUID playerId) {
        this.playerId = playerId;
        this.primaryPotion = null;
        this.secondaryPotion = null;
        this.primaryEnabled = false;
        this.secondaryEnabled = false;
        this.activeSlot = null;
        this.trustedPlayers = new HashSet<>();
    }
    
    public UUID getPlayerId() {
        return playerId;
    }
    
    public PotionType getPrimaryPotion() {
        return primaryPotion;
    }
    
    public void setPrimaryPotion(PotionType primaryPotion) {
        this.primaryPotion = primaryPotion;
        if (primaryPotion != null && activeSlot == null) {
            activeSlot = primaryPotion;
        }
    }
    
    public PotionType getSecondaryPotion() {
        return secondaryPotion;
    }
    
    public void setSecondaryPotion(PotionType secondaryPotion) {
        this.secondaryPotion = secondaryPotion;
        if (secondaryPotion != null && activeSlot == null) {
            activeSlot = secondaryPotion;
        }
    }
    
    public boolean isPrimaryEnabled() {
        return primaryEnabled;
    }
    
    public void setPrimaryEnabled(boolean primaryEnabled) {
        this.primaryEnabled = primaryEnabled;
    }
    
    public boolean isSecondaryEnabled() {
        return secondaryEnabled;
    }
    
    public void setSecondaryEnabled(boolean secondaryEnabled) {
        this.secondaryEnabled = secondaryEnabled;
    }
    
    public PotionType getActiveSlot() {
        return activeSlot;
    }
    
    public void setActiveSlot(PotionType activeSlot) {
        this.activeSlot = activeSlot;
    }
    
    public void switchToSlot(boolean isPrimary) {
        if (isPrimary && primaryPotion != null) {
            activeSlot = primaryPotion;
        } else if (!isPrimary && secondaryPotion != null) {
            activeSlot = secondaryPotion;
        }
    }
    
    public void clearSlot(boolean isPrimary) {
        if (isPrimary) {
            primaryPotion = null;
            primaryEnabled = false;
            if (activeSlot == primaryPotion) {
                activeSlot = secondaryPotion;
            }
        } else {
            secondaryPotion = null;
            secondaryEnabled = false;
            if (activeSlot == secondaryPotion) {
                activeSlot = primaryPotion;
            }
        }
    }
    
    public boolean hasAnyPotion() {
        return primaryPotion != null || secondaryPotion != null;
    }
    
    public boolean isPotionInSlot(PotionType type, boolean isPrimary) {
        if (isPrimary) {
            return primaryPotion == type;
        } else {
            return secondaryPotion == type;
        }
    }
    
    // Trust system methods
    public Set<UUID> getTrustedPlayers() {
        return trustedPlayers;
    }
    
    public void addTrustedPlayer(UUID playerId) {
        trustedPlayers.add(playerId);
    }
    
    public void removeTrustedPlayer(UUID playerId) {
        trustedPlayers.remove(playerId);
    }
    
    public boolean isTrustedPlayer(UUID playerId) {
        return trustedPlayers.contains(playerId);
    }
}