<p align="center">
  <img src="src/main/resources/assets/logo.png" style="width: 128px; height: 128px" alt="ChatLagFix Logo">
</p>
<h2 align="center">ChatLagFix</h2>

<p align="center">
  A Fabric mod to fix chat-related game stutters.
</p>

This is a small client-side mod for Fabric Minecraft 1.21.11. It prevents the game from freezing or stuttering when chat messages are received or sent on servers.

### The Problem
In vanilla Minecraft, the game processes chat messages on the main render thread. This is the same thread that draws the game to your screen. When a message arrives, the game stops everything to do several heavy tasks:

If any of these tasks take even a few milliseconds, your game will stutter. If they take longer, your game will freeze until the task finishes.

### The Solution
This mod intercepts chat messages the moment they arrive and moves the heavy processing to a dedicated background thread. This allows the main game thread to continue rendering frames without interruption.

Because the processing happens in the background, you might notice a very slight delay before a message appears in your chat box, but your framerate will remain smooth and consistent.


`This was only tested on offline mode I am not even sure if it's a real problem in online mode.`

### Installation
1. [Download latest jar](https://github.com/Fus3n/ChatLagFix/releases/)
2. Drop the jar file into your `mods` folder.
3. This mod is client-side only. You do not need to install it on the server for it to work.