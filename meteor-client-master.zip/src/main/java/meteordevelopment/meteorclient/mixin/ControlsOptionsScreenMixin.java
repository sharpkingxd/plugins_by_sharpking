/*
 * This file is part of the Meteor Client distribution (https://github.com/meteordevelopment/meteor-client).
 * Copyright (c) Meteor Development.
 */

package meteordevelopment.meteorclient.mixin;

import org.spongepowered.asm.mixin.Mixin;

// Placeholder mixin - keybinds are handled separately and not displayed
@Mixin(net.minecraft.client.gui.screen.option.ControlsOptionsScreen.class)
public class ControlsOptionsScreenMixin {
}


