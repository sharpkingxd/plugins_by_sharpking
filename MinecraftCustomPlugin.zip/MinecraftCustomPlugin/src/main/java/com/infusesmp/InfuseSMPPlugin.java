package com.infusesmp;

import com.infusesmp.commands.InfuseCommand;
import com.infusesmp.commands.PlayerPotionCommands;
import com.infusesmp.commands.RecipeCommand;
import com.infusesmp.commands.TrustCommand;
import com.infusesmp.listeners.BrewingListener;
import com.infusesmp.listeners.CombatListener;
import com.infusesmp.listeners.PlayerListener;
import com.infusesmp.listeners.AnvilListener;
import com.infusesmp.listeners.PotionProtectionListener;
import com.infusesmp.listeners.PotionEffectListener; // Add this import
import com.infusesmp.managers.*;
import com.infusesmp.data.DataManager;
import com.infusesmp.gui.InfuseCraftingGUI;
import com.infusesmp.hud.InfuseHUD;
import com.infusesmp.managers.CustomCraftingIntegration;
import org.bukkit.plugin.java.JavaPlugin;

public class InfuseSMPPlugin extends JavaPlugin {
    
    private static InfuseSMPPlugin instance;
    
    private PotionManager potionManager;
    private BrewingManager brewingManager;
    private EffectManager effectManager;
    private CooldownManager cooldownManager;
    private HUDManager hudManager;
    private DataManager dataManager;
    private InfuseCraftingGUI infuseCraftingGUI;
    private InfuseHUD infuseHUD;
    private CustomCraftingIntegration customCraftingIntegration;
    private PotionCounterManager potionCounterManager;
    
    @Override
    public void onEnable() {
        instance = this;
        
        // Save default config
        saveDefaultConfig();
        
        // Initialize managers
        initializeManagers();
        
        // Register events
        registerEvents();
        
        // Register commands
        registerCommands();
        
        // Start HUD updater
        infuseHUD.startHUDUpdater();
        
        // Load potion counters
        potionCounterManager.load();
        
        getLogger().info("InfuseSMP Plugin has been enabled!");
    }
    
    @Override
    public void onDisable() {
        // Save all data
        if (dataManager != null) {
            dataManager.saveAllData();
        }
        
        // Cancel all brewing processes
        if (brewingManager != null) {
            brewingManager.cancelAllBrewingProcesses();
        }
        
        // Save potion counters
        if (potionCounterManager != null) {
            potionCounterManager.save();
        }
        
        getLogger().info("InfuseSMP Plugin has been disabled!");
    }
    
    private void initializeManagers() {
        dataManager = new DataManager(this);
        potionManager = new PotionManager(this);
        cooldownManager = new CooldownManager(this);
        effectManager = new EffectManager(this);
        brewingManager = new BrewingManager(this);
        hudManager = new HUDManager(this);
        infuseCraftingGUI = new InfuseCraftingGUI(this);
        infuseHUD = new InfuseHUD(this);
        customCraftingIntegration = new CustomCraftingIntegration(this);
        potionCounterManager = new PotionCounterManager(this);
    }
    
    private void registerEvents() {
        getServer().getPluginManager().registerEvents(new BrewingListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new AnvilListener(this), this);
        getServer().getPluginManager().registerEvents(new PotionProtectionListener(), this);
        getServer().getPluginManager().registerEvents(new PotionEffectListener(this), this); // Add this line
    }
    
    private void registerCommands() {
        // Register commands
        InfuseCommand infuseCommand = new InfuseCommand(this);
        getCommand("infuse").setExecutor(infuseCommand);
        getCommand("resetpotioncounter").setExecutor(infuseCommand);
        getCommand("resetpotioncounter").setTabCompleter(infuseCommand);
        
        getCommand("trust").setExecutor(new TrustCommand(this, true));
        getCommand("untrust").setExecutor(new TrustCommand(this, false));
        getCommand("infuserecipe").setExecutor(new RecipeCommand(this));
        
        PlayerPotionCommands playerCommands = new PlayerPotionCommands(this);
        getCommand("luse").setExecutor(playerCommands);
        getCommand("ruse").setExecutor(playerCommands);
        getCommand("lspark").setExecutor(playerCommands);
        getCommand("rspark").setExecutor(playerCommands);
        getCommand("ldisable").setExecutor(playerCommands);
        getCommand("rdisable").setExecutor(playerCommands);
        getCommand("lenable").setExecutor(playerCommands);
        getCommand("renable").setExecutor(playerCommands);
        getCommand("ldrain").setExecutor(playerCommands);
        getCommand("rdrain").setExecutor(playerCommands);
        getCommand("drain").setExecutor(playerCommands);
    }
    
    public static InfuseSMPPlugin getInstance() {
        return instance;
    }
    
    public PotionManager getPotionManager() {
        return potionManager;
    }
    
    public BrewingManager getBrewingManager() {
        return brewingManager;
    }
    
    public EffectManager getEffectManager() {
        return effectManager;
    }
    
    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }
    
    public HUDManager getHudManager() {
        return hudManager;
    }
    
    public DataManager getDataManager() {
        return dataManager;
    }
    
    public InfuseCraftingGUI getInfuseCraftingGUI() {
        return infuseCraftingGUI;
    }
    
    public InfuseHUD getInfuseHUD() {
        return infuseHUD;
    }
    
    public CustomCraftingIntegration getCustomCraftingIntegration() {
        return customCraftingIntegration;
    }
    
    public PotionCounterManager getPotionCounterManager() {
        return potionCounterManager;
    }
}
