package me.pipewasxd.strengthsmp;

import java.util.List;
import java.util.Objects;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.attribute.AttributeModifier.Operation;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.jetbrains.annotations.NotNull;

public record StrengthManager(StrengthSMP plugin, ConfigManager configManager) implements Listener {
   public int getStrength(Player player) {
      return this.plugin.getConfig().getInt("players." + String.valueOf(player.getUniqueId()) + ".strength", this.configManager.getDefaultStrength());
   }

   public void setStrength(Player player, int strength) {
      int maxStrength = this.configManager.getMaxStrength();
      int minStrength = this.configManager.getMinStrength();
      int oldStrength = this.getStrength(player);
      strength = Math.max(minStrength, Math.min(maxStrength, strength));
      this.plugin.getConfig().set("players." + String.valueOf(player.getUniqueId()) + ".strength", strength);
      this.plugin.saveConfig();
      this.updatePlayerAttributes(player, strength);
      if (strength >= maxStrength && oldStrength < maxStrength) {
         player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0F, 2.0F);
         String var10001 = String.valueOf(ChatColor.DARK_RED);
         player.sendMessage(var10001 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ʜᴀᴠᴇ ʀᴇᴀᴄʜᴇᴅ ᴍᴀxɪᴍᴜᴍ sᴛʀᴇɴɢᴛʜ!");
      }

   }

   public void addStrength(Player player, int amount) {
      int current = this.getStrength(player);
      this.setStrength(player, current + amount);
   }

   public boolean isAtMaxStrength(Player player) {
      return this.getStrength(player) >= this.configManager.getMaxStrength();
   }

   public boolean isAtMinStrength(Player player) {
      return this.getStrength(player) <= this.configManager.getMinStrength();
   }

   private void updatePlayerAttributes(Player player, int strength) {
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         AttributeInstance instance = player.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
         if (instance != null) {
            NamespacedKey key = new NamespacedKey("strengthsmp", "strength_modifier");
            List var10000 = instance.getModifiers().stream().filter((mod) -> mod.getKey().equals(key)).toList();
            Objects.requireNonNull(instance);
            var10000.forEach(instance::removeModifier);
            if (strength != 0) {
               AttributeModifier modifier = new AttributeModifier(key, (double)strength, Operation.ADD_NUMBER, EquipmentSlotGroup.HAND);
               instance.addModifier(modifier);
            }
         }

      });
   }

   public void loadPlayerStrength(Player player) {
      Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         int strength = this.getStrength(player);
         this.updatePlayerAttributes(player, strength);
      }, 10L);
   }

   public boolean equals(Object obj) {
      return false;
   }

   public int hashCode() {
      return 0;
   }

   public @NotNull String toString() {
      return "";
   }
}
