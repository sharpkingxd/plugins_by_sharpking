package com.sharpkingyt.majesticmace.managers;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.Recipe;
import org.bukkit.configuration.ConfigurationSection;

import com.sharpkingyt.majesticmace.MajesticMace;

import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class RecipeManager {
    
    private final MajesticMace plugin;
    private NamespacedKey customRecipeKey;
    private ShapedRecipe customRecipe;
    
    public RecipeManager(MajesticMace plugin) {
        this.plugin = plugin;
        this.customRecipeKey = new NamespacedKey(plugin, "custom_mace_recipe");
    }
    
    public void loadCustomRecipe() {
        // Remove existing custom recipe
        removeCustomRecipe();
        
        if (!plugin.getConfig().getBoolean("recipe.enabled")) {
            plugin.getLogger().info("Custom recipe system is disabled");
            return;
        }
        
        // Create new mace item
        ItemStack mace = new ItemStack(Material.MACE);
        
        // Create shaped recipe
        customRecipe = new ShapedRecipe(customRecipeKey, mace);
        customRecipe.shape("ABC", "DEF", "GHI");
        
        // Load ingredients from config
        ConfigurationSection ingredients = plugin.getConfig().getConfigurationSection("custom-recipe.ingredients");
        if (ingredients == null) {
            plugin.getLogger().warning("No custom recipe ingredients found in config, using default");
            loadDefaultRecipe();
            return;
        }
        
        // Map config slots to recipe pattern (3x3 grid)
        Map<String, Material> recipeMap = new HashMap<>();
        recipeMap.put("A", getMaterialFromConfig("slot-36", ingredients)); // Top-left
        recipeMap.put("B", getMaterialFromConfig("slot-37", ingredients)); // Top-center
        recipeMap.put("C", getMaterialFromConfig("slot-38", ingredients)); // Top-right
        recipeMap.put("D", getMaterialFromConfig("slot-39", ingredients)); // Middle-left
        recipeMap.put("E", getMaterialFromConfig("slot-40", ingredients)); // Middle-center
        recipeMap.put("F", getMaterialFromConfig("slot-41", ingredients)); // Middle-right
        recipeMap.put("G", getMaterialFromConfig("slot-42", ingredients)); // Bottom-left
        recipeMap.put("H", getMaterialFromConfig("slot-43", ingredients)); // Bottom-center
        recipeMap.put("I", getMaterialFromConfig("slot-44", ingredients)); // Bottom-right
        
        // Set ingredients
        for (Map.Entry<String, Material> entry : recipeMap.entrySet()) {
            if (entry.getValue() != Material.AIR) {
                customRecipe.setIngredient(entry.getKey().charAt(0), entry.getValue());
            }
        }
        
        // Add recipe to server
        try {
            Bukkit.addRecipe(customRecipe);
            plugin.getLogger().info("Custom mace recipe loaded successfully");
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to load custom mace recipe: " + e.getMessage());
        }
    }
    
    private Material getMaterialFromConfig(String slot, ConfigurationSection ingredients) {
        String materialName = ingredients.getString(slot, "AIR");
        try {
            return Material.valueOf(materialName.toUpperCase());
        } catch (IllegalArgumentException e) {
            plugin.getLogger().warning("Invalid material '" + materialName + "' for " + slot + ", using AIR");
            return Material.AIR;
        }
    }
    
    public void removeCustomRecipe() {
        if (customRecipe != null) {
            Iterator<Recipe> recipeIterator = Bukkit.recipeIterator();
            while (recipeIterator.hasNext()) {
                Recipe recipe = recipeIterator.next();
                if (recipe instanceof ShapedRecipe) {
                    ShapedRecipe shapedRecipe = (ShapedRecipe) recipe;
                    if (shapedRecipe.getKey().equals(customRecipeKey)) {
                        recipeIterator.remove();
                        plugin.getLogger().info("Removed custom mace recipe");
                        break;
                    }
                }
            }
        }
    }
    
    public void saveRecipeFromGUI(ItemStack[] guiContents) {
        // Extract ingredients from GUI slots 36-44
        ConfigurationSection ingredients = plugin.getConfig().getConfigurationSection("custom-recipe.ingredients");
        if (ingredients == null) {
            plugin.getConfig().createSection("custom-recipe.ingredients");
            ingredients = plugin.getConfig().getConfigurationSection("custom-recipe.ingredients");
        }
        
        // Map GUI slots to config
        for (int i = 36; i <= 44; i++) {
            ItemStack item = guiContents[i];
            String materialName = (item == null || item.getType() == Material.AIR) ? "AIR" : item.getType().name();
            ingredients.set("slot-" + i, materialName);
        }
        
        // Save config and reload recipe
        plugin.saveConfig();
        loadCustomRecipe();
        
        plugin.getLogger().info("Custom mace recipe saved and reloaded");
    }
    
    public void saveRecipeFromGUI(ItemStack[] guiContents, int[] craftingSlots) {
        // Extract ingredients from new GUI crafting slots (10-12, 19-21, 28-30)
        ConfigurationSection ingredients = plugin.getConfig().getConfigurationSection("custom-recipe.ingredients");
        if (ingredients == null) {
            plugin.getConfig().createSection("custom-recipe.ingredients");
            ingredients = plugin.getConfig().getConfigurationSection("custom-recipe.ingredients");
        }
        
        // Map GUI crafting slots to config slots (36-44)
        int[] configSlots = {36, 37, 38, 39, 40, 41, 42, 43, 44};
        
        for (int i = 0; i < craftingSlots.length; i++) {
            ItemStack item = guiContents[craftingSlots[i]];
            String materialName = (item == null || item.getType() == Material.AIR) ? "AIR" : item.getType().name();
            ingredients.set("slot-" + configSlots[i], materialName);
        }
        
        // Save config and reload recipe
        plugin.saveConfig();
        loadCustomRecipe();
        
        plugin.getLogger().info("Custom mace recipe saved and reloaded from new GUI layout");
    }
    
    public void resetToDefault() {
        ConfigurationSection defaultRecipe = plugin.getConfig().getConfigurationSection("custom-recipe.default-recipe");
        ConfigurationSection ingredients = plugin.getConfig().getConfigurationSection("custom-recipe.ingredients");
        
        if (defaultRecipe != null && ingredients != null) {
            // Copy default recipe to current ingredients
            for (String key : defaultRecipe.getKeys(false)) {
                ingredients.set(key, defaultRecipe.getString(key));
            }
            
            plugin.saveConfig();
            loadCustomRecipe();
            plugin.getLogger().info("Mace recipe reset to default configuration");
        }
    }
    
    private void loadDefaultRecipe() {
        resetToDefault();
    }
    
    public boolean isRecipeEnabled() {
        return plugin.getConfig().getBoolean("recipe.enabled");
    }
}