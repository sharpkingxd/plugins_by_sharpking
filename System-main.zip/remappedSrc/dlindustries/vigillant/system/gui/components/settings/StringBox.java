package dlindustries.vigillant.system.gui.components.settings;

import dlindustries.vigillant.system.system;
import dlindustries.vigillant.system.gui.components.ModuleButton;
import dlindustries.vigillant.system.module.modules.client.ClickGUI;
import dlindustries.vigillant.system.module.setting.Setting;
import dlindustries.vigillant.system.module.setting.StringSetting;
import dlindustries.vigillant.system.utils.*;
import dlindustries.vigillant.system.utils.ColorUtils;
import dlindustries.vigillant.system.utils.RenderUtils;
import dlindustries.vigillant.system.utils.TextRenderer;
import dlindustries.vigillant.system.utils.Utils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.awt.*;

public final class StringBox extends RenderableSetting {
    private final StringSetting setting;
    private Color currentAlpha;

    public StringBox(ModuleButton parent, Setting<?> setting, int offset) {
        super(parent, setting, offset);
        this.setting = (StringSetting) setting;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        TextRenderer.drawString(setting.getName() + ": " + (setting.getValue().length() <= 9 ? setting.getValue() : (setting.getValue().substring(0, 9) + "...")), context, parentX() + 9 ,(parentY() + parentOffset() + offset) + 9, ColorUtils.getRGB50Percent(245, 245, 245));

        if (false) {
            int toHoverAlpha = isHovered(mouseX, mouseY) ? 15 : 0;

            if (currentAlpha == null)
                currentAlpha = new Color(255, 255, 255, toHoverAlpha);
            else currentAlpha = new Color(255, 255, 255, currentAlpha.getAlpha());

            if (currentAlpha.getAlpha() != toHoverAlpha)
                currentAlpha = ColorUtils.smoothAlphaTransition(0.05F, toHoverAlpha, currentAlpha);

            RenderUtils.fillWithAlpha(context, parentX(), parentY() + parentOffset() + offset, parentX() + parentWidth(), parentY() + parentOffset() + offset + parentHeight(), ColorUtils.getRGBWithAlpha(currentAlpha, 128));
        }
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        if(isHovered(mouseX, mouseY) && button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            mc.setScreen(new Screen(Text.empty()) {
                private String content = setting.getValue();

                @Override
                public void render(DrawContext context, int mouseX, int mouseY, float delta) {
                    RenderUtils.unscaledProjection();
                    mouseX *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();
                    mouseY *= (int) MinecraftClient.getInstance().getWindow().getScaleFactor();
                    super.render(context, mouseX, mouseY, delta);

                    RenderUtils.fillWithAlpha(context, 0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight(), ColorUtils.getRGB50Percent(0, 0, 0));

                    int screenMidX = mc.getWindow().getWidth() / 2;
                    int screenMidY = mc.getWindow().getHeight() / 2;

                    int contentWidth = Math.max(TextRenderer.getWidth(content), 600);
                    int width = contentWidth + 30;

                    int startX = screenMidX - (width / 2);
                    int startY = screenMidY - 30;

                    MatrixStack matrices = new MatrixStack();
                    RenderUtils.renderRoundedQuad(matrices, new Color(0, 0, 0, ClickGUI.alphaWindow.getValueInt()), startX, startY, startX + width, screenMidY + 30, 5, 5, 0, 0, 20);
                    TextRenderer.drawCenteredString(setting.getName(), context, screenMidX, startY + 10, ColorUtils.getRGB50Percent(245, 245, 245));
                    RenderUtils.fillWithAlpha(context, startX, screenMidY, startX + width, screenMidY + 30, ColorUtils.getRGB50Percent(0, 0, 0));

                    RenderUtils.renderRoundedOutline(context, new Color(50, 50, 50, 128), startX + 10, screenMidY + 5, startX + (width - 10), screenMidY + 25, 5, 5, 5, 5, 2, 20);

                    TextRenderer.drawString(content, context, startX + 15, screenMidY + 8, ColorUtils.getRGB50Percent(245, 245, 245));
                    Color lineColor = Utils.getMainColor(128, 1);
                    RenderUtils.fillWithAlpha(context, startX, screenMidY, startX + width, screenMidY + 1, ColorUtils.getRGBWithAlpha(lineColor, 128));

                    RenderUtils.scaledProjection();
                }

                @Override
                public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
                    if(keyCode == GLFW.GLFW_KEY_ESCAPE) {
                        setting.setValue(content.strip());
                        mc.setScreen(system.INSTANCE.clickGui);
                    }

                    if(isPaste(keyCode))
                        content += mc.keyboard.getClipboard();

                    if(isCopy(keyCode))
                        GLFW.glfwSetClipboardString(mc.getWindow().getHandle(), content);

                    if(keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                        if(!content.isEmpty()) {
                            content = content.substring(0, content.length() - 1);
                        }
                    }

                    return super.keyPressed(keyCode, scanCode, modifiers);
                }

                public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
                }

                @Override
                public boolean charTyped(char chr, int modifiers) {
                    content += chr;
                    return super.charTyped(chr, modifiers);
                }

                @Override
                public boolean shouldCloseOnEsc() {
                    return false;
                }
            });
        }
        super.mouseClicked(mouseX, mouseY, button);
    }

}
