package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import com.infusesmp.potion.PotionType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

import java.util.*;

public class OceanEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Long> sparkEndTimes = new HashMap<>();
    private final Map<UUID, BukkitRunnable> whirlpoolTasks = new HashMap<>();
    private static final long SPARK_DURATION = 5 * 1000; // 5 seconds in milliseconds
    private static final double WHIRLPOOL_RADIUS = 15.0;
    private static final double DROWNING_RADIUS = 8.0;
    private static final int DROWNING_INTERVAL = 40; // 2 seconds (40 ticks)
    private static final double PULL_STRENGTH = 1.5;

    public OceanEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        startEffectWatchdog();
    }

    @Override
    public void activatePassive(Player player) {
        safeRemoveAndAddOcean(player);
        startDrowningAura(player);
        player.sendMessage(Component.text("🌊 Ocean Effect activated! You now have permanent water breathing and dolphin's grace.")
                .color(NamedTextColor.BLUE));
    }

    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        sparkEndTimes.remove(playerId);
        PotionEffect water = player.getPotionEffect(PotionEffectType.WATER_BREATHING);
        if (water != null && water.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.WATER_BREATHING);
        }
        PotionEffect dolphin = player.getPotionEffect(PotionEffectType.DOLPHINS_GRACE);
        if (dolphin != null && dolphin.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
        }
        BukkitRunnable whirlpool = whirlpoolTasks.remove(playerId);
        if (whirlpool != null) {
            whirlpool.cancel();
        }
    }

    @Override
    public void useSpark(Player player) {
        if (!hasEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Ocean effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        sparkEndTimes.put(playerId, System.currentTimeMillis() + SPARK_DURATION);
        
        // Start whirlpool effect
        startWhirlpool(player);
        
        // Visual and sound effects
        player.playSound(player.getLocation(), Sound.AMBIENT_UNDERWATER_ENTER, 2.0f, 0.5f);
        player.sendMessage(Component.text("🌊 Whirlpool activated!")
                .color(NamedTextColor.AQUA));
    }

    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        // No special attack handling needed
    }

    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // No special defense handling needed
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Trident trident) || !(trident.getShooter() instanceof Player shooter)) {
            return;
        }

        if (!hasEffect(shooter)) return;

        // Pull hit entity towards the shooter
        Entity hitEntity = event.getHitEntity();
        if (hitEntity instanceof LivingEntity target) {
            Location shooterLoc = shooter.getLocation();
            Location targetLoc = target.getLocation();
            
            Vector direction = shooterLoc.toVector().subtract(targetLoc.toVector()).normalize();
            target.setVelocity(direction.multiply(PULL_STRENGTH));
            
            // Visual and sound effects
            target.getWorld().spawnParticle(Particle.FALLING_WATER, targetLoc, 50, 0.5, 0.5, 0.5, 0.1);
            target.getWorld().playSound(targetLoc, Sound.ENTITY_FISHING_BOBBER_RETRIEVE, 1.0f, 1.0f);
        }
    }

    private void startDrowningAura(Player player) {
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!hasEffect(player) || !player.isOnline()) {
                    cancel();
                    return;
                }

                // Get nearby entities
                Collection<Entity> nearbyEntities = player.getWorld().getNearbyEntities(
                    player.getLocation(),
                    DROWNING_RADIUS,
                    DROWNING_RADIUS,
                    DROWNING_RADIUS
                );

                for (Entity entity : nearbyEntities) {
                    if (entity instanceof LivingEntity target && entity != player) {
                        // Check if target is a trusted player
                        if (target instanceof Player targetPlayer) {
                            PlayerData playerData = plugin.getDataManager().getPlayerData(player.getUniqueId());
                            if (playerData.isTrustedPlayer(targetPlayer.getUniqueId())) {
                                // Skip effects for trusted players
                                continue;
                            }
                        }
                        
                        // Apply drowning effect
                        if (target instanceof Player) {
                            // Players get drowning effect
                            ((Player) target).setRemainingAir(Math.max(0, ((Player) target).getRemainingAir() - 40));
                        } else {
                            // Other entities get damage
                            target.damage(2.0);
                        }
                        
                        // Visual effect
                        target.getWorld().spawnParticle(Particle.FALLING_WATER, 
                            target.getLocation().add(0, 1, 0), 
                            10, 0.3, 0.5, 0.3, 0.1);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, DROWNING_INTERVAL);
    }

    private void startWhirlpool(Player player) {
        UUID playerId = player.getUniqueId();
        
        // Cancel existing whirlpool if any
        BukkitRunnable existingWhirlpool = whirlpoolTasks.remove(playerId);
        if (existingWhirlpool != null) {
            existingWhirlpool.cancel();
        }

        // Create new whirlpool task
        BukkitRunnable whirlpool = new BukkitRunnable() {
            private final Location center = player.getLocation();
            private double rotation = 0;

            @Override
            public void run() {
                if (!player.isOnline() || !isSparkActive(playerId)) {
                    cancel();
                    whirlpoolTasks.remove(playerId);
                    return;
                }

                // Get entities in range
                Collection<Entity> nearbyEntities = player.getWorld().getNearbyEntities(
                    center,
                    WHIRLPOOL_RADIUS,
                    WHIRLPOOL_RADIUS,
                    WHIRLPOOL_RADIUS
                );

                // Update rotation
                rotation += Math.PI / 16; // Rotate by 11.25 degrees each tick

                for (Entity entity : nearbyEntities) {
                    if (entity instanceof LivingEntity target && entity != player) {
                        // Check if target is a trusted player
                        if (target instanceof Player targetPlayer) {
                            PlayerData playerData = plugin.getDataManager().getPlayerData(player.getUniqueId());
                            if (playerData.isTrustedPlayer(targetPlayer.getUniqueId())) {
                                // Skip effects for trusted players
                                continue;
                            }
                        }
                        
                        // Calculate pull vector
                        Location targetLoc = target.getLocation();
                        Vector toCenter = center.toVector().subtract(targetLoc.toVector());
                        double distance = toCenter.length();
                        
                        if (distance > 1.0) { // Prevent division by zero and too strong pull when very close
                            // Add rotational component
                            Vector rotational = new Vector(-toCenter.getZ(), 0, toCenter.getX()).normalize();
                            Vector pullVector = toCenter.normalize().multiply(0.3) // Pull towards center
                                .add(rotational.multiply(0.2)); // Add rotation
                            
                            target.setVelocity(target.getVelocity().add(pullVector));
                        }
                        
                        // Visual effects
                        target.getWorld().spawnParticle(Particle.FALLING_WATER,
                            targetLoc.add(0, 0.5, 0),
                            5, 0.2, 0.2, 0.2, 0.1);
                    }
                }

                // Whirlpool particle effect
                for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 16) {
                    double x = Math.cos(angle + rotation) * WHIRLPOOL_RADIUS;
                    double z = Math.sin(angle + rotation) * WHIRLPOOL_RADIUS;
                    Location particleLoc = center.clone().add(x, 0, z);
                    
                    player.getWorld().spawnParticle(Particle.FALLING_WATER,
                        particleLoc,
                        5, 0.2, 0.2, 0.2, 0.1);
                }
            }
        };
        whirlpool.runTaskTimer(plugin, 0L, 1L);
        whirlpoolTasks.put(playerId, whirlpool);
    }
    private boolean isSparkActive(UUID playerId) {
        Long endTime = sparkEndTimes.get(playerId);
        return endTime != null && System.currentTimeMillis() < endTime;
    }

    private boolean hasEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.OCEAN && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.OCEAN && data.isSecondaryEnabled());
    }

    // --- Watchdog to ensure effects are always present ---
    // Remove duplicate method - keep only ONE activatePassive
    
    public void deactivateEffects(Player player) {
        player.removePotionEffect(PotionEffectType.WATER_BREATHING);
        player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
    }
    
    // Call this from:
    // - PlayerQuitEvent
    // - PlayerDeathEvent
    // - Potion expiration logic
    // Add missing watchdog method
    private void startEffectWatchdog() {
        new BukkitRunnable() {
            @Override
            public void run() {
                // Check all online players with Ocean effect
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    if (hasEffect(player)) {
                        // Check if they're missing our effects
                        PotionEffect waterBreathing = player.getPotionEffect(PotionEffectType.WATER_BREATHING);
                        PotionEffect dolphinsGrace = player.getPotionEffect(PotionEffectType.DOLPHINS_GRACE);
                        
                        // Only reapply if they don't have any effect
                        if (waterBreathing == null) {
                            player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 
                                Integer.MAX_VALUE, 1, false, false));
                        }
                        if (dolphinsGrace == null) {
                            player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, 
                                Integer.MAX_VALUE, 1, false, false));
                        }
                    } else {
                        // If they don't have our effect but have the potion effects, remove only if they're our effects
                        PotionEffect waterBreathing = player.getPotionEffect(PotionEffectType.WATER_BREATHING);
                        PotionEffect dolphinsGrace = player.getPotionEffect(PotionEffectType.DOLPHINS_GRACE);
                        
                        if (waterBreathing != null && waterBreathing.getDuration() > 9999) {
                            player.removePotionEffect(PotionEffectType.WATER_BREATHING);
                        }
                        if (dolphinsGrace != null && dolphinsGrace.getDuration() > 9999) {
                            player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L); // Check every second
    }

    private void safeRemoveAndAddOcean(Player player) {
        PotionEffect water = player.getPotionEffect(PotionEffectType.WATER_BREATHING);
        PotionEffect dolphin = player.getPotionEffect(PotionEffectType.DOLPHINS_GRACE);
        if (water == null || water.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.WATER_BREATHING);
            player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 1));
        }
        if (dolphin == null || dolphin.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.DOLPHINS_GRACE);
            player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, Integer.MAX_VALUE, 1));
        }
    }
}
