package com.infusesmp.utils;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class ItemUtil {
    
    public static ItemStack createGuiItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.displayName(Component.text(name)
                    .color(NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false));
            
            if (lore != null && !lore.isEmpty()) {
                List<Component> loreComponents = lore.stream()
                        .map(line -> (Component) Component.text(line)
                                .color(NamedTextColor.GRAY)
                                .decoration(TextDecoration.ITALIC, false))
                        .collect(java.util.stream.Collectors.toList());
                meta.lore(loreComponents);
            }
            
            item.setItemMeta(meta);
        }
        
        return item;
    }
    
    public static ItemStack createFillerItem() {
        ItemStack item = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        
        if (meta != null) {
            meta.displayName(Component.text(" "));
            item.setItemMeta(meta);
        }
        
        return item;
    }
    
    public static boolean isSimilar(ItemStack item1, ItemStack item2) {
        if (item1 == null && item2 == null) return true;
        if (item1 == null || item2 == null) return false;
        
        return item1.getType() == item2.getType();
    }
    
    public static ItemStack cloneWithAmount(ItemStack item, int amount) {
        if (item == null) return null;
        
        ItemStack clone = item.clone();
        clone.setAmount(amount);
        return clone;
    }
    
    public static void setItemDisplayNameAndLore(ItemStack item, String name, List<String> lore) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text(name)
                    .color(NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false));
            
            if (lore != null && !lore.isEmpty()) {
                List<Component> loreComponents = lore.stream()
                        .map(line -> Component.text(line)
                                .color(NamedTextColor.GRAY)
                                .decoration(TextDecoration.ITALIC, false))
                        .collect(java.util.stream.Collectors.toList());
                meta.lore(loreComponents);
            }
            
            item.setItemMeta(meta);
        }
    }
}
