package com.infusesmp.potion;

import com.infusesmp.InfuseSMPPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.List;
import java.util.ArrayList;

public class InfusePotion {
    
    private final PotionType type;
    private final InfuseSMPPlugin plugin;
    private final NamespacedKey potionTypeKey;
    
    public InfusePotion(PotionType type, InfuseSMPPlugin plugin) {
        this.type = type;
        this.plugin = plugin;
        this.potionTypeKey = new NamespacedKey(plugin, "infuse_potion_type");
    }
    
    public ItemStack createItem() {
        ItemStack item = new ItemStack(Material.POTION);
        PotionMeta meta = (PotionMeta) item.getItemMeta();
        
        // Set display name
        meta.displayName(Component.text(type.getIcon() + " " + type.getDisplayName())
                .color(NamedTextColor.LIGHT_PURPLE)
                .decoration(TextDecoration.ITALIC, false));
        
        // Set lore with description
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text(""));
        lore.add(Component.text("A mysterious infuse potion with")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("powerful effects and abilities.")
                .color(NamedTextColor.GRAY)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text(""));
        lore.add(Component.text("Right-click to drink")
                .color(NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text("Shift+Right-click to use spark")
                .color(NamedTextColor.GOLD)
                .decoration(TextDecoration.ITALIC, false));
        lore.add(Component.text(""));
        lore.add(Component.text(type.isPrimary() ? "Primary Effect" : "Secondary Effect")
                .color(type.isPrimary() ? NamedTextColor.RED : NamedTextColor.BLUE)
                .decoration(TextDecoration.ITALIC, false)
                .decoration(TextDecoration.BOLD, true));
        
        meta.lore(lore);
        
        // Set custom potion color based on type
        switch (type) {
            case REGEN -> meta.setColor(org.bukkit.Color.LIME);
            case FEATHER -> meta.setColor(org.bukkit.Color.WHITE);
            case THUNDER -> meta.setColor(org.bukkit.Color.YELLOW);
            case STRENGTH -> meta.setColor(org.bukkit.Color.RED);
            case HEART -> meta.setColor(org.bukkit.Color.MAROON);
            case FROST -> meta.setColor(org.bukkit.Color.AQUA);
            case EMERALD -> meta.setColor(org.bukkit.Color.GREEN);
            case OCEAN -> meta.setColor(org.bukkit.Color.BLUE);
            case FIRE -> meta.setColor(org.bukkit.Color.ORANGE);
            case SPEED -> meta.setColor(org.bukkit.Color.GRAY);
            case HASTE -> meta.setColor(org.bukkit.Color.OLIVE);
            case INVIS -> meta.setColor(org.bukkit.Color.SILVER);
        }
        
        // Store potion type in persistent data
        meta.getPersistentDataContainer().set(potionTypeKey, PersistentDataType.STRING, type.name());
        // Set custom model data for resource pack
        meta.setCustomModelData(type.getCustomModelData());
        
        item.setItemMeta(meta);
        return item;
    }
    
    public static PotionType getPotionType(ItemStack item) {
        if (item == null || item.getType() != Material.POTION) {
            return null;
        }
        
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        
        NamespacedKey key = new NamespacedKey(InfuseSMPPlugin.getInstance(), "infuse_potion_type");
        String typeString = meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        
        if (typeString == null) {
            return null;
        }
        
        return PotionType.fromString(typeString);
    }
    
    public static boolean isInfusePotion(ItemStack item) {
        return getPotionType(item) != null;
    }
    
    public PotionType getType() {
        return type;
    }
}
