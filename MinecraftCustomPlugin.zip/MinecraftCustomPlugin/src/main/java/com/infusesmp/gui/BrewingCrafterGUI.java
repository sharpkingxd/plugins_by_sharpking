package com.infusesmp.gui;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import com.infusesmp.utils.ItemUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;

public class BrewingCrafterGUI implements Listener {
    
    private final InfuseSMPPlugin plugin;
    private final Player player;
    private final Location brewingStandLocation;
    private final Inventory inventory;
    private PotionType currentRecipeMatch = null;
    
    public BrewingCrafterGUI(InfuseSMPPlugin plugin, Player player, Location brewingStandLocation) {
        this.plugin = plugin;
        this.player = player;
        this.brewingStandLocation = brewingStandLocation;
        
        this.inventory = Bukkit.createInventory(null, 54, 
                Component.text("Infuse Potion Crafter").color(NamedTextColor.DARK_PURPLE));
        
        setupGUI();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    
    private void setupGUI() {
        // Fill with filler items
        ItemStack filler = ItemUtil.createFillerItem();
        for (int i = 0; i < 54; i++) {
            inventory.setItem(i, filler);
        }
        
        // Clear crafting grid (3x3 in center)
        int[] craftingSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        for (int slot : craftingSlots) {
            inventory.setItem(slot, null);
        }
        
        // Start button (initially disabled)
        updateStartButton(false, null);
        
        // Cancel button
        ItemStack cancelButton = ItemUtil.createGuiItem(Material.BARRIER, 
                "Cancel", 
                List.of("Close the brewing interface"));
        inventory.setItem(38, cancelButton);
    }
    
    private void updateStartButton(boolean recipeFound, PotionType type) {
        ItemStack startButton;
        if (recipeFound && type != null) {
            startButton = ItemUtil.createGuiItem(Material.BREWING_STAND,
                "§aStart Brewing " + type.getDisplayName(),
                Arrays.asList(
                    "§7Click to start brewing:",
                    "§f" + type.getDisplayName(),
                    "",
                    "§7Time: §f15 minutes",
                    "§7Location will be broadcast"
                ));
            currentRecipeMatch = type;
        } else {
            startButton = ItemUtil.createGuiItem(Material.BARRIER,
                "§cNo Valid Recipe",
                Arrays.asList(
                    "§7Place the correct items",
                    "§7in the crafting grid"
                ));
            currentRecipeMatch = null;
        }
        inventory.setItem(24, startButton);
    }
    
    public void open() {
        player.openInventory(inventory);
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getInventory().equals(inventory)) return;
        
        int slot = event.getRawSlot();
        
        // Handle button clicks
        if (slot == 24) { // Start button
            event.setCancelled(true);
            if (currentRecipeMatch != null) {
                handleStartBrewing();
            } else {
                player.sendMessage(Component.text("Place the correct items in the crafting grid first!")
                        .color(NamedTextColor.RED));
            }
        } else if (slot == 38) { // Cancel button
            event.setCancelled(true);
            player.closeInventory();
        }
        
        // Allow interaction with crafting slots
        int[] craftingSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        boolean isCraftingSlot = Arrays.stream(craftingSlots).anyMatch(i -> i == slot);
        
        if (!isCraftingSlot && slot < 54) {
            event.setCancelled(true);
        }
        
        // Check recipe after any change
        if (isCraftingSlot) {
            Bukkit.getScheduler().runTaskLater(plugin, this::checkRecipe, 1L);
        }
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!event.getInventory().equals(inventory)) return;
        
        // Return items to player
        int[] craftingSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        for (int slot : craftingSlots) {
            ItemStack item = inventory.getItem(slot);
            if (item != null && item.getType() != Material.AIR) {
                player.getInventory().addItem(item);
            }
        }
        
        // Unregister listener
        InventoryClickEvent.getHandlerList().unregister(this);
        InventoryCloseEvent.getHandlerList().unregister(this);
    }
    
    private void checkRecipe() {
        // Get all items in crafting grid
        int[] craftingSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        ItemStack[] contents = new ItemStack[9];
        for (int i = 0; i < 9; i++) {
            contents[i] = inventory.getItem(craftingSlots[i]);
        }
        
        // Check if grid is empty
        boolean isEmpty = true;
        for (ItemStack item : contents) {
            if (item != null && item.getType() != Material.AIR) {
                isEmpty = false;
                break;
            }
        }
        
        if (isEmpty) {
            updateStartButton(false, null);
            return;
        }
        
        // Check for complete recipe match
        for (PotionType type : PotionType.values()) {
            ItemStack[][] recipe = plugin.getPotionManager().getRecipe(type);
            if (recipe == null) continue;
            
            boolean matches = true;
            boolean hasAllItems = true;
            
            // Check each slot
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    ItemStack recipeItem = recipe[row][col];
                    ItemStack gridItem = contents[row * 3 + col];
                    
                    // If recipe expects an item
                    if (recipeItem != null && recipeItem.getType() != Material.AIR) {
                        // Grid must have matching item
                        if (gridItem == null || !gridItem.isSimilar(recipeItem)) {
                            matches = false;
                            if (gridItem == null) hasAllItems = false;
                            break;
                        }
                    } else {
                        // If recipe expects empty slot
                        if (gridItem != null && gridItem.getType() != Material.AIR) {
                            matches = false;
                            break;
                        }
                    }
                }
                if (!matches) break;
            }
            
            // Update start button if we found a match
            if (matches && hasAllItems) {
                updateStartButton(true, type);
                return;
            }
        }
        
        // No complete match found
        updateStartButton(false, null);
    }
    
    private void handleStartBrewing() {
        if (currentRecipeMatch == null) {
            player.sendMessage(Component.text("No valid recipe found!")
                    .color(NamedTextColor.RED));
            return;
        }
        
        // Get crafting contents
        int[] craftingSlots = {10, 11, 12, 19, 20, 21, 28, 29, 30};
        ItemStack[] contents = new ItemStack[9];
        
        for (int i = 0; i < craftingSlots.length; i++) {
            contents[i] = inventory.getItem(craftingSlots[i]);
        }
        
        // Start brewing process
        if (plugin.getBrewingManager().startBrewing(player, brewingStandLocation, currentRecipeMatch, contents)) {
            // Clear crafting grid
            for (int slot : craftingSlots) {
                inventory.setItem(slot, null);
            }
            
            player.closeInventory();
        }
    }
}
