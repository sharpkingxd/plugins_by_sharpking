package com.sharpkingyt.majesticmace.managers;

import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.configuration.ConfigurationSection;

import com.sharpkingyt.majesticmace.MajesticMace;

import java.util.HashMap;
import java.util.Map;

public class SoundManager {
    
    private final MajesticMace plugin;
    private Map<String, SoundData> sounds;
    private boolean soundsEnabled;
    private float volume;
    
    public SoundManager(MajesticMace plugin) {
        this.plugin = plugin;
        loadSounds();
    }
    
    public void loadSounds() {
        sounds = new HashMap<>();
        soundsEnabled = plugin.getConfig().getBoolean("sounds.enabled", true);
        volume = (float) plugin.getConfig().getDouble("sounds.volume", 1.0);
        
        ConfigurationSection soundEffects = plugin.getConfig().getConfigurationSection("sounds.effects");
        if (soundEffects == null) {
            plugin.getLogger().warning("No sound effects configuration found, using defaults");
            loadDefaultSounds();
            return;
        }
        
        for (String key : soundEffects.getKeys(false)) {
            ConfigurationSection soundConfig = soundEffects.getConfigurationSection(key);
            if (soundConfig != null) {
                String soundName = soundConfig.getString("sound");
                float pitch = (float) soundConfig.getDouble("pitch", 1.0);
                
                try {
                    Sound sound = Sound.valueOf(soundName.toUpperCase());
                    sounds.put(key, new SoundData(sound, pitch));
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("Invalid sound '" + soundName + "' for effect '" + key + "'");
                }
            }
        }
    }
    
    private void loadDefaultSounds() {
        sounds.put("gui-open", new SoundData(Sound.UI_BUTTON_CLICK, 1.0f));
        sounds.put("gui-close", new SoundData(Sound.BLOCK_CHEST_CLOSE, 1.0f));
        sounds.put("save-recipe", new SoundData(Sound.ENTITY_PLAYER_LEVELUP, 1.2f));
        sounds.put("reset-recipe", new SoundData(Sound.BLOCK_ANVIL_LAND, 0.8f));
        sounds.put("access-denied", new SoundData(Sound.ENTITY_VILLAGER_NO, 0.9f));
        sounds.put("command-execute", new SoundData(Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.5f));
        sounds.put("recipe-toggle", new SoundData(Sound.BLOCK_NOTE_BLOCK_PLING, 2.0f));
    }
    
    public void playSound(Player player, String soundKey) {
        if (!soundsEnabled || player == null) {
            return;
        }
        
        SoundData soundData = sounds.get(soundKey);
        if (soundData != null) {
            player.playSound(player.getLocation(), soundData.sound, volume, soundData.pitch);
        } else {
            plugin.getLogger().warning("Sound effect '" + soundKey + "' not found");
        }
    }
    
    public void reloadSounds() {
        loadSounds();
        plugin.getLogger().info("Sound effects reloaded");
    }
    
    public boolean areSoundsEnabled() {
        return soundsEnabled;
    }
    
    public void setSoundsEnabled(boolean enabled) {
        this.soundsEnabled = enabled;
        plugin.getConfig().set("sounds.enabled", enabled);
        plugin.saveConfig();
    }
    
    private static class SoundData {
        final Sound sound;
        final float pitch;
        
        SoundData(Sound sound, float pitch) {
            this.sound = sound;
            this.pitch = pitch;
        }
    }
}