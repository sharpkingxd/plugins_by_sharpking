package me.pipewasxd.strengthsmp;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class CrossbowUltimate implements Listener {
   private final StrengthSMP plugin;
   private final WeaponManager weaponManager;
   private final StrengthManager strengthManager;
   private final Map<UUID, Integer> ultimateShotCount = new HashMap();
   private final Map<UUID, Long> ultimateCooldown = new HashMap();
   private final Map<UUID, BukkitRunnable> cooldownTasks = new HashMap();

   public CrossbowUltimate(StrengthSMP plugin, WeaponManager weaponManager, StrengthManager strengthManager) {
      this.plugin = plugin;
      this.weaponManager = weaponManager;
      this.strengthManager = strengthManager;
   }

   public boolean onAbilityCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (player.getInventory().getItemInMainHand().getType() != Material.CROSSBOW) {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#8B8B83:#A9A9A9>ʏᴏᴜ ᴍᴜsᴛ ʜᴏʟᴅ ᴀ ᴄʀᴏssʙᴏᴡ ᴛᴏ ᴜsᴇ ᴛʜɪs!</gradient></bold>"));
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6F, 1.2F);
            return true;
         } else if (this.weaponManager.getPlayerWeapon(player) != WeaponType.CROSSBOW) {
            return true;
         } else if (!this.strengthManager.isAtMaxStrength(player)) {
            return true;
         } else {
            UUID uuid = player.getUniqueId();
            int currentCount = (Integer)this.ultimateShotCount.getOrDefault(uuid, 0);
            if (this.isOnCooldown(player)) {
               long remaining = ((Long)this.ultimateCooldown.get(uuid) - System.currentTimeMillis()) / 1000L;
               return true;
            } else {
               return true;
            }
         }
      } else {
         sender.sendMessage("Only players can use this command.");
         return true;
      }
   }

   @EventHandler
   public void onCrossbowShoot(EntityShootBowEvent event) {
      LivingEntity var3 = event.getEntity();
      if (var3 instanceof Player shooter) {
         Entity var4 = event.getProjectile();
         if (var4 instanceof final Arrow arrow) {
            if (event.getBow() != null) {
               if (event.getBow().getType() == Material.CROSSBOW) {
                  if (this.weaponManager.getPlayerWeapon(shooter) == WeaponType.CROSSBOW) {
                     if (this.strengthManager.isAtMaxStrength(shooter)) {
                        UUID uuid = shooter.getUniqueId();
                        double random = Math.random();
                        if (random < 0.333) {
                           arrow.setMetadata("crossbow_pull", new FixedMetadataValue(this.plugin, true));
                           arrow.setGlowing(true);
                           (new BukkitRunnable() {
                              public void run() {
                                 if (!arrow.isDead() && arrow.isValid()) {
                                    Particle.DustOptions whiteDust = new Particle.DustOptions(Color.fromRGB(255, 255, 255), 1.0F);
                                    arrow.getWorld().spawnParticle(Particle.DUST, arrow.getLocation(), 2, 0.05, 0.05, 0.05, whiteDust);
                                 } else {
                                    this.cancel();
                                 }
                              }
                           }).runTaskTimer(this.plugin, 0L, 1L);
                        }

                        if (!this.isOnCooldown(shooter)) {
                           int shots = (Integer)this.ultimateShotCount.getOrDefault(uuid, 0) + 1;
                           this.ultimateShotCount.put(uuid, shots);
                           if (shots >= 10) {
                              arrow.setMetadata("crossbow_ultimate", new FixedMetadataValue(this.plugin, true));
                              arrow.setGlowing(true);
                              arrow.setFireTicks(100);
                              this.ultimateShotCount.put(uuid, 0);
                              shooter.playSound(shooter.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0F, 1.0F);
                              shooter.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#8B0000:#B22222>ᴜʟᴛɪᴍᴀᴛᴇ ᴀᴄᴛɪᴠᴀᴛᴇᴅ</gradient></bold>"));
                              shooter.playSound(shooter.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1.0F, 0.8F);
                              (new BukkitRunnable() {
                                 public void run() {
                                    if (!arrow.isDead() && arrow.isValid()) {
                                       Particle.DustOptions redDust = new Particle.DustOptions(Color.fromRGB(255, 0, 0), 1.5F);
                                       arrow.getWorld().spawnParticle(Particle.DUST, arrow.getLocation(), 3, 0.05, 0.05, 0.05, redDust);
                                       arrow.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, arrow.getLocation(), 1, 0.05, 0.05, 0.05, 0.01);
                                    } else {
                                       this.cancel();
                                    }
                                 }
                              }).runTaskTimer(this.plugin, 0L, 1L);
                           } else if (shots % 2 == 0) {
                           }

                        }
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onArrowHit(ProjectileHitEvent event) {
      Projectile var3 = event.getEntity();
      if (var3 instanceof Arrow arrow) {
         ProjectileSource var4 = arrow.getShooter();
         if (var4 instanceof Player shooter) {
            Entity var5 = event.getHitEntity();
            if (var5 instanceof Player target) {
               if (this.weaponManager.getPlayerWeapon(shooter) == WeaponType.CROSSBOW) {
                  if (arrow.hasMetadata("crossbow_pull")) {
                     Location shooterLoc = shooter.getLocation().clone().add((double)0.0F, (double)1.0F, (double)0.0F);
                     Location targetLoc = target.getLocation().clone().add((double)0.0F, (double)1.0F, (double)0.0F);
                     Vector pullVector = shooterLoc.toVector().subtract(targetLoc.toVector()).normalize();
                     pullVector.multiply((double)2.5F);
                     pullVector.setY(0.3);
                     target.setVelocity(pullVector);
                     Particle.DustOptions whiteDust = new Particle.DustOptions(Color.fromRGB(255, 255, 255), 1.5F);
                     target.getWorld().spawnParticle(Particle.DUST, targetLoc, 20, 0.3, (double)0.5F, 0.3, whiteDust);
                     target.playSound(target.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1.0F, 1.2F);
                     shooter.playSound(shooter.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 1.0F, 1.2F);
                  }

                  if (arrow.hasMetadata("crossbow_ultimate")) {
                     Location hitLoc = arrow.getLocation();
                     Particle.DustOptions redDust = new Particle.DustOptions(Color.fromRGB(255, 0, 0), 2.0F);
                     hitLoc.getWorld().spawnParticle(Particle.DUST, hitLoc, 30, 0.3, 0.3, 0.3, redDust);
                     hitLoc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, hitLoc, 15, 0.3, 0.3, 0.3, 0.05);
                     hitLoc.getWorld().playSound(hitLoc, Sound.ENTITY_GENERIC_EXPLODE, 1.0F, 1.5F);
                     this.startCooldown(shooter);
                  }

               }
            }
         }
      }
   }

   @EventHandler
   public void onArrowDamage(EntityDamageByEntityEvent event) {
      Entity var3 = event.getDamager();
      if (var3 instanceof Arrow arrow) {
         ProjectileSource var4 = arrow.getShooter();
         if (var4 instanceof Player shooter) {
            if (this.weaponManager.getPlayerWeapon(shooter) == WeaponType.CROSSBOW) {
               if (arrow.hasMetadata("crossbow_ultimate")) {
                  event.setDamage(event.getDamage() * (double)4.0F);
                  Entity var5 = event.getEntity();
                  if (var5 instanceof Player) {
                     Player target = (Player)var5;
                     Location targetLoc = target.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
                     Particle.DustOptions redDust = new Particle.DustOptions(Color.fromRGB(255, 0, 0), 2.0F);
                     targetLoc.getWorld().spawnParticle(Particle.DUST, targetLoc, 50, 0.3, 0.8, 0.3, redDust);
                     targetLoc.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, targetLoc, 25, 0.3, 0.8, 0.3, 0.05);
                  }

                  shooter.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#8B0000:#B22222>ᴜʟᴛɪᴍᴀᴛᴇ ᴀᴄᴛɪᴠᴀᴛᴇᴅ</gradient></bold>"));
                  shooter.playSound(shooter.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1.0F, 0.8F);
               }

            }
         }
      }
   }

   private void spawnEvokerFangs(Location start, Location end) {
      Vector direction = end.toVector().subtract(start.toVector()).normalize();
      Location current = start.clone();

      for(int i = 0; i < 10; ++i) {
         current.add(direction.clone().multiply((double)0.5F));
         Particle.DustOptions whiteDust = new Particle.DustOptions(Color.fromRGB(255, 255, 255), 1.2F);
         current.getWorld().spawnParticle(Particle.DUST, current, 5, 0.2, 0.2, 0.2, whiteDust);
      }

   }

   private void startCooldown(final Player player) {
      final UUID uuid = player.getUniqueId();
      this.ultimateCooldown.put(uuid, System.currentTimeMillis() + 60000L);
      player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#A9A9A9:#D3D3D3>ᴏɴ ᴄᴏᴏʟᴅᴏᴡɴ</gradient></bold>"));
      player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5F, 1.0F);
      BukkitRunnable cooldownTask = new BukkitRunnable() {
         public void run() {
            player.sendMessage(MiniMessage.miniMessage().deserialize("<bold><gradient:#006400:#008000>ᴜʟᴛɪᴍᴀᴛᴇ ʀᴇᴀᴅʏ</gradient></bold>"));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
            CrossbowUltimate.this.cooldownTasks.remove(uuid);
         }
      };
      cooldownTask.runTaskLater(this.plugin, 1200L);
      this.cooldownTasks.put(uuid, cooldownTask);
   }

   public boolean isOnCooldown(Player player) {
      Long cooldownEnd = (Long)this.ultimateCooldown.get(player.getUniqueId());
      return cooldownEnd != null && System.currentTimeMillis() < cooldownEnd;
   }
}
