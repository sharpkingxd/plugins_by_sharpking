package me.pipewasxd.strengthsmp;

import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public record StrengthItem(StrengthManager strengthManager, ConfigManager configManager) implements Listener {
   @EventHandler
   public void onPlayerUseStrengthItem(PlayerInteractEvent event) {
      Player player = event.getPlayer();
      ItemStack item = event.getItem();
      if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
         if (StrengthItemRecipe.isStrengthItem(item)) {
            event.setCancelled(true);
            if (this.strengthManager.isAtMaxStrength(player)) {
               String var4 = String.valueOf(ChatColor.DARK_RED);
               player.sendMessage(var4 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ᴀʀᴇ ᴀᴛ ᴛʜᴇ ᴍᴀxɪᴍᴜᴍ ᴀᴍᴏᴜɴᴛ ᴏғ sᴛʀᴇɴɢᴛʜ!");
            } else {
               item.setAmount(item.getAmount() - 1);
               this.strengthManager.addStrength(player, 1);
               String var10001 = String.valueOf(ChatColor.DARK_RED);
               player.sendMessage(var10001 + String.valueOf(ChatColor.BOLD) + "ʏᴏᴜ ᴄᴏɴsᴜᴍᴇᴅ " + String.valueOf(ChatColor.WHITE) + String.valueOf(ChatColor.BOLD) + "+1" + String.valueOf(ChatColor.DARK_RED) + String.valueOf(ChatColor.BOLD) + " sᴛʀᴇɴɢᴛʜ");
               player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0F, 1.0F);
            }
         }
      }
   }
}
