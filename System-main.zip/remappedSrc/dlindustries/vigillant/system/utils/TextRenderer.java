package dlindustries.vigillant.system.utils;

import net.minecraft.client.gui.DrawContext;

import static dlindustries.vigillant.system.system.mc;
public final class TextRenderer {

	public static void drawString(CharSequence string, DrawContext context, int x, int y, int color) {
		drawMinecraftText(string, context, x, y, color);
	}

	public static int getWidth(CharSequence string) {
		if (mc == null || mc.textRenderer == null) return 0;
		return mc.textRenderer.getWidth(string == null ? "" : string.toString());
	}

	public static void drawCenteredString(CharSequence string, DrawContext context, int x, int y, int color) {
		drawCenteredMinecraftText(string, context, x, y, color);
	}

	public static void drawLargeString(CharSequence string, DrawContext context, int x, int y, int color) {
		drawLargerMinecraftText(string, context, x, y, color);
	}

	public static void drawMinecraftText(CharSequence string, DrawContext context, int x, int y, int color) {

		if (mc == null || mc.textRenderer == null) return;
		String text = string == null ? "" : string.toString();
		context.drawText(mc.textRenderer, text, x, y, color, false);
	}

	public static void drawLargerMinecraftText(CharSequence string, DrawContext context, int x, int y, int color) {

		if (mc == null || mc.textRenderer == null) return;
		String text = string == null ? "" : string.toString();
		context.drawText(mc.textRenderer, text, x, y, color, false);
	}

	public static void drawCenteredMinecraftText(CharSequence string, DrawContext context, int x, int y, int color) {

		if (mc == null || mc.textRenderer == null) return;
		String s = string == null ? "" : string.toString();
		context.drawText(mc.textRenderer, s, x - (mc.textRenderer.getWidth(s) / 2), y, color, false);
	}

	public static void drawSmallString(CharSequence string, DrawContext context, int x, int y, int color) {

		if (mc == null || mc.textRenderer == null) return;
		String text = string == null ? "" : string.toString();

		var matrices = context.getMatrices();
		matrices.pushMatrix();
		matrices.translate((float)x, (float)y);
		matrices.scale(0.85f, 0.85f);
		matrices.translate((float)-x, (float)-y);
		context.drawText(mc.textRenderer, text, x, y, color, false);
		matrices.popMatrix();
	}

	public static int getSmallWidth(CharSequence string) {

		return (int)(getWidth(string) * 0.85f);
	}
}
