package com.infusesmp.managers;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;

public class PotionCounterManager {
    private final InfuseSMPPlugin plugin;
    private final Map<PotionType, Integer> counterMap = new EnumMap<>(PotionType.class);
    private File counterFile;
    private FileConfiguration counterConfig;

    public PotionCounterManager(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        setupFile();
        load();
    }

    private void setupFile() {
        counterFile = new File(plugin.getDataFolder(), "potion_counters.yml");
        if (!counterFile.exists()) {
            try {
                plugin.getDataFolder().mkdirs();
                counterFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create potion_counters.yml: " + e.getMessage());
            }
        }
        counterConfig = YamlConfiguration.loadConfiguration(counterFile);
    }

    public synchronized int getCount(PotionType type) {
        return counterMap.getOrDefault(type, 0);
    }

    public synchronized void increment(PotionType type) {
        counterMap.put(type, getCount(type) + 1);
        save();
    }

    public synchronized void reset(PotionType type) {
        counterMap.put(type, 0);
        save();
    }

    public synchronized void save() {
        for (PotionType type : PotionType.values()) {
            counterConfig.set(type.name(), getCount(type));
        }
        try {
            counterConfig.save(counterFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save potion_counters.yml: " + e.getMessage());
        }
    }

    public synchronized void load() {
        for (PotionType type : PotionType.values()) {
            int count = counterConfig.getInt(type.name(), 0);
            counterMap.put(type, count);
        }
    }
} 