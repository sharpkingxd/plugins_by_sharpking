package com.infusesmp.commands;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.data.PlayerData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class TrustCommand implements CommandExecutor, TabCompleter {
    
    private final InfuseSMPPlugin plugin;
    private final boolean isTrust; // true for trust, false for untrust
    
    public TrustCommand(InfuseSMPPlugin plugin, boolean isTrust) {
        this.plugin = plugin;
        this.isTrust = isTrust;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("This command can only be used by players!")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        if (!player.hasPermission("infuse.use")) {
            player.sendMessage(Component.text("You don't have permission to use this command!")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        if (args.length < 1) {
            player.sendMessage(Component.text("Usage: /" + (isTrust ? "trust" : "untrust") + " <player>")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        // Get target player
        String targetName = args[0];
        Player targetPlayer = Bukkit.getPlayer(targetName);
        
        if (targetPlayer == null) {
            player.sendMessage(Component.text("Player not found or not online!")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        // Can't trust/untrust yourself
        if (targetPlayer.equals(player)) {
            player.sendMessage(Component.text("You can't " + (isTrust ? "trust" : "untrust") + " yourself!")
                    .color(NamedTextColor.RED));
            return true;
        }
        
        UUID playerId = player.getUniqueId();
        UUID targetId = targetPlayer.getUniqueId();
        
        // Get player data
        PlayerData playerData = plugin.getDataManager().getPlayerData(playerId);
        
        if (isTrust) {
            // Check if already trusted
            if (playerData.isTrustedPlayer(targetId)) {
                player.sendMessage(Component.text(targetPlayer.getName() + " is already trusted!")
                        .color(NamedTextColor.YELLOW));
                return true;
            }
            
            // Add to trusted players
            playerData.addTrustedPlayer(targetId);
            plugin.getDataManager().savePlayerData(playerId);
            
            // Send messages
            player.sendMessage(Component.text("You now trust " + targetPlayer.getName() + ". They won't take spark damage from you.")
                    .color(NamedTextColor.GREEN));
            targetPlayer.sendMessage(Component.text(player.getName() + " now trusts you. You won't take spark damage from them.")
                    .color(NamedTextColor.GREEN));
        } else {
            // Check if not trusted
            if (!playerData.isTrustedPlayer(targetId)) {
                player.sendMessage(Component.text(targetPlayer.getName() + " is not in your trusted list!")
                        .color(NamedTextColor.YELLOW));
                return true;
            }
            
            // Remove from trusted players
            playerData.removeTrustedPlayer(targetId);
            plugin.getDataManager().savePlayerData(playerId);
            
            // Send messages
            player.sendMessage(Component.text("You no longer trust " + targetPlayer.getName() + ". They will now take spark damage from you.")
                    .color(NamedTextColor.YELLOW));
            targetPlayer.sendMessage(Component.text(player.getName() + " no longer trusts you. You will now take spark damage from them.")
                    .color(NamedTextColor.YELLOW));
        }
        
        return true;
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (!(sender instanceof Player) || !sender.hasPermission("infuse.use")) {
            return completions;
        }
        
        if (args.length == 1) {
            // Suggest online players except the sender
            Player senderPlayer = (Player) sender;
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!player.equals(senderPlayer)) {
                    completions.add(player.getName());
                }
            }
        }
        
        return completions;
    }
}