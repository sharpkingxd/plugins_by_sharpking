#!/bin/bash

# Majestic Mace Plugin Build Script
# Author: SharpKingYT

echo "=========================================="
echo "    Building Majestic Mace Plugin v1.0.0"
echo "    Author: SharpKingYT"
echo "=========================================="

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "❌ Error: Maven is not installed or not in PATH"
    echo "Please install Maven to build this plugin"
    exit 1
fi

# Check Java version
java_version=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d'.' -f1)
if [ "$java_version" -lt 17 ]; then
    echo "❌ Error: Java 17 or higher is required"
    echo "Current Java version: $(java -version 2>&1 | head -n 1)"
    exit 1
fi

echo "✅ Maven found: $(mvn -version | head -n 1)"
echo "✅ Java version: $(java -version 2>&1 | head -n 1)"
echo ""

# Clean previous builds
echo "🧹 Cleaning previous builds..."
mvn clean

# Compile and package
echo "🔨 Compiling and packaging plugin..."
mvn package

# Check if build was successful
if [ $? -eq 0 ]; then
    echo ""
    echo "=========================================="
    echo "✅ Build completed successfully!"
    echo "📦 Plugin JAR location: target/MajesticMace-1.0.0.jar"
    echo "📋 Ready for deployment to your server's plugins folder"
    echo "=========================================="
else
    echo ""
    echo "=========================================="
    echo "❌ Build failed!"
    echo "Please check the error messages above"
    echo "=========================================="
    exit 1
fi