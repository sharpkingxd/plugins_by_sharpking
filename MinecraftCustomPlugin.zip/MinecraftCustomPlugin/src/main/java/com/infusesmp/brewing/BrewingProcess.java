package com.infusesmp.brewing;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class BrewingProcess {
    
    private final InfuseSMPPlugin plugin;
    private final Player player;
    private final Location location;
    private final PotionType potionType;
    private final ItemStack[] contents;
    private BukkitTask brewingTask;
    private BukkitTask coordinateLeakTask;
    
    public BrewingProcess(InfuseSMPPlugin plugin, Player player, Location location, 
                         PotionType potionType, ItemStack[] contents) {
        this.plugin = plugin;
        this.player = player;
        this.location = location;
        this.potionType = potionType;
        this.contents = contents.clone();
    }
    
    public void start() {
        int processTime = plugin.getConfig().getInt("brewing.process_time", 900) * 20; // Convert to ticks
        int leakInterval = plugin.getConfig().getInt("brewing.coordinate_leak_interval", 300) * 20; // Convert to ticks
        
        // Start brewing timer - continue even if player leaves
        brewingTask = new BukkitRunnable() {
            @Override
            public void run() {
                complete();
            }
        }.runTaskLater(plugin, processTime);
        
        // Start coordinate leak timer
        coordinateLeakTask = new BukkitRunnable() {
            @Override
            public void run() {
                leakCoordinates();
            }
        }.runTaskTimer(plugin, leakInterval, leakInterval);
        
        // Broadcast start
        String message = String.format(
            "§6[InfuseSMP] §7A §c%s §7potion ritual has begun at §e[%s: %d, %d, %d]",
            potionType.getDisplayName(),
            location.getWorld().getName(),
            location.getBlockX(),
            location.getBlockY(),
            location.getBlockZ()
        );
        plugin.getServer().broadcastMessage(message);
    }
    
    private void complete() {
        cancel();
        plugin.getBrewingManager().completeBrewing(location);
    }
    
    private void leakCoordinates() {
        // Broadcast the brewing stand location
        Location brewingLoc = location;
        String message = plugin.getConfig().getString("messages.coordinate_leak", 
                "&c[InfuseSMP] &7A potion is brewing at X:{x} Y:{y} Z:{z}")
                .replace("{x}", String.valueOf(brewingLoc.getBlockX()))
                .replace("{y}", String.valueOf(brewingLoc.getBlockY()))
                .replace("{z}", String.valueOf(brewingLoc.getBlockZ()));
        
        // Broadcast to all players
        for (Player onlinePlayer : plugin.getServer().getOnlinePlayers()) {
            onlinePlayer.sendMessage(Component.text(message.replace("&", "§")));
        }
    }
    
    public void cancel() {
        if (brewingTask != null && !brewingTask.isCancelled()) {
            brewingTask.cancel();
        }
        
        if (coordinateLeakTask != null && !coordinateLeakTask.isCancelled()) {
            coordinateLeakTask.cancel();
        }
    }
    
    public Player getPlayer() {
        return player;
    }
    
    public Location getLocation() {
        return location;
    }
    
    public PotionType getPotionType() {
        return potionType;
    }
    
    public ItemStack[] getContents() {
        return contents.clone();
    }
}
