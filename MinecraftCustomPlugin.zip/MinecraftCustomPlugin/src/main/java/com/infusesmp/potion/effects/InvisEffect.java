package com.infusesmp.potion.effects;

import com.infusesmp.InfuseSMPPlugin;
import com.infusesmp.potion.PotionType;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ItemFlag;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.PacketType;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import com.comphenix.protocol.wrappers.EnumWrappers;
import com.comphenix.protocol.wrappers.Pair;

import java.util.*;

public class InvisEffect implements com.infusesmp.potion.effects.PotionEffect, Listener {
    
    private final InfuseSMPPlugin plugin;
    private final Map<UUID, Integer> hitCounter = new HashMap<>();
    private final Map<UUID, Long> lastSparkTime = new HashMap<>();
    private final Map<UUID, Set<Location>> activeSmokeBombs = new HashMap<>();
    private final Map<UUID, BukkitTask> smokeBombTasks = new HashMap<>();
    private final ProtocolManager protocolManager;
    private static final Set<UUID> currentlyInvisible = new HashSet<>();
    
    private static final long SPARK_DURATION = 20 * 20; // 20 seconds in ticks
    private static final long SPARK_COOLDOWN = 90 * 1000; // 90 seconds in milliseconds
    private static final int HITS_FOR_EFFECT = 10;
    private static final double SMOKE_RADIUS = 5.0;
    private static final double SPARK_RADIUS = 7.0;
    
    // Track periodic hide tasks for each player
    private static final Map<UUID, BukkitTask> periodicHideTasks = new HashMap<>();
    
    public InvisEffect(InfuseSMPPlugin plugin) {
        this.plugin = plugin;
        this.protocolManager = ProtocolLibrary.getProtocolManager();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        startEffectWatchdog();
    }
    
    // Modify watchdog to never interfere with other potion effects
    private void startEffectWatchdog() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    if (hasInvisEffect(player)) {
                        // Get current invisibility effect
                        PotionEffect currentInvis = player.getPotionEffect(PotionEffectType.INVISIBILITY);
                        
                        // Only reapply if they don't have any invisibility effect
                        if (currentInvis == null) {
                            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 
                                Integer.MAX_VALUE, 0, false, false));
                        }
                    } else {
                        // If they don't have our effect but have invisibility, remove it only if it's our effect
                        PotionEffect currentInvis = player.getPotionEffect(PotionEffectType.INVISIBILITY);
                        if (currentInvis != null && isOurInvisibilityEffect(player, currentInvis)) {
                            player.removePotionEffect(PotionEffectType.INVISIBILITY);
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 20L, 40L); // Check every 2 seconds
    }
    
    // Improve the detection of custom effects
    private boolean isOurInvisibilityEffect(Player player, PotionEffect effect) {
        if (effect == null || effect.getType() != PotionEffectType.INVISIBILITY) return false;
        
        // Much more precise check for our custom effect
        // Only consider it our effect if it has infinite duration (> 9999) and amplifier 0
        // AND the player has our effect OR is in spark mode
        boolean isInfinite = effect.getDuration() > 9999;
        boolean isAmplifierZero = effect.getAmplifier() == 0;
        boolean playerHasOurEffect = hasInvisEffect(player);
        boolean isInSparkMode = currentlyInvisible.contains(player.getUniqueId());
        
        // The key change: ONLY consider it our effect if it's infinite duration
        // Vanilla potions always have a finite duration
        return isInfinite && isAmplifierZero && (playerHasOurEffect || isInSparkMode);
    }
    
    // Helper to clear spark state (for safety)
    public static void clearSparkState(Player player) {
        UUID playerId = player.getUniqueId();
        currentlyInvisible.remove(playerId);
        BukkitTask task = periodicHideTasks.remove(playerId);
        if (task != null && !task.isCancelled()) {
            task.cancel();
        }
    }
    
    @Override
    public void activatePassive(Player player) {
        safeRemoveAndAddInvis(player);
    }
    
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (hasInvisEffect(player)) {
            PotionEffect effect = player.getPotionEffect(PotionEffectType.INVISIBILITY);
            if (effect != null && effect.getDuration() > 9999) {
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
            }
        }
        UUID playerId = player.getUniqueId();
        clearSparkState(player);
        hitCounter.remove(playerId);
        lastSparkTime.remove(playerId);
    }
    
    @EventHandler
    public void onPotionDrain(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        if (hasInvisEffect(player)) {
            PotionEffect effect = player.getPotionEffect(PotionEffectType.INVISIBILITY);
            if (effect != null && effect.getDuration() > 9999) {
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
            }
        }
    }
    
    @EventHandler
    public void onPlayerJoin(org.bukkit.event.player.PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (hasInvisEffect(player)) {
            safeRemoveAndAddInvis(player);
        }
    }
    
    @EventHandler
    public void onPlayerQuit(org.bukkit.event.player.PlayerQuitEvent event) {
        Player player = event.getPlayer();
        PotionEffect effect = player.getPotionEffect(PotionEffectType.INVISIBILITY);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
        }
        restoreFullVisibility(player);
        UUID playerId = player.getUniqueId();
        clearSparkState(player);
        hitCounter.remove(playerId);
        lastSparkTime.remove(playerId);
        if (activeSmokeBombs.containsKey(playerId)) {
            activeSmokeBombs.remove(playerId);
        }
        BukkitTask task = smokeBombTasks.remove(playerId);
        if (task != null && !task.isCancelled()) {
            task.cancel();
        }
    }
    
    private void hidePlayerArmor(Player player) {
        // Hide armor to the player during smoke bomb
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 100, 0)); // 5 seconds
    }
    
    public boolean hasInvisEffect(Player player) {
        var data = plugin.getDataManager().getPlayerData(player.getUniqueId());
        return (data.getPrimaryPotion() == PotionType.INVIS && data.isPrimaryEnabled()) ||
               (data.getSecondaryPotion() == PotionType.INVIS && data.isSecondaryEnabled());
    }
    
    // Black magic circle effect method
    private void createBlackMagicCircle(Player player) {
        Location center = player.getLocation();
        Set<UUID> affected = new HashSet<>();
        
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline() || ticks > SPARK_DURATION) {
                    cancel();
                    return;
                }
                
                // Draw multiple layers of thin black particles for a more dramatic effect
                for (int layer = 0; layer < 3; layer++) {
                    double layerHeight = layer * 0.25;
                    
                    // Draw circle of black particles - more dense for better visibility
                    for (int i = 0; i < 90; i++) { // More points for thinner circle
                        double angle = 2 * Math.PI * i / 90;
                        double x = center.getX() + SPARK_RADIUS * Math.cos(angle);
                        double z = center.getZ() + SPARK_RADIUS * Math.sin(angle);
                        Location particleLoc = new Location(center.getWorld(), x, center.getY() + layerHeight, z);
                        
                        // Main black particle circle - thin and precise
                        center.getWorld().spawnParticle(Particle.ASH, particleLoc, 1, 0.02, 0.02, 0.02, 0);
                        
                        // Add some smoke for effect - less frequent for thinner appearance
                        if (i % 5 == 0) {
                            center.getWorld().spawnParticle(Particle.SMOKE, particleLoc, 1, 0.02, 0.02, 0.02, 0.005);
                        }
                        
                        // Add occasional dark cloud particles for a more intense look
                        if (i % 15 == 0 && layer == 1 && ticks % 5 == 0) {
                            center.getWorld().spawnParticle(Particle.LARGE_SMOKE, particleLoc, 1, 0.05, 0.05, 0.05, 0.005);
                        }
                    }
                }
                
                // Add some floating particles inside the circle - fewer for a more subtle effect
                if (ticks % 5 == 0) {
                    for (int i = 0; i < 3; i++) {
                        double angle = 2 * Math.PI * Math.random();
                        double distance = SPARK_RADIUS * 0.7 * Math.random();
                        double x = center.getX() + distance * Math.cos(angle);
                        double z = center.getZ() + distance * Math.sin(angle);
                        Location particleLoc = new Location(center.getWorld(), x, center.getY() + 0.3 + Math.random(), z);
                        center.getWorld().spawnParticle(Particle.SMOKE, particleLoc, 1, 0.05, 0.05, 0.05, 0.005);
                    }
                }
                
                // Affect players inside the circle (once per spark)
                for (Entity entity : center.getWorld().getNearbyEntities(center, SPARK_RADIUS, 2, SPARK_RADIUS)) {
                    if (entity instanceof Player target && !target.equals(player)) {
                        double dist = entity.getLocation().distance(center);
                        if (dist <= SPARK_RADIUS && !affected.contains(target.getUniqueId())) {
                            target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 1));
                            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
                            affected.add(target.getUniqueId());
                            target.sendMessage(Component.text("👁️ You are blinded by the smoke!").color(NamedTextColor.DARK_GRAY));
                        }
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 2L); // Every 2 ticks
    }

    // ProtocolLib: Hide all equipment from other players (enum-based, reliable)
    private void hideEquipmentForOthers(Player player) {
        // Create empty equipment list
        List<Pair<EnumWrappers.ItemSlot, ItemStack>> equipment = new ArrayList<>();
        
        // Add empty items for all equipment slots
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.HEAD, null));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.CHEST, null));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.LEGS, null));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.FEET, null));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.MAINHAND, null));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.OFFHAND, null));

        // Create and send equipment packet to all players except the invisible one
        PacketContainer packet = protocolManager.createPacket(PacketType.Play.Server.ENTITY_EQUIPMENT);
        packet.getIntegers().write(0, player.getEntityId());
        packet.getSlotStackPairLists().write(0, equipment);

        for (Player observer : plugin.getServer().getOnlinePlayers()) {
            if (!observer.equals(player)) {
                try {
                    protocolManager.sendServerPacket(observer, packet);
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to hide equipment for " + player.getName() + " from " + observer.getName());
                }
            }
        }
    }

    private void showEquipmentForOthers(Player player) {
        // Create equipment list with actual items
        List<Pair<EnumWrappers.ItemSlot, ItemStack>> equipment = new ArrayList<>();
        
        // Add all current equipment
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.HEAD, player.getInventory().getHelmet()));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.CHEST, player.getInventory().getChestplate()));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.LEGS, player.getInventory().getLeggings()));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.FEET, player.getInventory().getBoots()));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.MAINHAND, player.getInventory().getItemInMainHand()));
        equipment.add(new Pair<>(EnumWrappers.ItemSlot.OFFHAND, player.getInventory().getItemInOffHand()));

        // Create and send equipment packet to all players
        PacketContainer packet = protocolManager.createPacket(PacketType.Play.Server.ENTITY_EQUIPMENT);
        packet.getIntegers().write(0, player.getEntityId());
        packet.getSlotStackPairLists().write(0, equipment);

        for (Player observer : plugin.getServer().getOnlinePlayers()) {
            if (!observer.equals(player)) {
                try {
                    protocolManager.sendServerPacket(observer, packet);
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to restore equipment visibility for " + player.getName() + " to " + observer.getName());
                }
            }
        }
    }

    // Scoreboard team logic for full name tag hiding
    private void hideNameTag(Player player) {
        Scoreboard scoreboard = player.getServer().getScoreboardManager().getMainScoreboard();
        Team team = scoreboard.getTeam("invis") != null ? scoreboard.getTeam("invis") : scoreboard.registerNewTeam("invis");
        team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.NEVER);
        team.addEntry(player.getName());
    }
    private void showNameTag(Player player) {
        Scoreboard scoreboard = player.getServer().getScoreboardManager().getMainScoreboard();
        Team team = scoreboard.getTeam("invis");
        if (team != null) {
            team.removeEntry(player.getName());
        }
    }

    public static void removePassiveInvis(Player player) {
        // Use the complete removal method
        InfuseSMPPlugin plugin = InfuseSMPPlugin.getInstance();
        if (plugin != null) {
            InvisEffect invisEffect = (InvisEffect) plugin.getEffectManager().getEffectHandler(PotionType.INVIS);
            if (invisEffect != null) {
                invisEffect.removeAllInvisibility(player);
            }
        }
    }

    // Add new method to handle complete visibility restoration
    private static void restoreFullVisibility(Player player) {
        UUID playerId = player.getUniqueId();
        
        // Remove invisibility effects
        player.removePotionEffect(PotionEffectType.INVISIBILITY);
        player.setInvisible(false);
        
        // Restore nametag visibility
        player.setCustomNameVisible(true);
        
        // Get plugin instance for static context
        InfuseSMPPlugin plugin = InfuseSMPPlugin.getInstance();
        if (plugin == null) return;
        
        // Get invis effect instance
        InvisEffect invisEffect = (InvisEffect) plugin.getEffectManager().getEffectHandler(PotionType.INVIS);
        if (invisEffect == null) return;
        
        // Show nametag and equipment
        invisEffect.showNameTag(player);
        invisEffect.showEquipmentForOthers(player);
        
        // Remove from tracking sets
        currentlyInvisible.remove(playerId);
        
        // Cancel any ongoing tasks
        BukkitTask task = periodicHideTasks.remove(playerId);
        if (task != null && !task.isCancelled()) {
            task.cancel();
        }
    }

    // Add respawn handler to ensure visibility
    @EventHandler
    public void onPlayerRespawn(org.bukkit.event.player.PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        new BukkitRunnable() {
            @Override
            public void run() {
                restoreFullVisibility(player);
                if (hasInvisEffect(player)) {
                    safeRemoveAndAddInvis(player);
                }
            }
        }.runTaskLater(plugin, 1L);
    }
    
    @Override
    public void deactivatePassive(Player player) {
        UUID playerId = player.getUniqueId();
        // Remove only our infinite-duration effect (like OceanEffect)
        PotionEffect effect = player.getPotionEffect(PotionEffectType.INVISIBILITY);
        if (effect != null && effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
        }
        clearSparkState(player);
        hitCounter.remove(playerId);
        lastSparkTime.remove(playerId);
        if (activeSmokeBombs.containsKey(playerId)) {
            activeSmokeBombs.remove(playerId);
        }
        BukkitTask task = smokeBombTasks.remove(playerId);
        if (task != null && !task.isCancelled()) {
            task.cancel();
        }
        player.sendMessage(Component.text("👻 Invisibility Effect deactivated!")
                .color(NamedTextColor.GRAY));
    }
    
    @Override
    public void useSpark(Player player) {
        if (!hasInvisEffect(player)) {
            player.sendMessage(Component.text("You no longer have the Invis effect active!").color(NamedTextColor.RED));
            return;
        }
        UUID playerId = player.getUniqueId();
        long currentTime = System.currentTimeMillis();
        
        // Single cooldown check
        if (lastSparkTime.containsKey(playerId)) {
            long lastTime = lastSparkTime.get(playerId);
            if (currentTime - lastTime < SPARK_COOLDOWN) {
                long secondsLeft = (SPARK_COOLDOWN - (currentTime - lastTime)) / 1000;
                player.sendMessage(Component.text("❌ Spark is on cooldown! (" + secondsLeft + "s)").color(NamedTextColor.RED));
                return;
            }
        }
        
        // Set cooldown immediately
        lastSparkTime.put(playerId, currentTime);
        
        // Clear any existing spark state
        clearSparkState(player);
        
        // Remove regular invisibility first
        player.removePotionEffect(PotionEffectType.INVISIBILITY);
        
        // Apply complete invisibility with ProtocolLib
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 400, 1, false, false));
        currentlyInvisible.add(playerId);
        player.setCustomNameVisible(false);
        hideNameTag(player);
        player.setInvisible(true);
        
        // Play effects
        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 0.5f);
        player.sendMessage(Component.text("👻 You are completely invisible for 20 seconds!").color(NamedTextColor.LIGHT_PURPLE));
        createBlackMagicCircle(player);
        
        // Hide equipment immediately
        hideEquipmentForOthers(player);
        
        // Periodically re-hide equipment and maintain invisibility
        BukkitTask periodicHideTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (!player.isOnline() || !currentlyInvisible.contains(playerId) || ticks > 400) {
                    this.cancel();
                    return;
                }
                // Re-hide equipment every 5 ticks
                hideEquipmentForOthers(player);
                // Re-apply invisibility every 40 ticks (2 seconds) to prevent glitches
                if (ticks % 40 == 0) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 400, 1, false, false));
                    player.setInvisible(true);
                }
                ticks += 5;
            }
        }.runTaskTimer(plugin, 0L, 5L);
        periodicHideTasks.put(playerId, periodicHideTask);
        
        // Schedule restoration after 20 seconds
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) return;
                
                // Full visibility restoration
                restoreFullVisibility(player);
                
                // If passive invis is still enabled, reapply it
                if (hasInvisEffect(player)) {
                    // Reapply vanilla invisibility
                    player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
                }
                
                player.sendMessage(Component.text("👻 You are visible again!")
                        .color(NamedTextColor.GRAY));
            }
        }.runTaskLater(plugin, 400L);
    }
    
    public void handleAttack(Player attacker, EntityDamageByEntityEvent event) {
        UUID attackerId = attacker.getUniqueId();
        
        // Increment hit counter
        int hits = hitCounter.getOrDefault(attackerId, 0) + 1;
        hitCounter.put(attackerId, hits);
        
        // Every 10 hits, hide enemy health and apply blindness
        if (hits >= HITS_FOR_EFFECT) {
            hitCounter.put(attackerId, 0);
            
            if (event.getEntity() instanceof LivingEntity target) {
                // Hide health
                if (target instanceof Player) {
                    ((Player) target).setHealthScaled(false);
                }
                
                // Apply blindness
                target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0)); // 3 seconds
                
                // Visual effect
                target.getWorld().spawnParticle(Particle.CLOUD,
                    target.getEyeLocation(),
                    20, 0.2, 0.2, 0.2, 0.05);
                
                attacker.sendMessage(Component.text("👻 Target blinded!")
                        .color(NamedTextColor.GRAY));
            }
        }
    }
    
    public void handleDefense(Player defender, EntityDamageByEntityEvent event) {
        // No special defense handling needed
    }

    // Modified removal method to only remove our custom invisibility
    private void removeAllInvisibility(Player player) {
        PotionEffect currentInvis = player.getPotionEffect(PotionEffectType.INVISIBILITY);
        // Only remove if it's our effect
        if (isOurInvisibilityEffect(player, currentInvis)) {
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
            // Add debug message
            plugin.getLogger().info("Removed invisibility effect from " + player.getName() + 
                " with duration: " + (currentInvis != null ? currentInvis.getDuration() : "null") + 
                " and amplifier: " + (currentInvis != null ? currentInvis.getAmplifier() : "null"));
        }
    }

    private void safeRemoveAndAddInvis(Player player) {
        PotionEffect effect = player.getPotionEffect(PotionEffectType.INVISIBILITY);
        if (effect == null || effect.getDuration() > 9999) {
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
            player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0));
        }
    }
}